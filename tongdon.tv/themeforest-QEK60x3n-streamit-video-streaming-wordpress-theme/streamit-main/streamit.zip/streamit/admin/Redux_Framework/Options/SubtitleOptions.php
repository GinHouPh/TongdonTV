<?php

if (!class_exists('Redux')) {
    exit;
}

Redux::set_section($this->opt_name, array(
    'title'      => esc_html__('Subtitle Settings', 'streamit'),
    'id'         => 'streamit_subtitle_settings',
    'icon'       => 'el el-cc', // Icon close to captions
    'desc'       => esc_html__('Configure the default appearance of subtitles in the player.', 'streamit'),
    'fields'     => array(
        
        array(
            'id'       => 'streamit_subtitle_font_size',
            'type'     => 'button_set',
            'title'    => esc_html__('Font Size', 'streamit'),
            'subtitle' => esc_html__('Select the default font size.', 'streamit'),
            'options'  => array(
                '75'   => 'Small', 
                '100'  => 'Medium', 
                '125'  => 'Large',
                '150'  => 'Extra Large'
            ),
            'default'  => '100'
        ),

        array(
            'id'       => 'streamit_subtitle_font_family',
            'type'     => 'select',
            'title'    => esc_html__('Font Family', 'streamit'),
            'subtitle' => esc_html__('Select the font family.', 'streamit'),
            'options'  => array(
                'Default'      => 'Default',
                'Block'        => 'Block',
                'Typewriter'   => 'Typewriter',
                'Print'        => 'Print',
                'Console'      => 'Console',
                'Block Curved' => 'Block Curved',
                'Cursive'      => 'Cursive',
                'Small Caps'   => 'Small Caps'
            ),
            'default'  => 'Default'
        ),

        array(
            'id'       => 'streamit_subtitle_text_shadow',
            'type'     => 'button_set',
            'title'    => esc_html__('Text Edge Style', 'streamit'),
            'subtitle' => esc_html__('Select the text edge style.', 'streamit'),
            'options'  => array(
                'none'        => 'None',
                'raised'      => 'Raised',
                'depressed'   => 'Depressed',
                'uniform'     => 'Uniform',
                'drop_shadow' => 'Drop Shadow'
            ),
            'default'  => 'none'
        ),
    )
));
