<?php


if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}


Redux::set_section($this->opt_name, array(
    'title'         => esc_html__('Starring/Genres/Tags', 'streamit'),
    'id'            => 'custom-text-custom-options',
    'icon'          => 'custom-Information',
    'subsection'    => true,
    'fields'        => array(
        array(
            'id'        => 'streamit_starring_title',
            'type'      => 'text',
            'title'     => esc_html__('Starring title', 'streamit'),
            'default'   => esc_html__('Starring', 'streamit')
        ),
        array(
            'id'        => 'streamit_genres_title',
            'type'      => 'text',
            'title'     => esc_html__('Genres title', 'streamit'),
            'default'   => esc_html__('Genres', 'streamit')
        ),
        array(
            'id'        => 'streamit_tag_title',
            'type'      => 'text',
            'title'     => esc_html__('Tag title', 'streamit'),
            'default'   => esc_html__('Tags', 'streamit')
        ),

        array(
            'id'        => 'streamit_genere_tag_category_item',
            'type'      => 'button_set',
            'title'     => esc_html__('Genres, Tags , Categories, Archive/Single Page Loading Option', 'streamit'),
            'subtitle'  => esc_html__('Select any one as per you requirement, work in archive, genres, tags, categories, single page and filter page', 'streamit'),
            'options'   => array(
                'load_more'         => esc_html__('Load More', 'streamit'),
                'infinite_scroll'   => esc_html__('Infinite Scroll', 'streamit')
            ),
            'default' => esc_html__('load_more', 'streamit'),
        ),
        array(
            'id'        => 'streamit_genere_tag_category_display_loadmore_text',
            'type'      => 'text',
            'title'     => esc_html__('Load More button text', 'streamit'),
            'desc'      => esc_html__('This text will be displayed on the load more button.', 'streamit'),
            'default'   => esc_html__('Load More', 'streamit'),
            'required'  => array('streamit_genere_tag_category_item', '=', 'load_more'),
        ),
        array(
            'id'        => 'streamit_genere_tag_category_loadmore_text_2',
            'type'      => 'text',
            'title'     => esc_html__('Load More Loader Text', 'streamit'),
            'desc'      => esc_html__('This text will be displayed when the load more button is clicked.', 'streamit'),
            'default'   => esc_html__('Loading...', 'streamit'),
            'required'  => array('streamit_genere_tag_category_item', '=', 'load_more'),
        ),
        array(
            'id'        => 'streamit_genere_tag_category_post_per_page',
            'type'      => 'text',
            'title'     => esc_html__('Item Per Page', 'streamit'),
            'desc'      => esc_html__('This setting controls how many items are displayed per page on the categories, genres, and tags', 'streamit'),
            'default'   => '15',
        ),
        array(
            'id'        => 'streamit_archive_page_post_per_page',
            'type'      => 'text',
            'title'     => esc_html__('Archive Page(Filter page) Items Per Page', 'streamit'),
            'desc'      => esc_html__('This setting controls how many items are displayed per page on the archive page(filter page)', 'streamit'),
            'default'   => '15',
        ),
    )
));
