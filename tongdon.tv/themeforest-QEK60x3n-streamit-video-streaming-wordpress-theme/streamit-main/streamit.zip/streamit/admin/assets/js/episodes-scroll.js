jQuery(function ($) {

    const STORAGE_PREFIX = 'activeEpisodeRange';

    $('.tab-pane').each(function () {
        const $tabPane = $(this);
        const seasonIndex = $tabPane.data('season-index');
        if (seasonIndex === undefined) return;

        const savedRange = localStorage.getItem(STORAGE_PREFIX + seasonIndex);
        if (!savedRange) return;

        const $btn = $tabPane
            .find(`.episode-range-btn[data-range-start="${savedRange}"]`);

        if ($btn.length) {
            $btn
                .addClass('active')
                .closest('ul')
                .find('.episode-range-btn')
                .not($btn)
                .removeClass('active');
        }
    });


    $(document).on('click', '.episode-range-btn', function (e) {
        e.preventDefault();

        const $btn = $(this);
        const rangeStart = parseInt($btn.data('range-start'), 10);
        if (!rangeStart) return;

        const $tabPane = $btn.closest('.tab-pane');
        const seasonIndex = $tabPane.data('season-index');

        // Save to localStorage
        if (seasonIndex !== undefined) {
            localStorage.setItem(
                STORAGE_PREFIX + seasonIndex,
                rangeStart
            );
        }

        const $slick = $tabPane.find('.css_prefix-slick-general');
        if (!$slick.length || !$slick.hasClass('slick-initialized')) return;

        const slick = $slick.slick('getSlick');
        const slidesToShow = slick.options.slidesToShow || 1;
        const total = slick.$slides.not('.slick-cloned').length;

        let targetSlide = Math.floor((rangeStart - 1) / slidesToShow) * slidesToShow;
        const maxSlide = Math.max(total - slidesToShow, 0);
        if (targetSlide > maxSlide) targetSlide = maxSlide;

        $slick.slick('slickGoTo', targetSlide, false);

        // Active state
        $btn
            .addClass('active')
            .closest('ul')
            .find('.episode-range-btn')
            .not($btn)
            .removeClass('active');
    });

});
