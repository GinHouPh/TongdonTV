<?php
if (!defined('ABSPATH'))
    exit;

$id = 'main-banner-' . esc_attr($id_int);

$autoplay = !empty($settings['autoplay']) && $settings['autoplay'] === 'true';
$delay = !empty($settings['autoplay_speed']) ? intval($settings['autoplay_speed']) : 5000;
$speed = !empty($settings['speed']) ? intval($settings['speed']) : 600;
?>

<div class="css_prefix-rtl-direction css_prefix-banner-thumb-slider st-main-slider inner-content">
    <section id="<?php echo $id; ?>" class="home-slider js-streamit-slider" data-type="main-banner"
        data-autoplay="<?php echo $autoplay ? 'true' : 'false'; ?>" data-delay="<?php echo esc_attr($delay); ?>"
        data-speed="<?php echo esc_attr($speed); ?>">

        <!-- MAIN SLIDER -->
        <div class="banner-main-slider">
            <div class="swiper-wrapper">
                <?php foreach ($post_data as $post):
                    $post_type = $post->get_post_type();
                    $bg = wp_get_attachment_url($post->get_meta('thumbnail_id'))
                        ?: streamit_placeholder_image();

                    $run_time = $censor_rating = $cast = $tag_list_display = $genres_list_display = '';
                    $post_id = $post->get_id();

                    if ($post_type == 'movie') {
                        $censor_rating = $post->get_meta('_movie_censor_rating');
                        $run_time = $post->get_meta('_movie_run_time');
                        $genre_texonomy = 'movie_genre';
                    } elseif ($post_type == 'tvshow') {
                        $seasons = $post->get_meta('_seasons');
                        $season_count = $seasons ? count($seasons) : 0;
                        $censor_rating = $season_count
                            ? $season_count . _n(" Season", " Seasons", $season_count, 'streamit')
                            : esc_html__('Arriving Soon', 'streamit');
                        $run_time = date('F Y', strtotime($post->get_post_date()));
                        $genre_texonomy = 'tvshow_genre';
                    } elseif ($post_type == 'video') {
                        $run_time = $post->get_meta('_video_run_time');
                        $genre_texonomy = 'video_category';
                    }

                    if ($post_type !== 'video' && !empty($post->get_meta('_cast'))) {
                        $cast = '';
                        foreach (array_slice($post->get_meta('_cast') ?? [], 0, 3) as $data) {
                            if ($cast_obj = streamit_get_person((int) $data['id'])) {
                                $cast .= '<a href="' . streamit_get_permalink($cast_obj->get_post_type(), $cast_obj->get_post_name()) . '">
                                        <span class="text-body">' . $cast_obj->get_post_title() . '</span></a>, ';
                            }
                        }
                        $cast = rtrim($cast, ", ");
                    }

                    if (!empty(streamit_get_term_by_post($post_id, $post_type . '_tag'))):
                        $tag_list = array_slice(streamit_get_term_by_post($post_id, $post_type . '_tag'), 0, 3) ?: [];
                        $tag_list_display = implode(', ', array_map(fn($tag) =>
                            '<a href="' . streamit_get_permalink($tag->get_taxonomy(), $tag->get_term_slug()) . '">
                                <span class="text-body">' . $tag->get_term_name() . '</span></a>', $tag_list));
                    endif;

                    if (!empty(streamit_get_term_by_post($post_id, $genre_texonomy))):
                        $genre_list = array_slice(streamit_get_term_by_post($post_id, $genre_texonomy), 0, 3);
                        $genres_list_display = implode(', ', array_map(function ($genre) {
                            return '<a href="' . streamit_get_permalink($genre->get_taxonomy(), $genre->get_term_slug()) . '">
                                        <span class="text-body">' . $genre->get_term_name() . '</span></a>';
                        }, $genre_list));
                    endif;

                    $imdb_logo = streamit_get_imdb_logo();
                    $url = streamit_get_permalink($post_type, $post->get_post_name());
                    ?>
                    <article class="swiper-slide banner-slide"
                        aria-label="<?php echo esc_attr($post->get_post_title()); ?>">
                        <div class="slide banner-bg <?php echo esc_attr($post_type); ?>"
                            style="background-image:url('<?php echo esc_url($bg); ?>')">
                            <div class="container-fluid position-relative h-100 slider-content-full-height">
                                <div class="shows-content h-100 slider-content-full-height">
                                    <div class="row align-items-lg-center h-100 slider-content-full-height">
                                        <div class="col-xl-5 col-lg-6 col-md-12">
                                            <header class="css-prefix-main-banner-content">

                                                <h2
                                                    class="slider-text texture-text line-count-2 RightAnimate-two banner-title">
                                                    <?php echo esc_html($post->get_post_title()); ?>
                                                </h2>

                                                <?php if ($post_type !== 'video' || $run_time !== '0:00'): ?>
                                                    <div
                                                        class="d-flex flex-wrap align-items-center gap-3 horizontal-thumb-description py-2 RightAnimate-three">
                                                        <?php if (!empty($censor_rating)) { ?>
                                                            <span class="badge bg-secondary slider-badge">
                                                                <?php echo esc_html($censor_rating); ?>
                                                            </span>
                                                        <?php }
                                                        if (!empty($post->get_meta('name_custom_imdb_rating'))) { ?>
                                                            <div class="slider-ratting d-flex align-items-center gap-1">
                                                                <?php echo st_star_rating($post->get_meta('name_custom_imdb_rating')); ?>
                                                            </div>
                                                            <?php if (is_array($imdb_logo) && !empty($imdb_logo['url'])) { ?>
                                                                <div class="imdb-ratting d-flex align-items-center gap-1">
                                                                    <img src="<?php echo esc_url($imdb_logo['url']); ?>" loading="lazy"
                                                                        decoding="async"
                                                                        alt="<?php esc_attr_e('imdb logo', 'streamit') ?>">
                                                                </div>
                                                            <?php }
                                                        } ?>
                                                        <?php if (!empty($run_time) && $run_time !== '0:00') { ?>
                                                            <div class="font-normal">
                                                                <?php
                                                                if ($post_type !== 'tvshow') {
                                                                    echo st_get_icon('clock');
                                                                    echo esc_html(st_format_runtime($run_time));
                                                                } else {
                                                                    echo esc_html($run_time);
                                                                } ?>
                                                            </div>
                                                        <?php } ?>
                                                    </div>
                                                <?php endif; ?>

                                                <?php if ($excerpt = $post->get_post_excerpt()): ?>
                                                    <p class="line-count-2 my-3 RightAnimate-two banner-description">
                                                        <?php echo str_replace(['<p>', '</p>'], '', $excerpt); ?>
                                                    </p>
                                                <?php endif; ?>

                                                <div class="gener-tag trending-list RightAnimate-three">
                                                    <?php if (!empty($tag_listDisplay)): ?>
                                                        <div class="text-primary title tag">
                                                            <span
                                                                class="mx-0"><?php echo esc_html__('Tag', 'streamit') . ':'; ?></span>
                                                            <span
                                                                class="text-body"><?php echo wp_kses_post($tag_list_display) ?></span>
                                                        </div>
                                                    <?php endif; ?>

                                                    <?php if (!empty($genres_list_display)): ?>
                                                        <div class="text-primary title genres">
                                                            <span
                                                                class="mx-0"><?php echo esc_html__('Genres', 'streamit') . ':'; ?></span>
                                                            <span
                                                                class="text-body"><?php echo wp_kses_post($genres_list_display) ?></span>
                                                        </div>
                                                    <?php endif; ?>

                                                    <?php if (!empty($cast)): ?>
                                                        <div class="text-primary title starring">
                                                            <span
                                                                class="mx-0"><?php echo esc_html__('Starring', 'streamit') . ':'; ?></span>
                                                            <span class="text-body"><?php echo wp_kses_post($cast); ?></span>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>

                                                <div class="banner-btn RightAnimate-four mt-lg-0 mt-4">
                                                    <a href="<?php echo esc_url($url); ?>"
                                                        class="btn btn-primary banner-play-btn" tabindex="0">
                                                        <span class="d-flex align-items-center gap-2">
                                                            <span><?php echo esc_html($settings['play_now_text']); ?></span>
                                                            <?php echo st_get_icon('play', ['class' => 'ms-2', 'aria-hidden' => 'true']); ?>
                                                        </span>
                                                    </a>
                                                </div>

                                            </header>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- THUMB SLIDER -->
        <div class="horizontal_thumb_slider banner-thumb-wrapper">
            <nav class="banner-thumb-slider-nav d-flex align-items-center" aria-label="Banner navigation">

                <button class="thumb-btn-prev PreArrow-two" aria-label="Previous slide">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none"
                        stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="15 18 9 12 15 6" />
                    </svg>
                </button>

                <div class="swiper banner-thumb-slider w-100">
                    <div class="swiper-wrapper">
                        <?php foreach ($post_data as $post):
                            $post_type = $post->get_post_type();
                            $run_time = '';
                            if ($post_type == 'movie') {
                                $run_time = $post->get_meta('_movie_run_time');
                            } elseif ($post_type == 'tvshow') {
                                $run_time = date('F Y', strtotime($post->get_post_date()));
                            } elseif ($post_type == 'video') {
                                $run_time = $post->get_meta('_video_run_time');
                            }

                            $portrait = streamit_render_image([
                                'attachment_id' => $post->get_meta('_portrait_thumbmail'),
                                'class' => 'img-fluid',
                                'alt' => $post->get_post_title(),
                                'loading' => 'lazy'
                            ]);
                            ?>
                            <div class="swiper-slide banner-thumb-slide" role="button" tabindex="0"
                                aria-label="<?php echo esc_attr($post->get_post_title()); ?>">
                                <figure
                                    class="block-images position-relative <?php echo esc_attr($post_type); ?> banner-thumb-card m-0">
                                    <?php echo $portrait; ?>
                                    <figcaption class="block-description">
                                        <h6 class="css_prefix-verticle-title line-count-1">
                                            <?php echo esc_html($post->get_post_title()) ?></h6>
                                        <div class="movie-time d-flex align-items-center mt-1">
                                            <small class="movie-time-text font-normal d-flex align-items-center gap-1">
                                                <?php if (!empty($run_time) && $run_time !== '0:00') {
                                                    if ($post_type !== 'tvshow') {
                                                        echo st_get_icon('clock');
                                                        echo esc_html(st_format_runtime($run_time));
                                                    } else {
                                                        echo esc_html($run_time);
                                                    }
                                                } ?>
                                            </small>
                                        </div>
                                    </figcaption>
                                </figure>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <button class="thumb-btn-next NextArrow-two" aria-label="Next slide">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="20" height="20" fill="none"
                        stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="9 18 15 12 9 6" />
                    </svg>
                </button>

            </nav>
        </div>

    </section>
</div>