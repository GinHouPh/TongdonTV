<?php
defined('ABSPATH') || exit;
if (empty($result))
    return;

global $streamit_options;

$enable_premium_badges =
    (!empty($settings['enable_premium_badges']) &&
        $settings['enable_premium_badges'] === 'yes');
$show_title_flag = $settings['show_title'] ?? 'yes';
$get_navigation_setting = static function (string $key, string $legacy_key = '', string $fallback = 'flex') use ($settings): bool {
    if (array_key_exists($key, $settings) && $settings[$key] !== '') {
        return $settings[$key] === 'flex' || $settings[$key] === 'true';
    }

    if ($legacy_key && array_key_exists($legacy_key, $settings) && $settings[$legacy_key] !== '') {
        return $settings[$legacy_key] === 'flex' || $settings[$legacy_key] === 'true';
    }

    return $fallback === 'flex' || $fallback === 'true';
};
$desktop_navigation = $get_navigation_setting('nav-arrow', '', 'flex');
$laptop_navigation = $get_navigation_setting('nav-arrow_laptop', '', 'flex');
$tablet_navigation = $get_navigation_setting('nav-arrow_tablet', 'nav_arrow_tablet');
$mobile_navigation = $get_navigation_setting('nav-arrow_mobile', 'nav_arrow_mobile');
$show_navigation = $desktop_navigation || $laptop_navigation || $tablet_navigation || $mobile_navigation;
?>

<div class="section-spacing-bottom streamit-topten-section streamit-responsive-arrow-widget">


    <?php if (!empty($slider_title) && $show_title_flag === 'yes'): ?>

        <header class="streamit-section-header d-flex align-items-center justify-content-between">

                <<?php echo esc_attr($settings['title_tag'] ?? 'h3'); ?>
                    class="streamit-section-title mb-0">

                    <?php echo esc_html($slider_title); ?>

                </<?php echo esc_attr($settings['title_tag'] ?? 'h3'); ?>>

        </header>

    <?php endif; ?>


    <div class="swiper js-streamit-slider streamit-topten-slider" data-type="top-ten"
        data-slides="<?php echo esc_attr($settings['desk_number'] ?? 6); ?>"
        data-lap="<?php echo esc_attr($settings['lap_number'] ?? 4); ?>"
        data-tab="<?php echo esc_attr($settings['tab_number'] ?? 3); ?>"
        data-mob="<?php echo esc_attr($settings['mob_number'] ?? 2.5); ?>" data-loop="<?php echo esc_attr(
                 !empty($settings['infinite']) &&
                 $settings['infinite'] === 'true'
                 ? 'true' : 'false'
             ); ?>" data-autoplay="<?php echo esc_attr(
                  !empty($settings['autoplay']) &&
                  $settings['autoplay'] === 'true'
                  ? 'true' : 'false'
              ); ?>" data-delay="<?php echo esc_attr(
                   $settings['autoplay_speed'] ?? 2000
                ); ?>" data-speed="<?php echo esc_attr(
                    $settings['speed'] ?? 400
                ); ?>" data-navigation="<?php echo esc_attr(
                     $desktop_navigation ? 'true' : 'false'
                 ); ?>" data-navigation-laptop="<?php echo esc_attr(
                     $laptop_navigation ? 'true' : 'false'
                 ); ?>" data-navigation-tablet="<?php echo esc_attr(
                     $tablet_navigation ? 'true' : 'false'
                 ); ?>" data-navigation-mobile="<?php echo esc_attr(
                     $mobile_navigation ? 'true' : 'false'
                 ); ?>" data-pagination="false">


        <div class="swiper-wrapper">

            <?php
            $rank = 0;

            foreach ($result as $post):

                if (!$post)
                    continue;

                $rank++;

                $post_type = $post->get_post_type();
                $slug = $post->get_post_name();
                $title = esc_html($post->get_post_title());

                $url =
                    streamit_get_permalink(
                        $post_type,
                        $slug
                    );

                $image =
                    streamit_render_image([
                        'attachment_id' =>
                            $post->get_meta('_portrait_thumbmail'),

                        'class' => 'img-fluid w-100',

                        'alt' => $title,

                        'loading' => $rank <= 3
                            ? 'eager'
                            : 'lazy',

                        'decoding' => 'async'
                    ]);

                $badge =
                    streamit_get_access_badge_for_user($post);

                ?>

                <article class="swiper-slide">

                    <div class="streamit-topten-card">

                        <figure class="streamit-topten-media">

                            <a href="<?php echo esc_url($url); ?>" aria-label="<?php echo esc_attr($title); ?>">
                                <?php echo $image; ?>
                            </a>
                            <?php if (!empty($badge) && $enable_premium_badges && function_exists('st_get_icon')):
                                $badge_map = [
                                    'is_premium_icon' => ['class' => 'streamit-badge-premium', 'title_key' => 'premium_title', 'icon' => 'premium'],
                                    'is_rent_icon' => ['class' => 'streamit-badge-ppv', 'title_key' => 'rent_title', 'icon' => 'rent'],
                                    'is_rented_icon' => ['class' => 'streamit-badge-ppv-rented', 'title_key' => 'rent_title', 'icon' => 'rented'],
                                ];
                                foreach ($badge_map as $key => $config):
                                    if (!empty($badge[$key])): ?>
                                        <span class="streamit-badge <?php echo esc_attr($config['class']); ?>" data-bs-toggle="tooltip"
                                            data-bs-placement="top" title="<?php echo esc_attr($badge[$config['title_key']]); ?>">
                                            <?php echo st_get_icon($config['icon']); ?>
                                        </span>
                                    <?php endif;
                                endforeach;
                            endif; ?>


                            <span class="top_ten_numbers texture-text" aria-hidden="true">

                                <?php echo esc_html($rank); ?>

                            </span>


                        </figure>


                    </div>

                </article>

            <?php endforeach; ?>


        </div>
    </div>


    <?php if ($show_navigation): ?>

        <button class="swiper-arrow swiper-button-prev js-swiper-prev" aria-label="Previous">

            <i class="icon-arrow-left"></i>

        </button>


        <button class="swiper-arrow swiper-button-next js-swiper-next" aria-label="Next">

            <i class="icon-arrow-right"></i>

        </button>

    <?php endif; ?>


    </div>
