<?php
if (!defined('ABSPATH')) exit;
if (is_wp_error($post_data) || empty($post_data)) return;

global $streamit_options;

$col_count = !empty($settings['streamit_grid_style'])
    ? (int)$settings['streamit_grid_style']
    : 4;

$enable_premium_badges =
    (!empty($enable_premium_badges) && $enable_premium_badges === 'yes') &&
    (!isset($streamit_options['streamit_recommended_enable_premium_badges'])
        || $streamit_options['streamit_recommended_enable_premium_badges'] === 'yes');

$enable_upcoming_badges =
    ($streamit_options['streamit_recommended_enable_upcoming_badges'] === 'yes');

$view_all_url =
    !empty($settings['st_select_content_type'])
        ? streamit_get_permalink(
            $settings['st_select_content_type'],
            '',
            $post_filter
        )
        : '';
?>


<section class="streamit-grid-section streamit-grid-landscape">

    <?php if (!empty($slider_title) || (!empty($settings['view_all_switch']) && $view_all_url)) : ?>

        <header class="streamit-section-header d-flex align-items-center justify-content-between">
            
                <?php if (!empty($slider_title)) : ?>

                    <<?php echo esc_attr($title_tag); ?>
                        class="streamit-section-title mb-0">

                        <?php echo esc_html($slider_title); ?>

                    </<?php echo esc_attr($title_tag); ?>>

                <?php endif; ?>

                <?php if (!empty($settings['view_all_switch']) && $view_all_url) : ?>

                    <a class="streamit-grid-viewall"
                    href="<?php echo esc_url($view_all_url); ?>">

                        <?php esc_html_e('View All','streamit'); ?>

                    </a>

                <?php endif; ?>
        </header>

    <?php endif; ?>



    <div class="row g-4">

        <?php foreach ($post_data as $index => $post):

            if (!is_object($post) || !method_exists($post,'get_meta')) continue;

            $post_id    = (int)$post->get_id();
            $post_type  = sanitize_text_field($post->get_post_type());
            $post_slug  = sanitize_title($post->get_post_name());
            $post_title = esc_html($post->get_post_title());

            $permalink =
                esc_url(
                    streamit_get_permalink(
                        $post_type,
                        $post_slug
                    )
                );


            $image_id =
                $post->get_meta('thumbnail_id');


            $image_html =
                streamit_render_image([
                    'attachment_id'=>$image_id,
                    'class'=>'img-fluid w-100',
                    'alt'=>$post_title,
                    'loading'=>$index < 4 ? 'eager':'lazy',
                    'decoding'=>'async'
                ]);


            /* taxonomy */
            $taxonomy_map=[
                'movie'=>'movie_genre',
                'tvshow'=>'tvshow_genre',
                'tv_show'=>'tvshow_genre',
                'video'=>'video_category'
            ];

            $taxonomy =
                $taxonomy_map[$post_type] ?? 'video_category';


            $term_ids =
                streamit_get_term_relationships(
                    $post_id,
                    $taxonomy
                );

            $terms_data =
                !empty($term_ids)
                ? streamit_get_terms([
                    'include'=>$term_ids,
                    'per_page'=>2
                ])->results
                : [];


            /* runtime */
            $runtime =
                st_format_runtime(
                    $post->get_meta("_{$post_type}_run_time")
                );


            /* language */
            $language_meta =
                $post->get_meta('_language');

            $language_html='';

            if(!empty($language_meta['labels']))
            {
                $labels =
                    array_slice(
                        $language_meta['labels'],
                        0,
                        2
                    );

                $extra =
                    count($language_meta['labels']) - 2;

                $language_html =
                    st_get_icon('translate').
                    '<small>'.
                    esc_html(
                        implode(', ',$labels)
                    ).
                    ($extra>0?' +'.$extra:'').
                    '</small>';
            }


            /* upcoming */
            $upcoming =
                function_exists('streamit_is_upcoming')
                ? streamit_is_upcoming($post,$post_type)
                : ['is_upcoming'=>false,'is_future_release'=>false];

            $is_upcoming =
                !empty($upcoming['is_upcoming']) &&
                !empty($upcoming['is_future_release']);


            /* badges */
            $badge =
                $enable_premium_badges
                ? streamit_get_access_badge_for_user($post)
                : null;

            $render_badges = static function ($badge) {
                if (empty($badge)) return;

                if (!empty($badge['is_premium_icon'])) {
                    echo '<span class="streamit-badge-premium">'
                        . st_get_icon('premium') . '</span>';
                }
                if (!empty($badge['is_rent_icon'])) {
                    echo '<span class="streamit-badge-ppv">'
                        . st_get_icon('rent') . '</span>';
                }
                if (!empty($badge['is_rented_icon'])) {
                    echo '<span class="streamit-badge-ppv-rented">'
                        . st_get_icon('rented') . '</span>';
                }
            };

            /* play link */
            $play_link = $permalink;

            if(!$is_upcoming && $post_type==='tvshow')
            {
                if(!empty($badge['is_rented_icon']) ||
                   empty($badge))
                {
                    $play_link =
                        streamit_get_permalink(
                            $post_type,
                            trailingslashit(
                                $post_slug
                            ).'player'
                        );
                }
            }

        ?>


        <div class="col-6 col-md-4 col-lg-<?php echo (int)(12/$col_count); ?>">

            <article class="css_prefix-card landscape-card">


                <figure class="block-images position-relative w-100 cursor-pointer">

                    <a href="<?php echo $permalink; ?>" class="color-inherit image-box w-100"
                       aria-label="<?php echo esc_attr($post_title); ?>">

                        <?php echo $image_html; ?>


                        <?php if($is_upcoming && $enable_upcoming_badges): ?>

                        <span class="streamit-badge-upcoming">

                            <?php esc_html_e('Coming Soon','streamit'); ?>

                        </span>

                        <?php endif; ?>


                        <?php if(!empty($badge)): ?>

                        <?php $render_badges($badge); ?>

                        <?php endif; ?>


                    </a>

                </figure>



                <div class="card-description with-transition">


                    <?php if(!empty($terms_data)): ?>

                    <ul class="genres-list p-0 mb-2 d-flex flex-wrap align-items-center">

                        <?php foreach($terms_data as $term): ?>

                        <li class="list-inline-item">

                            <a href="<?php echo esc_url(
                                streamit_get_permalink(
                                    $taxonomy,
                                    $term->get_term_slug()
                                )
                            ); ?>">

                                <?php echo esc_html(
                                    $term->get_term_name()
                                ); ?>

                            </a>

                        </li>

                        <?php endforeach; ?>

                    </ul>

                    <?php endif; ?>



                    <?php if (!empty($settings['show_title'])) : ?>

                    <h5 class="css_prefix-title text-capitalize line-count-1">

                        <a href="<?php echo $permalink; ?>">

                            <?php echo $post_title; ?>

                        </a>

                    </h5>

                    <?php endif; ?>

                    <div class="d-flex flex-wrap align-items-center gap-2">

                        <?php if($runtime): ?>

                        <span>

                            <?php echo esc_html($runtime); ?>

                        </span>

                        <?php endif; ?>


                        <?php echo $language_html; ?>


                    </div>



                    <div class="css-prefix-play-button d-flex flex-wrap align-items-center gap-2 mt-2">

                        <?php echo do_shortcode(
                            '[streamit_watchlist_shortcode post_id="'.
                            esc_attr($post_id).
                            '" post_type="'.
                            esc_attr($post_type).
                            '" is_button="false"]'
                        ); ?>


                        <div>
                            <a href="<?php echo esc_url($play_link); ?>"
                           class="btn btn-primary">

                            <?php echo esc_html(
                                $settings['play_now_text']
                                ?? 'Play Now'
                            ); ?>

                        </a>
                        </div>

                    </div>


                </div>


            </article>

        </div>


        <?php endforeach; ?>


    </div>

</section>