<?php

/**
 * Streamit Main Card Slider Template (Optimized)
 * 
 * @package Streamit
 */
if (!defined('ABSPATH')) {
    exit;
}
if (is_wp_error($post_data) || empty($post_data)) {
    return;
}
global $streamit_options;
$enable_premium_badges = (!empty($enable_premium_badges) && $enable_premium_badges === 'yes') && (!isset($streamit_options['streamit_recommended_enable_premium_badges']) || $streamit_options['streamit_recommended_enable_premium_badges'] === 'yes');
$enable_upcoming_badges = ($streamit_options['streamit_recommended_enable_upcoming_badges'] === 'yes');
$show_title_flag = isset($settings['show_title']) ? $settings['show_title'] : 'yes';
$get_navigation_setting = static function (string $key, string $legacy_key = '', string $fallback = 'flex') use ($settings): bool {
    if (array_key_exists($key, $settings) && $settings[$key] !== '') {
        return $settings[$key] === 'flex' || $settings[$key] === 'true';
    }

    if ($legacy_key && array_key_exists($legacy_key, $settings) && $settings[$legacy_key] !== '') {
        return $settings[$legacy_key] === 'flex' || $settings[$legacy_key] === 'true';
    }

    return $fallback === 'flex' || $fallback === 'true';
};
$desktop_navigation = $get_navigation_setting('nav-arrow', '', 'flex');
$laptop_navigation = $get_navigation_setting('nav-arrow_laptop', '', 'flex');
$tablet_navigation = $get_navigation_setting('nav-arrow_tablet', 'nav_arrow_tablet');
$mobile_navigation = $get_navigation_setting('nav-arrow_mobile', 'nav_arrow_mobile');
$show_any_navigation = $desktop_navigation || $laptop_navigation || $tablet_navigation || $mobile_navigation;
$main_card_section_class = 'section-spacing-bottom position-relative streamit-main-card-slider';

?>



<div class="<?php echo esc_attr($main_card_section_class); ?>">
    <header class="streamit-section-header d-flex align-items-center justify-content-between">
        <?php if (!empty($slider_title) && $show_title_flag === 'yes'): ?>
            <<?php echo esc_attr($title_tag); ?> class="streamit-section-title mb-0">
                <?php echo esc_html($slider_title); ?>
            </<?php echo esc_attr($title_tag); ?>>
        <?php endif; ?>

        <?php if (!empty($settings['view_all_switch']) && $settings['view_all_switch'] === 'yes') : ?>
            <div class="streamit-view-all">
                <a href="<?php echo esc_url(streamit_get_permalink($settings['st_select_content_type'], '', $post_filter)); ?>">
                    <?php esc_html_e('View All', 'streamit'); ?>
                </a>
            </div>
        <?php endif; ?>
    </header>
    <?php
    // Map slick_settings (which use slidesToShow) to our data attributes if present
    $desk_num = $settings['desk_number'] ?? ($slick_settings['slidesToShow'] ?? 6);
    $lap_num  = $settings['lap_number']  ?? 4;
    $tab_num  = $settings['tab_number']  ?? 3;
    $mob_num  = $settings['mob_number']  ?? ($slick_settings['responsive'][2]['settings']['slidesToShow'] ?? 2.5);
    ?>
    <div class="swiper js-streamit-slider position-relative" data-type="main-card"
        data-desk="<?php echo esc_attr($desk_num); ?>"
        data-lap="<?php echo esc_attr($lap_num); ?>"
        data-tab="<?php echo esc_attr($tab_num); ?>"
        data-mob="<?php echo esc_attr($mob_num); ?>"
        data-space="<?php echo esc_attr($settings['space_between'] ?? 24); ?>"
        data-space-mob="<?php echo esc_attr($settings['space_between_mobile'] ?? 12); ?>"
        data-loop="<?php echo esc_attr(!empty($settings['infinite']) && $settings['infinite'] === 'true' ? 'true' : 'false'); ?>"
        data-autoplay="<?php echo esc_attr(!empty($settings['autoplay']) && $settings['autoplay'] === 'true' ? 'true' : 'false'); ?>"
        data-delay="<?php echo esc_attr($settings['autoplay_speed'] ?? 2000); ?>"
        data-speed="<?php echo esc_attr($settings['speed'] ?? 300); ?>"
        data-navigation="<?php echo esc_attr($desktop_navigation ? 'true' : 'false'); ?>"
        data-navigation-laptop="<?php echo esc_attr($laptop_navigation ? 'true' : 'false'); ?>"
        data-navigation-tablet="<?php echo esc_attr($tablet_navigation ? 'true' : 'false'); ?>"
        data-navigation-mobile="<?php echo esc_attr($mobile_navigation ? 'true' : 'false'); ?>"
        data-pagination="true">

        <div class="swiper-wrapper">

            <?php foreach ($post_data as $index => $post):

                if (!is_object($post) || !method_exists($post, 'get_meta') || !method_exists($post, 'get_post_type')) {
                    continue;
                }


                $post_type = sanitize_text_field($post->get_post_type());
                $post_id = (int) $post->get_id();
                $post_title = esc_html($post->get_post_title());
                $post_slug = sanitize_title($post->get_post_name());
                $base_permalink = esc_url(streamit_get_permalink($post_type, $post_slug));

                $image_id = $post->get_meta('_portrait_thumbmail');

                $image_html = streamit_render_image([
                    'attachment_id' => $image_id,
                    'class' => 'img-fluid object-cover w-100 border-0',
                    'alt' => esc_attr($post_title),
                    'loading' => $index === 0 ? 'eager' : 'lazy',
                    'fetchpriority' => $index === 0 ? 'high' : 'auto',
                    'decoding' => 'async',
                ]);

                static $taxonomy_map = [
                'movie' => 'movie_genre',
                'tvshow' => 'tvshow_genre',
                'tv_show' => 'tvshow_genre',
                'video' => 'video_category',
                ];
                $taxonomy = $taxonomy_map[$post_type] ?? 'video_category';

                $terms_data = [];
                $terms_ids = streamit_get_term_relationships($post_id, $taxonomy);
                if (!empty($terms_ids)) {
                    $terms = streamit_get_terms(['include' => $terms_ids, 'per_page' => 2]);
                    if (!is_wp_error($terms)) {
                        $terms_data = $terms->results ?? [];
                    }
                }

                $runtime = st_format_runtime($post->get_meta("_{$post_type}_run_time"));
                $runtime_html = !empty($runtime) ? '<small>' . esc_html($runtime) . '</small>' : '';

                $language_meta = $post->get_meta('_language');
                $language_html = '';
                if (!empty($language_meta['labels'])) {
                    $languages = array_slice($language_meta['labels'], 0, 2);
                    $extra = count($language_meta['labels']) - 2;
                    $lang_text = esc_html(implode(', ', $languages));
                    if ($extra > 0) {
                        $lang_text .= ' +' . esc_html($extra);
                    }
                    $language_html = st_get_icon('translate') . '<small>' . $lang_text . '</small>';
                }

                // Upcoming & badges
                $upcoming = function_exists('streamit_is_upcoming') ? streamit_is_upcoming($post, $post_type) : [
                    'is_upcoming' => false,
                    'is_future_release' => false,
                    'formatted_date' => ''
                ];
                $is_upcoming = !empty($upcoming['is_upcoming']) && !empty($upcoming['is_future_release']);

                $badge = streamit_get_access_badge_for_user($post);

                $render_badges = static function ($badge, $is_upcoming = false) use ($enable_upcoming_badges, $enable_premium_badges) {

                    if ($is_upcoming && !empty($enable_upcoming_badges)) {
                        echo '<span class="streamit-badge-upcoming">'
                            . esc_html__('Coming Soon', 'streamit') . '</span>';
                    }

                    if (empty($badge) || empty($enable_premium_badges))
                        return;

                    if (!empty($badge['is_premium_icon'])) {
                        echo '<span class="streamit-badge-premium">'
                            . st_get_icon('premium') . '</span>';
                    }
                    if (!empty($badge['is_rent_icon'])) {
                        echo '<span class="streamit-badge-ppv">'
                            . st_get_icon('rent') . '</span>';
                    }
                    if (!empty($badge['is_rented_icon'])) {
                        echo '<span class="streamit-badge-ppv-rented">'
                            . st_get_icon('rented') . '</span>';
                    }
                };
                /**
                 * Determine final Play Now link:
                 * - If upcoming → always normal permalink
                 * - If premium or rent (locked content) → normal permalink (user cannot access directly)
                 * - If rented or free (accessible) → redirect to /player
                 */
                if (!$is_upcoming && ($post_slug == 'tvshow')) {
                    if ($is_rented || (!$is_premium && !$is_rent)) {
                        // Free content or rented content → redirect to player
                        $base_permalink = esc_url(streamit_get_permalink($post_type, trailingslashit($post_slug) . 'player'));
                    }
                }
                ?>

                <article class="swiper-slide streamit-card streamit-card-portrait">

                    <div class="css_prefix-card">
                        <!-- Image -->
                        <div class="block-images position-relative w-100">
                            <a href="<?php echo $base_permalink; ?>" class="image-box w-100">
                                <?php echo $image_html; ?>
                                <?php $render_badges($badge, $is_upcoming); ?>
                            </a>
                        </div>

                        <!-- Description -->
                        <div class="card-description with-transition">
                            <!-- Terms -->
                            <?php if (!empty($terms_data)): ?>
                                <ul class="genres-list p-0 mb-2 d-flex flex-wrap align-items-center">
                                    <?php foreach ($terms_data as $term): ?>
                                        <li>
                                            <a
                                                href="<?php echo esc_url(streamit_get_permalink($taxonomy, $term->get_term_slug())); ?>">
                                                <?php echo esc_html($term->get_term_name()); ?>
                                            </a>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                            <!-- Title -->
                            <h5 class="css_prefix-title text-capitalize line-count-1">
                                <a href="<?php echo $base_permalink; ?>">
                                    <?php echo $post_title; ?>
                                </a>
                            </h5>
                            <!-- Runtime and Language -->
                            <div class="d-flex flex-wrap align-items-center gap-2">
                                <?php echo $runtime_html; ?>
                                <?php echo $language_html; ?>
                            </div>
                            <!-- Play Button -->
                            <div class="css-prefix-play-button d-flex flex-wrap align-items-center gap-2 mt-2">

                                <?php echo do_shortcode('[streamit_watchlist_shortcode post_id="' . esc_attr($post_id) . '" post_type="' . esc_attr($post_type) . '" is_button="false"]'); ?>
                                <div>
                                    <a href="<?php echo esc_url($base_permalink); ?>" class="btn btn-primary w-100">
                                        <?php echo esc_html($settings['play_now_text'] ?? __('Play Now', 'streamit')); ?>
                                    </a>
                                </div>

                            </div>

                        </div>

                    </div>

                </article>

            <?php endforeach; ?>

        </div>

    </div>

    <?php if ($show_any_navigation): ?>
        <button class="swiper-arrow swiper-button-prev js-swiper-prev" aria-label="Previous">
            <i class="icon-arrow-left"></i>
        </button>

        <button class="swiper-arrow swiper-button-next js-swiper-next" aria-label="Next">
            <i class="icon-arrow-right"></i>
        </button>
    <?php endif; ?>

    <div class="swiper-pagination"></div>

</div>
