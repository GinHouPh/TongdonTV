<?php
if (!defined('ABSPATH'))
    exit;
if (is_wp_error($post_data) || empty($post_data))
    return;

global $streamit_options;

$enable_premium_badges =
    (!empty($enable_premium_badges) && $enable_premium_badges === 'yes') &&
    (!isset($streamit_options['streamit_recommended_enable_premium_badges']) ||
        $streamit_options['streamit_recommended_enable_premium_badges'] === 'yes');

$enable_upcoming_badges =
    ($streamit_options['streamit_recommended_enable_upcoming_badges'] === 'yes');
$get_navigation_setting = static function (string $key, string $legacy_key = '', string $fallback = 'flex') use ($settings): bool {
    if (array_key_exists($key, $settings) && $settings[$key] !== '') {
        return $settings[$key] === 'flex' || $settings[$key] === 'true';
    }

    if ($legacy_key && array_key_exists($legacy_key, $settings) && $settings[$legacy_key] !== '') {
        return $settings[$legacy_key] === 'flex' || $settings[$legacy_key] === 'true';
    }

    return $fallback === 'flex' || $fallback === 'true';
};
$desktop_navigation = $get_navigation_setting('nav-arrow', '', 'flex');
$laptop_navigation = $get_navigation_setting('nav-arrow_laptop', '', 'flex');
$tablet_navigation = $get_navigation_setting('nav-arrow_tablet', 'nav_arrow_tablet');
$mobile_navigation = $get_navigation_setting('nav-arrow_mobile', 'nav_arrow_mobile');
$show_any_navigation = $desktop_navigation || $laptop_navigation || $tablet_navigation || $mobile_navigation;
?>

<section class="streamit-slider-section section-spacing-bottom position-relative streamit-main-card-slider">


    <?php if (!empty($slider_title) || !empty($settings['view_all_switch'])): ?>

        <header class="streamit-section-header d-flex align-items-center justify-content-between">
            <?php if (!empty($slider_title)): ?>
                <<?php echo esc_attr($title_tag); ?>
                    class="streamit-section-title mb-0">
                    <?php echo esc_html($slider_title); ?>
                </<?php echo esc_attr($title_tag); ?>>
            <?php endif; ?>

            <?php if (!empty($settings['view_all_switch']) && $settings['view_all_switch'] === 'yes'): ?>
                <a class="streamit-slider-viewall"
                    href="<?php echo esc_url(streamit_get_permalink($settings['st_select_content_type'], '', $post_filter)); ?>">
                    <?php esc_html_e('View All', 'streamit'); ?>
                </a>
            <?php endif; ?>
        </header>

    <?php endif; ?>


    <div class="swiper js-streamit-slider streamit-slider-landscape" data-type="main-card"
        data-desk="<?php echo esc_attr($settings['desk_number'] ?? 6); ?>"
        data-lap="<?php echo esc_attr($settings['lap_number'] ?? 4); ?>"
        data-tab="<?php echo esc_attr($settings['tab_number'] ?? 3); ?>"
        data-mob="<?php echo esc_attr($settings['mob_number'] ?? 2); ?>"
        data-loop="<?php echo esc_attr(!empty($settings['infinite']) && $settings['infinite'] === 'true' ? 'true' : 'false'); ?>"
        data-autoplay="<?php echo esc_attr(!empty($settings['autoplay']) && $settings['autoplay'] === 'true' ? 'true' : 'false'); ?>"
        data-delay="<?php echo esc_attr($settings['autoplay_speed'] ?? 2000); ?>"
        data-speed="<?php echo esc_attr($settings['speed'] ?? 300); ?>"
        data-navigation="<?php echo esc_attr($desktop_navigation ? 'true' : 'false'); ?>"
        data-navigation-laptop="<?php echo esc_attr($laptop_navigation ? 'true' : 'false'); ?>"
        data-navigation-tablet="<?php echo esc_attr($tablet_navigation ? 'true' : 'false'); ?>"
        data-navigation-mobile="<?php echo esc_attr($mobile_navigation ? 'true' : 'false'); ?>"
        data-pagination="true">

        <div class="swiper-wrapper">

            <?php foreach ($post_data as $index => $post):

                if (!is_object($post) || !method_exists($post, 'get_meta'))
                    continue;

                $post_id = $post->get_id();
                $post_type = sanitize_text_field($post->get_post_type());
                $post_name = esc_attr($post->get_post_name());
                $post_slug = sanitize_title($post->get_post_name());
                $post_title = esc_html($post->get_post_title());

                $permalink = esc_url(streamit_get_permalink($post_type, $post_name));

                $image_id = $post->get_meta('thumbnail_id');

                $image_html = streamit_render_image([
                    'attachment_id' => $image_id,
                    'class' => 'streamit-card-image',
                    'alt' => $post_title,
                    'loading' => $index === 0 ? 'eager' : 'lazy',
                    'decoding' => 'async',
                ]);

                /* taxonomy */
                $taxonomy_map = [
                    'movie' => 'movie_genre',
                    'tvshow' => 'tvshow_genre',
                    'tv_show' => 'tvshow_genre',
                    'video' => 'video_category'
                ];

                $taxonomy = $taxonomy_map[$post_type] ?? 'video_category';

                $terms_ids = streamit_get_term_relationships($post_id, $taxonomy);

                $terms_data = !empty($terms_ids)
                    ? streamit_get_terms([
                        'include' => $terms_ids,
                        'per_page' => 2
                    ])->results
                    : [];

                /* runtime */
                $runtime = st_format_runtime(
                    $post->get_meta("_{$post_type}_run_time")
                );

                /* language */
                $language_meta = $post->get_meta('_language');
                $language_html = '';

                if (!empty($language_meta['labels'])) {
                    $languages = array_slice($language_meta['labels'], 0, 2);

                    $language_html =
                        st_get_icon('translate') .
                        '<small>' .
                        esc_html(implode(', ', $languages)) .
                        '</small>';
                }

                /**
                 * Upcoming status and access badge
                 */
                $upcoming = function_exists('streamit_is_upcoming') ? streamit_is_upcoming($post, $post_type) : [
                    'is_upcoming' => false,
                    'is_future_release' => false,
                    'formatted_date' => ''
                ];
                $is_upcoming = $upcoming['is_upcoming'] && $upcoming['is_future_release'];




                $play_link = esc_url(
                    streamit_get_permalink($post_type, $post_name)
                );


                // Final Play Now logic
                if (!$is_upcoming && ($post_slug == 'tvshow')) {
                    if ($is_rented || (!$is_premium && !$is_rent && empty($badge))) {
                        // Free or rented content → direct to player page
                        $play_link = esc_url(streamit_get_permalink($post_type, trailingslashit($post_name) . 'player'));
                    }
                }

                $badge = streamit_get_access_badge_for_user($post);
                /**
                 * Build badges
                 */
                $badge_html = '';

                if ($is_upcoming && $enable_upcoming_badges) {
                    $badge_html .= sprintf(
                        '<span class="streamit-badge-upcoming">%s</span>',
                        esc_html__('Coming Soon', 'streamit')
                    );
                }

                if (!empty($badge) && $enable_premium_badges) {
                    if (!empty($badge['is_premium_icon'])) {
                        $badge_html .= sprintf(
                            '<span class="streamit-badge-premium" title="%s">%s</span>',
                            esc_attr($badge['premium_title']),
                            st_get_icon('premium')
                        );
                    }

                    if (!empty($badge['is_rent_icon'])) {
                        $badge_html .= sprintf(
                            '<span class="streamit-badge-ppv" title="%s">%s</span>',
                            esc_attr($badge['rent_title']),
                            st_get_icon('rent')
                        );
                    }

                    if (!empty($badge['is_rented_icon'])) {
                        $badge_html .= sprintf(
                            '<span class="streamit-badge-ppv-rented" title="%s">%s</span>',
                            esc_attr($badge['rent_title']),
                            st_get_icon('rented')
                        );
                    }
                }



                ?>

                <article class="swiper-slide streamit-card streamit-card-landscape">
                    <div class="css_prefix-card landscape-card">
                        <figure class="block-images position-relative w-100 cursor-pointer">

                            <a href="<?php echo $permalink; ?>" class="color-inherit image-box w-100"
                                aria-label="<?php echo esc_attr($post_title); ?>">

                                <?php echo $image_html; ?>

                                <?php echo $badge_html; ?>

                            </a>

                        </figure>

                        <!-- Description -->
                        <div class="card-description with-transition">

                            <?php if (!empty($terms_data)): ?>
                                <!-- Terms -->
                                <ul class="genres-list p-0 mb-2 d-flex flex-wrap align-items-center">

                                    <?php foreach ($terms_data as $term): ?>

                                        <li>

                                            <a href="<?php echo esc_url(
                                                streamit_get_permalink(
                                                    $taxonomy,
                                                    $term->get_term_slug()
                                                )
                                            ); ?>">

                                                <?php echo esc_html(
                                                    $term->get_term_name()
                                                ); ?>

                                            </a>

                                        </li>

                                    <?php endforeach; ?>

                                </ul>

                            <?php endif; ?>

                            <!-- Title -->
                            <h5 class="css_prefix-title text-capitalize line-count-1">

                                <a href="<?php echo $permalink; ?>">

                                    <?php echo $post_title; ?>

                                </a>

                            </h5>

                            <!-- Runtime and Language -->
                            <div class="d-flex flex-wrap align-items-center gap-2">

                                <?php if ($runtime): ?>

                                    <span class="streamit-runtime">

                                        <?php echo esc_html($runtime); ?>

                                    </span>

                                <?php endif; ?>

                                <?php echo $language_html; ?>

                            </div>


                            <div class="css-prefix-play-button d-flex flex-wrap align-items-center gap-2 mt-2">

                                <?php echo do_shortcode(
                                    '[streamit_watchlist_shortcode post_id="' .
                                    esc_attr($post_id) .
                                    '" post_type="' .
                                    esc_attr($post_type) .
                                    '" is_button="false"]'
                                ); ?>

                                <div>
                                    <a href="<?php echo $play_link; ?>" class="btn btn-primary w-100">

                                        <?php echo esc_html(
                                            $settings['play_now_text']
                                        ); ?>

                                    </a>
                                </div>

                            </div>

                        </div>
                    </div>

                </article>

            <?php endforeach; ?>

        </div>

    </div>

    <?php if ($show_any_navigation): ?>

        <button class="swiper-arrow swiper-button-prev PreArrow-two js-swiper-prev" aria-label="Previous">
            <i class="icon-arrow-left"></i>
        </button>

        <button class="swiper-arrow swiper-button-next NextArrow-two js-swiper-next" aria-label="Next">
            <i class="icon-arrow-right"></i>
        </button>

    <?php endif; ?>

    <div class="swiper-pagination"></div>

</section>
