<?php

/**
 * Streamit product Banner Template
 * 
 * @package Streamit
 */

if (!defined('ABSPATH'))
    exit;
if (!class_exists('WooCommerce'))
    return;

$get_navigation_setting = static function (string $key, string $legacy_key = '', string $fallback = 'flex') use ($settings): bool {
    if (array_key_exists($key, $settings) && $settings[$key] !== '') {
        return $settings[$key] === 'flex' || $settings[$key] === 'true';
    }

    if ($legacy_key && array_key_exists($legacy_key, $settings) && $settings[$legacy_key] !== '') {
        return $settings[$legacy_key] === 'flex' || $settings[$legacy_key] === 'true';
    }

    return $fallback === 'flex' || $fallback === 'true';
};
$desktop_navigation = $get_navigation_setting('nav-arrow', '', 'flex');
$laptop_navigation = $get_navigation_setting('nav-arrow_laptop', '', 'flex');
$tablet_navigation = $get_navigation_setting('nav-arrow_tablet', 'nav_arrow_tablet');
$mobile_navigation = $get_navigation_setting('nav-arrow_mobile', 'nav_arrow_mobile');
$show_navigation = $desktop_navigation || $laptop_navigation || $tablet_navigation || $mobile_navigation;

?>
<section class="css_prefix-main-slider p-0 css_prefix-rtl-direction css_prefix-product-banner-slider streamit-responsive-arrow-widget">

    <div id="<?php echo esc_attr('product-slider-' . $id_int); ?>"
        data-rand="<?php echo esc_attr('product-slider-' . $id_int); ?>"
        class="swiper js-streamit-slider product-slider" data-type="product-slider" data-slides="1" data-lap="1"
        data-tab="1" data-mob="1" data-loop="<?php echo esc_attr(
            !empty($settings['infinite']) &&
            $settings['infinite'] === 'true'
            ? 'true' : 'false'
        ); ?>" data-autoplay="<?php echo esc_attr(
             !empty($settings['autoplay']) &&
             $settings['autoplay'] === 'true'
             ? 'true' : 'false'
         ); ?>" data-delay="<?php echo esc_attr(
              $settings['autoplay_speed'] ?? 2000
          ); ?>" data-speed="<?php echo esc_attr(
               $settings['speed'] ?? 500
           ); ?>" data-navigation="<?php echo esc_attr(
                $desktop_navigation ? 'true' : 'false'
            ); ?>" data-navigation-laptop="<?php echo esc_attr(
                $laptop_navigation ? 'true' : 'false'
            ); ?>" data-navigation-tablet="<?php echo esc_attr(
                $tablet_navigation ? 'true' : 'false'
            ); ?>" data-navigation-mobile="<?php echo esc_attr(
                $mobile_navigation ? 'true' : 'false'
            ); ?>" data-pagination=" false">

        <div class="swiper-wrapper">
            <?php
            foreach ($args['post_data'] as $index => $item):
                $href = '';
                if ($item['link_type'] == 'dynamic') {
                    if ($item['link_by'] == 'category') {
                        $href = get_term_link($item['dynamic_link_by_cat'], 'product_cat');
                    } else {
                        $product = get_page_by_path($item['dynamic_link'], OBJECT, 'product');
                        $href = get_permalink(isset($product->ID) ? $product->ID : 0);
                    }
                } else {
                    $href = $item['link']['url'];
                }
                ?>
                <article class="swiper-slide">
                    <a href="<?php echo esc_url($href) ?>" class="slick-item">
                        <figure
                            class="elementor-repeater-item-<?php echo esc_attr($item['_id']) ?> slide slick-bg css_prefix-align-"
                            style="background-image:url('')">
                            <?php echo \Elementor\Group_Control_Image_Size::get_attachment_image_html($item, 'full', 'slider_image'); ?>
                        </figure>
                    </a>
                </article>
                <?php
            endforeach;
            ?>
        </div>
    </div>

    <?php if ($show_navigation): ?>
        <button class="swiper-arrow swiper-button-prev js-swiper-prev" aria-label="Previous">
            <i class="icon-arrow-left"></i>
        </button>
        <button class="swiper-arrow swiper-button-next js-swiper-next" aria-label="Next">
            <i class="icon-arrow-right"></i>
        </button>
    <?php endif; ?>
</section>
