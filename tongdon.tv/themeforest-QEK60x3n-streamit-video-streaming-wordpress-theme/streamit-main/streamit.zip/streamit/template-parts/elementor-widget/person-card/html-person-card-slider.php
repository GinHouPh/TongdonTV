<?php
if (!defined('ABSPATH'))
    exit;

$get_navigation_setting = static function (string $key, string $legacy_key = '', string $fallback = 'flex') use ($settings): bool {
    if (array_key_exists($key, $settings) && $settings[$key] !== '') {
        return $settings[$key] === 'flex' || $settings[$key] === 'true';
    }

    if ($legacy_key && array_key_exists($legacy_key, $settings) && $settings[$legacy_key] !== '') {
        return $settings[$legacy_key] === 'flex' || $settings[$legacy_key] === 'true';
    }

    return $fallback === 'flex' || $fallback === 'true';
};
$desktop_navigation = $get_navigation_setting('nav-arrow', '', 'flex');
$laptop_navigation = $get_navigation_setting('nav-arrow_laptop', '', 'flex');
$tablet_navigation = $get_navigation_setting('nav-arrow_tablet', 'nav_arrow_tablet');
$mobile_navigation = $get_navigation_setting('nav-arrow_mobile', 'nav_arrow_mobile');
$show_navigation = $desktop_navigation || $laptop_navigation || $tablet_navigation || $mobile_navigation;
?>

<section class="streamit-person-section streamit-person-slider section-spacing-bottom position-relative">

    <?php if (!empty($slider_title)) : ?>
    <header class="streamit-section-header d-flex justify-content-between align-items-center mb-4">
            <<?php echo esc_attr($title_tag); ?> class="streamit-section-title mb-0">
                <?php echo esc_html($slider_title); ?>
            </<?php echo esc_attr($title_tag); ?>>

            <?php if (!empty($settings['use_custom_link_text'])) : ?>
                <a class="streamit-view-all"
                href="<?php echo esc_url($view_all_url); ?>">
                    <?php echo esc_html($settings['use_custom_link_text']); ?>
                </a>
            <?php endif; ?>
    </header>
    <?php endif; ?>


    <div class="swiper js-streamit-slider" data-type="person-card"
        data-slides="<?php echo esc_attr(!empty($settings['desk_number']) ? $settings['desk_number'] : 12); ?>"
        data-lap="<?php echo esc_attr(!empty($settings['lap_number']) ? $settings['lap_number'] : 6); ?>"
        data-tab="<?php echo esc_attr(!empty($settings['tab_number']) ? $settings['tab_number'] : 4); ?>"
        data-mob="<?php echo esc_attr(!empty($settings['mob_number']) ? $settings['mob_number'] : 3); ?>"
        data-loop="<?php echo esc_attr($settings['infinite'] ?? 'false'); ?>"
        data-autoplay="<?php echo esc_attr($settings['autoplay'] ?? 'false'); ?>"
        data-delay="<?php echo esc_attr($settings['autoplay_speed'] ?? 2000); ?>"
        data-speed="<?php echo esc_attr($settings['speed'] ?? 300); ?>"
        data-navigation="<?php echo esc_attr($desktop_navigation ? 'true' : 'false'); ?>"
        data-navigation-laptop="<?php echo esc_attr($laptop_navigation ? 'true' : 'false'); ?>"
        data-navigation-tablet="<?php echo esc_attr($tablet_navigation ? 'true' : 'false'); ?>"
        data-navigation-mobile="<?php echo esc_attr($mobile_navigation ? 'true' : 'false'); ?>"
        data-pagination="false">

        <div class="swiper-wrapper">

            <?php foreach ($results as $index => $details):

                $person = $details['data'] ?? null;
                if (!$person)
                    continue;

                $id = $person->get_id();
                $slug = $person->get_post_name();
                $type = $person->get_post_type();
                $name = esc_html($person->get_post_title());

                $url =
                    streamit_get_permalink($type, $slug);

                $image =
                    streamit_render_image([
                        'attachment_id' => $person->get_meta('thumbnail_id'),
                        'class' => 'img-fluid w-100',
                        'alt' => $name,
                        'loading' => $index < 4 ? 'eager' : 'lazy',
                        'decoding' => 'async'
                    ]);

                $terms =
                    streamit_get_terms([
                        'include' => streamit_get_term_relationships($id, 'person_category'),
                        'per_page' => 2
                    ])->results ?? [];
                ?>

            <article class="swiper-slide">

                <div class="streamit-person-card text-center">

                    <figure class="streamit-person-media mb-2">

                        <a href="<?php echo esc_url($url); ?>"
                        aria-label="<?php echo esc_attr($name); ?>">

                            <?php echo $image; ?>

                        </a>

                    </figure>

                    <div class="streamit-person-detail">
                        <h3 class="streamit-person-name h6 mb-1">

                            <a href="<?php echo esc_url($url); ?>" class="color-inherit">
                                <?php echo $name; ?>
                            </a>

                        </h3>

                        <?php if(!empty($terms)): ?>
                            <ul class="streamit-person-meta list-inline small mb-0">

                                <?php foreach($terms as $term): ?>

                                <li class="list-inline-item">

                                    <a href="<?php echo esc_url(
                                        streamit_get_permalink(
                                            'person_category',
                                            $term->get_term_slug()
                                        )
                                    ); ?>" class="color-inherit">
                                        <?php echo esc_html($term->get_term_name()); ?>
                                    </a>

                                </li>

                                <?php endforeach; ?>

                            </ul>
                        <?php endif; ?>
                    </div>
                </div>

                </article>

            <?php endforeach; ?>

        </div>

        </div> 
        <?php if ($show_navigation): ?>

            <button class="swiper-arrow swiper-button-prev js-swiper-prev" data-person-nav="prev" aria-label="Previous">
                <i class="icon-arrow-left"></i>
            </button>

            <button class="swiper-arrow swiper-button-next js-swiper-next" data-person-nav="next" aria-label="Next">
                <i class="icon-arrow-right"></i>
                </button> 
        <?php endif; ?>

</section>
