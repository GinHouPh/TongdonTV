<?php
if (!defined('ABSPATH'))
    exit;
if (empty($results))
    return;

$columns = !empty($settings['iq_columns']) ? (int) $settings['iq_columns'] : 4;
$lg_col = $columns;
?>

<section class="streamit-person-section streamit-person-grid">

    <?php if (!empty($slider_title) || !empty($settings['use_custom_link_text'])): ?>

        <header class="streamit-section-header d-flex justify-content-between align-items-center mb-4">

            <?php if (!empty($slider_title)): ?>

                <<?php echo esc_attr($title_tag ?? 'h4'); ?>
                    class="streamit-section-title mb-0">

                    <?php echo esc_html($slider_title); ?>

                </<?php echo esc_attr($title_tag ?? 'h3'); ?>>

            <?php endif; ?>


            <?php if (!empty($settings['use_custom_link_text'])): ?>

                <a class="streamit-view-all color-inherit" href="<?php echo esc_url($view_all_url ?? streamit_get_permalink('person')); ?>">

                    <?php echo esc_html($settings['use_custom_link_text']); ?>

                </a>

            <?php endif; ?>

        </header>

    <?php endif; ?>


    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-<?php echo esc_attr($lg_col); ?> g-4">

        <?php foreach ($results as $index => $details):

            $person = $details['data'] ?? null;
            if (!$person)
                continue;

            $id = $person->get_id();
            $slug = $person->get_post_name();
            $type = $person->get_post_type();
            $name = esc_html($person->get_post_title());

            $url = streamit_get_permalink($type, $slug);

            $image = streamit_render_image([
                'attachment_id' => $person->get_meta('thumbnail_id'),
                'class' => 'img-fluid w-100',
                'alt' => $name,
                'loading' => $index < 4 ? 'eager' : 'lazy',
                'decoding' => 'async'
            ]);

            // Get categories (max 2)
            $terms_data = streamit_get_terms([
                'include' => streamit_get_term_relationships($id, 'person_category'),
                'per_page' => 2
            ])->results ?? [];

            ?>

                <div class="col">

                    <article class="streamit-person-card h-100 text-center">
                        <figure class="streamit-person-media">

                            <a href="<?php echo esc_url($url); ?>" aria-label="<?php echo esc_attr($name); ?>">
                                <?php echo $image; ?>

                            </a>

                        </figure>

                        <div class="streamit-person-detail">
                            <h3 class="streamit-person-name h6 mb-1">
                                <a href="<?php echo esc_url($url); ?>" class="color-inherit">
                                    <?php echo $name; ?>

                                </a>

                            </h3>

                            <?php if (!empty($details['character'])): ?>
                                    <p class="streamit-person-character small text-muted mb-1">
                                        <?php echo esc_html($details['character']); ?>
                                    </p>
                            <?php endif; ?>


                        <?php if (!empty($terms_data)): ?>

                                <ul class="streamit-person-meta list-inline small mb-0">

                                    <?php foreach ($terms_data as $term): ?>

                                                <li class="list-inline-item">

                                                    <a href="<?php echo esc_url(
                                                        streamit_get_permalink(
                                                            'person_category',
                                                            $term->get_term_slug()
                                                        )
                                                    ); ?>" class="text-muted">

                                                        <?php echo esc_html(
                                                            $term->get_term_name()
                                                        ); ?>

                                                    </a>

                                                </li>

                                        <?php endforeach; ?>

                                    </ul>

                            <?php endif; ?>

                        </div>

                    </article>

                </div>

        <?php endforeach; ?>

    </div>

</section>