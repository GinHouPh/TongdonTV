
<?php
$get_navigation_setting = static function (string $key, string $legacy_key = '', string $fallback = 'flex') use ($settings): bool {
    if (array_key_exists($key, $settings) && $settings[$key] !== '') {
        return $settings[$key] === 'flex' || $settings[$key] === 'true';
    }

    if ($legacy_key && array_key_exists($legacy_key, $settings) && $settings[$legacy_key] !== '') {
        return $settings[$legacy_key] === 'flex' || $settings[$legacy_key] === 'true';
    }

    return $fallback === 'flex' || $fallback === 'true';
};
$desktop_navigation = $get_navigation_setting('nav-arrow', '', 'flex');
$laptop_navigation = $get_navigation_setting('nav-arrow_laptop', '', 'flex');
$tablet_navigation = $get_navigation_setting('nav-arrow_tablet', 'nav_arrow_tablet');
$mobile_navigation = $get_navigation_setting('nav-arrow_mobile', 'nav_arrow_mobile');
$show_navigation = $desktop_navigation || $laptop_navigation || $tablet_navigation || $mobile_navigation;
?>

<section class="css_prefix-tvshow-season-parent css_prefix-rtl-direction streamit-responsive-arrow-widget">



    <!-- Main TV Show Slider -->
    <div class="swiper js-streamit-slider streamit-tvshow-season-slider" data-type="tvshow-season"
        data-loop="<?php echo esc_attr(!empty($settings['infinite']) && $settings['infinite'] === 'true' ? 'true' : 'false'); ?>"
        data-speed="<?php echo esc_attr(!empty($settings['speed']) ? intval($settings['speed']) : 300); ?>"
        data-navigation="<?php echo esc_attr($desktop_navigation ? 'true' : 'false'); ?>"
        data-navigation-laptop="<?php echo esc_attr($laptop_navigation ? 'true' : 'false'); ?>"
        data-navigation-tablet="<?php echo esc_attr($tablet_navigation ? 'true' : 'false'); ?>"
        data-navigation-mobile="<?php echo esc_attr($mobile_navigation ? 'true' : 'false'); ?>">

        <div class="swiper-wrapper">

            <?php
            $rank = 1;
            $all_posts = $post_data;
            foreach ($post_data as $post):
                $post_id = $post->get_id();
                $post_type = $post->get_post_type();
                $post_name = $post->get_post_name();
                $post_title = $post->get_post_title();
                $post_excerpt = $post->get_post_excerpt();
                $year = date_i18n('F Y', strtotime($post->get_post_date()));
                $thumbnail_id = $post->get_meta('thumbnail_id');

                $seasons = (array) $post->get_meta('_seasons');
                $season_display = !empty($seasons)
                    ? sprintf('%d %s', count($seasons), _n('Season', 'Seasons', count($seasons), 'streamit'))
                    : esc_html__('Arriving Soon', 'streamit');
                ?>

                <article
                    class="swiper-slide css_prefix-thumb-items css_prefix-tvshow home-slider tvshow-<?php echo esc_attr($post_id); ?>"
                    data-post="<?php echo esc_attr($post_id); ?>"
                    data-seasons='<?php echo esc_attr(wp_json_encode($seasons)); ?>'>

                    <figure class="tvshow-bg" aria-label="<?php echo esc_attr($post_title); ?>">

                        <?php
                        $landscape_url = wp_get_attachment_image_url($thumbnail_id, 'full') ?: streamit_placeholder_image();
                        $portrait_id = $post->get_meta('_portrait_thumbmail');
                        $portrait_url = $portrait_id ? wp_get_attachment_image_url($portrait_id, 'full') : $landscape_url;
                        ?>
                        <picture class="banner-img position-absolute top-0 start-0 w-100 h-100">
                            <source media="(max-width: 1024px)" srcset="<?php echo esc_url($portrait_url); ?>">
                            <img src="<?php echo esc_url($landscape_url); ?>" class="object-fit-cover w-100 h-100" alt="<?php echo esc_attr($post_title); ?>" loading="eager" fetchpriority="high" decoding="async">
                        </picture>

                        <div class="thumbnail-list-wrapper">
                            <div class="css_prefix-tvshow-details">

                                <?php if (!empty($settings['trending_top_img']['url'])):
                                    $alt = !empty($settings['trending_top_img']['alt']) ? esc_attr($settings['trending_top_img']['alt']) : 'Image';
                                    ?>
                                    <div class="series d-flex align-items-center gap-2 mb-3 RightAnimate">
                                        <?php
                                        echo wp_get_attachment_image(
                                            attachment_url_to_postid($settings['trending_top_img']['url']),
                                            'full',
                                            false,
                                            ['class' => 'img-fluid', 'alt' => $alt, 'decoding' => 'async']
                                        );
                                        ?>
                                        <span
                                            class="text-gold"><?php printf(esc_html__('#%d in Series Today', 'streamit'), $rank); ?></span>
                                    </div>
                                <?php endif; ?>

                                <header>
                                    <h2 class="slider-text texture-text line-count-2 RightAnimate-two">
                                        <?php echo esc_html($post_title); ?></h2>
                                </header>

                                <p class="season-excerpt line-count-2 mb-3 RightAnimate-three">
                                    <?php echo esc_html($post_excerpt); ?></p>

                                <footer
                                    class="css_prefix-tvshow-detail-meta text-detail d-flex align-items-center gap-5 RightAnimate-four">
                                    <time class="trending-year"
                                        datetime="<?php echo esc_attr($year); ?>"><?php echo esc_html($year); ?></time>
                                    <span class="season_date"><?php echo esc_html($season_display); ?></span>
                                </footer>

                                <div class="RightAnimate-four mt-5">
                                    <a class="btn btn-primary"
                                        href="<?php echo esc_url(streamit_get_permalink($post_type, $post_name)); ?>">
                                        <span class="d-flex align-items-center gap-2">
                                            <span><?php echo esc_html($settings['play_now_text']); ?></span>
                                            <i aria-hidden="true" class="icon-play-button ms-2"></i>
                                        </span>
                                    </a>
                                </div>

                            </div>
                        </div>

                    </figure>
                </article>

                <?php
                $rank++;
            endforeach;
            ?>

            </div><!-- .swiper-wrapper -->

        <?php if ($show_navigation): ?>
            <button class="swiper-arrow swiper-button-prev PreArrow-two js-swiper-prev" aria-label="<?php esc_attr_e('Previous', 'streamit'); ?>">
                <i class="icon-arrow-left" aria-hidden="true"></i>
            </button>
            <button class="swiper-arrow swiper-button-next NextArrow-two js-swiper-next" aria-label="<?php esc_attr_e('Next', 'streamit'); ?>">
                <i class="icon-arrow-right" aria-hidden="true"></i>
            </button>
        <?php endif; ?>

        <div class="swiper-pagination"></div>
    </div><!-- .swiper -->

    <!-- Episode Panel (updates on slide change / season tab click) -->
    <div class="css_prefix-wrap-details">
        <?php if (empty($all_posts))
            return;

        $first_tvshow = $all_posts[0];
        $first_showseasons = (array) $first_tvshow->get_meta('_seasons');
        ?>

        <div class="episodes-tab">
            <div class="trending-info align-items-center w-100 animated fadeIn">

                <div class="all-episodes">
                    <h3 class="trending-text mt-0 mb-2"><?php esc_html_e('All Episodes', 'streamit'); ?></h3>
                </div>

                <nav class="nav nav-tabs" aria-label="<?php esc_attr_e('Season Navigation', 'streamit'); ?>">
                    <div class="nav-tabs-inner" data-first_tvshow_id="<?php echo esc_attr($first_tvshow->get_id()); ?>">
                        <?php foreach ($first_showseasons as $index => $val): ?>
                            <a class="nav-item nav-link css_prefix-episodes-meta tvshow-<?php echo esc_attr($first_tvshow->get_id()); ?> <?php echo $index === 0 ? 'active' : ''; ?>"
                                href="#" role="tab" data-tvshow-id="<?php echo esc_attr($first_tvshow->get_id()); ?>"
                                data-season="<?php echo esc_attr($index); ?>" data-ajax-loaded="0"
                                aria-selected="<?php echo $index === 0 ? 'true' : 'false'; ?>">
                                <?php echo isset($val['name']) ? esc_html($val['name']) : ''; ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </nav>

                <!-- Initial season episodes (first season, server-rendered) -->
                <div class="season-content">
                    <?php
                    if (!empty($first_showseasons)):
                        foreach ($first_showseasons as $season_index => $season):
                            if (empty($season['episodes']))
                                continue;

                            $episodes = streamit_get_episodes([
                                'orderby' => 'post__in',
                                'include' => $season['episodes'],
                                'paged' => -1,
                                'per_page' => -1,
                            ])->results;
                            ?>
                            <ul class="season-episodes-details list-unstyled" data-season-index="0"
                                data-tvshow-id="<?php echo esc_attr($first_tvshow->get_id()); ?>">
                                <?php foreach (array_slice($episodes, 0, 5) as $episode):
                                    streamit_get_template('elementor-widget/tv-show-season/episode-item.php', [
                                        'episode' => $episode,
                                        'tvshow_id' => $first_tvshow->get_id(),
                                        'season_index' => 0
                                    ]);
                                endforeach; ?>

                                <?php if (count($episodes) > 5): ?>
                                    <li class="view-all-btn-parent">
                                        <a href="<?php echo esc_url(streamit_get_permalink($first_tvshow->get_post_type(), $first_tvshow->get_post_name())); ?>"
                                            class="season-btn btn btn-sm btn-primary">
                                            <?php echo esc_html($settings['episode_card_text']); ?>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>

                            <?php break; // only first season rendered server-side
                        endforeach;
                    else:
                        echo '<p class="no_data_found">' . esc_html__('No Season Found', 'streamit') . '</p>';
                    endif;
                    ?>
                </div><!-- .season-content -->

            </div>
        </div>
    </div><!-- .css_prefix-wrap-details -->

</section>