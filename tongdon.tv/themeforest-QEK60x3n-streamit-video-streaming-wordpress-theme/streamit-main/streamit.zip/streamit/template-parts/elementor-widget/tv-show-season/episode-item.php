<?php
if (!defined('ABSPATH')) exit;

$episode_id = $episode->get_id();
$episode_number = $episode->get_meta('_episode_number');
$episode_run_time = $episode->get_meta('_episode_run_time');
$permalink = streamit_get_permalink($episode->get_post_type(), $episode->get_post_name());
$title = $episode->get_post_title();

$thumbnail_id = $episode->get_meta('thumbnail_id');

// Handle TV show ID and Season Number classes if present in context or meta
$tvshow_id = isset($tvshow_id) ? $tvshow_id : $episode->get_meta('_tv_show_id');
$season_number = isset($season_index) ? $season_index : (isset($season_number) ? $season_number : $episode->get_meta('_season_index'));

$classes = "episodes-info episode-" . $episode_id;
if (!empty($tvshow_id)) {
    $classes .= " tvshow-" . $tvshow_id;
    if ($season_number !== '' && $season_number !== null) {
        $classes .= "-season-" . ($season_number + 1);
    }
}
?>
<li class="<?php echo esc_attr($classes); ?>">
    <article class="episode-card-content">
        <header class="episode-img">
            <a href="<?php echo esc_url($permalink); ?>" class="color-inherit">
                <?php echo streamit_render_image([
                    'attachment_id' => $thumbnail_id,
                    'class'         => 'post-img',
                    'alt'           => $title,
                ]); ?>
            </a>
        </header>

        <div class="episodes-meta">
            <h6 class="episode-name">
                <a href="<?php echo esc_url($permalink); ?>" class="color-inherit">
                    <?php if ($episode_number !== '') : ?>
                        <span class="episode-number me-2"><?php echo esc_html(str_pad($episode_number, 2, '0', STR_PAD_LEFT)); ?> :</span>
                    <?php endif; ?>
                    <?php echo esc_html($title); ?>
                </a>
            </h6>

            <?php if (!empty($episode_run_time) && $episode_run_time !== '0:00') : ?>
                <div class="episode-time mt-2">
                    <i class="icon-clock"></i>
                    <time datetime="PT<?php echo esc_attr($episode_run_time); ?>M">
                        <?php echo esc_html(st_format_runtime($episode_run_time)); ?>
                    </time>
                </div>
            <?php endif; ?>
        </div>
    </article>
</li>
