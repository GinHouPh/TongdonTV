<?php
if (!defined('ABSPATH'))
    exit;
if (!class_exists('WooCommerce'))
    return;
if (empty($woo_categories))
    return;

$get_navigation_setting = static function (string $key, string $legacy_key = '', string $fallback = 'flex') use ($settings): bool {
    if (array_key_exists($key, $settings) && $settings[$key] !== '') {
        return $settings[$key] === 'flex' || $settings[$key] === 'true';
    }

    if ($legacy_key && array_key_exists($legacy_key, $settings) && $settings[$legacy_key] !== '') {
        return $settings[$legacy_key] === 'flex' || $settings[$legacy_key] === 'true';
    }

    return $fallback === 'flex' || $fallback === 'true';
};
$desktop_navigation = $get_navigation_setting('nav-arrow', '', 'flex');
$laptop_navigation = $get_navigation_setting('nav-arrow_laptop', '', 'flex');
$tablet_navigation = $get_navigation_setting('nav-arrow_tablet', 'nav_arrow_tablet');
$mobile_navigation = $get_navigation_setting('nav-arrow_mobile', 'nav_arrow_mobile');
$show_navigation = $desktop_navigation || $laptop_navigation || $tablet_navigation || $mobile_navigation;
?>

<section class="streamit-category-section streamit-responsive-arrow-widget">


    <div class="swiper js-streamit-slider streamit-category-slider" data-type="product-category"
        data-slides="<?php echo esc_attr($settings['desk_number'] ?? 4); ?>"
        data-lap="<?php echo esc_attr($settings['lap_number'] ?? 3); ?>"
        data-tab="<?php echo esc_attr($settings['tab_number'] ?? 3); ?>"
        data-mob="<?php echo esc_attr($settings['mob_number'] ?? 1); ?>" data-loop="<?php echo esc_attr(
                 $settings['infinite'] === "true" ? "true" : "false"
             ); ?>" data-autoplay="<?php echo esc_attr(
                  $settings['autoplay'] === "true" ? "true" : "false"
              ); ?>" data-delay="<?php echo esc_attr(
                   $settings['autoplay_speed'] ?? 2000
               ); ?>" data-speed="<?php echo esc_attr(
                $settings['speed'] ?? 300
                ); ?>" data-navigation="<?php echo esc_attr(
                     $desktop_navigation ? "true" : "false"
                 ); ?>" data-navigation-laptop="<?php echo esc_attr(
                     $laptop_navigation ? "true" : "false"
                 ); ?>" data-navigation-tablet="<?php echo esc_attr(
                     $tablet_navigation ? "true" : "false"
                 ); ?>" data-navigation-mobile="<?php echo esc_attr(
                     $mobile_navigation ? "true" : "false"
                 ); ?>" data-pagination="false">


        <div class="swiper-wrapper">

            <?php foreach ($woo_categories as $cat):

                if (empty($cat->term_id))
                    continue;

                $link = get_term_link($cat);

                $image_id =
                    get_term_meta(
                        $cat->term_id,
                        'thumbnail_id',
                        true
                    );
                $has_image = !empty($image_id);

                ?>

                <article class="swiper-slide">

                    <div class="streamit-category-card">

                        <a href="<?php echo esc_url($link); ?>" class="streamit-category-link"
                            aria-label="<?php echo esc_attr($cat->name); ?>">

                            <figure class="streamit-category-media">

                                <?php
                                if ($has_image) {
                                    echo streamit_render_image([
                                        'attachment_id' => $image_id,
                                        'class' => 'img-fluid w-100',
                                        'alt' => esc_attr($cat->name),
                                        'loading' => 'lazy',
                                        'decoding' => 'async'
                                    ]);
                                } else {
                                    ?>
                                    <img
                                        src="<?php echo esc_url(streamit_placeholder_image()); ?>"
                                        class="img-fluid w-100"
                                        alt="<?php echo esc_attr($cat->name); ?>"
                                        loading="lazy"
                                        decoding="async">
                                    <?php
                                }
                                ?>

                                <figcaption class="streamit-category-title">

                                    <<?php echo esc_attr(
                                        $settings['title_tag'] ?? 'h5'
                                    ); ?>>

                                        <?php
                                        echo esc_html(
                                            $cat->name
                                        );
                                        ?>

                                    </<?php echo esc_attr(
                                        $settings['title_tag'] ?? 'h5'
                                    ); ?>>

                                </figcaption>

                            </figure>

                        </a>

                    </div>

                </article>

            <?php endforeach; ?>

        </div>


        <?php if ($show_navigation): ?>

            <button class="swiper-arrow swiper-button-prev js-swiper-prev" aria-label="Previous">

                <i class="icon-arrow-left"></i>

            </button>


            <button class="swiper-arrow swiper-button-next js-swiper-next" aria-label="Next">

                <i class="icon-arrow-right"></i>

            </button>

        <?php endif; ?>

    </div>

</section>
