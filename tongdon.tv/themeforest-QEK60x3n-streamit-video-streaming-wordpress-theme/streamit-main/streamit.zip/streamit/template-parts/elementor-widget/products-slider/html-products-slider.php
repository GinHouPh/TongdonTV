<?php

if (!defined('ABSPATH'))
    exit;
if (!class_exists('WooCommerce'))
    return;
$get_navigation_setting = static function (string $key, string $legacy_key = '', string $fallback = 'flex') use ($settings): bool {
    if (array_key_exists($key, $settings) && $settings[$key] !== '') {
        return $settings[$key] === 'flex' || $settings[$key] === 'true';
    }

    if ($legacy_key && array_key_exists($legacy_key, $settings) && $settings[$legacy_key] !== '') {
        return $settings[$legacy_key] === 'flex' || $settings[$legacy_key] === 'true';
    }

    return $fallback === 'flex' || $fallback === 'true';
};
$desktop_navigation = $get_navigation_setting('nav-arrow', '', 'flex');
$laptop_navigation = $get_navigation_setting('nav-arrow_laptop', '', 'flex');
$tablet_navigation = $get_navigation_setting('nav-arrow_tablet', 'nav_arrow_tablet');
$mobile_navigation = $get_navigation_setting('nav-arrow_mobile', 'nav_arrow_mobile');
$show_navigation = $desktop_navigation || $laptop_navigation || $tablet_navigation || $mobile_navigation;
$products_per_page = isset($products_per_page) ? intval($products_per_page) : (isset($settings['woo_per_page']) ? intval($settings['woo_per_page']) : 10);
$desktop_slides = isset($desktop_slides) ? intval($desktop_slides) : (isset($settings['desk_number']) ? intval($settings['desk_number']) : 5);
$laptop_slides = isset($laptop_slides) ? intval($laptop_slides) : (isset($settings['lap_number']) ? intval($settings['lap_number']) : 4);
$tablet_slides = isset($tablet_slides) ? intval($tablet_slides) : (isset($settings['tab_number']) ? intval($settings['tab_number']) : 3);
$mobile_slides = isset($mobile_slides) ? intval($mobile_slides) : (isset($settings['mob_number']) ? intval($settings['mob_number']) : 2);

if (defined('WP_DEBUG') && WP_DEBUG) {
    error_log(
        'Streamit Product Slider Template Debug: ' . wp_json_encode([
            'products_per_page' => $products_per_page,
            'desktop_slides' => $desktop_slides,
            'laptop_slides' => $laptop_slides,
            'tablet_slides' => $tablet_slides,
            'mobile_slides' => $mobile_slides,
            'desktop_navigation' => $desktop_navigation,
            'laptop_navigation' => $laptop_navigation,
            'tablet_navigation' => $tablet_navigation,
            'mobile_navigation' => $mobile_navigation,
        ])
    );
}

$view_all = '';
if (!empty($settings['view_all_switch']) && $settings['view_all_switch'] === 'yes') {
    $st_class = 'class="st-view-all"';
    if (!empty($settings['use_custom_link_viewall']) && $settings['use_custom_link_viewall'] === 'yes') {
        $url = !empty($settings['view_all_custom_link']['url']) ? $settings['view_all_custom_link']['url'] : '';
        if ($url) {
            $st_class .= ' href="' . esc_attr(esc_url($url)) . '"';
            if (!empty($settings['view_all_custom_link']['is_external'])) {
                $st_class .= ' target="_blank"';
            }
            if (!empty($settings['view_all_custom_link']['nofollow'])) {
                $st_class .= ' rel="nofollow"';
            }
        }
        $view_all_text = esc_html($settings['use_custom_link_text'] ?? '');
        $view_all = '<a ' . $st_class . '>' . $view_all_text . '</a>';
    } else {
        $streamit_options = get_option('streamit_options');
        $view_all_text = $streamit_options['streamit_viewall_text'] ?? esc_html__('Want More?', 'streamit');
        $cat = '';
        if (!empty($settings['woo_category'])) {
            $cat = '&cat=' . implode(',', $settings['woo_category']);
        }
        $view_all = '<a class="st-view-all" href="' . esc_url(get_page_link($streamit_options['streamit_viewall_link'] ?? 0)) . '?type=product&title=' . esc_attr($settings['product_slider_title'] ?? '') . '&p_type=' . esc_attr(($settings['product_type'] ?? '') . $cat) . '">' . esc_html($view_all_text) . '</a>';
    }
}
?>

<div class="st-woocommerce-product-slider streamit-responsive-arrow-widget woocommerce">

    <style>
        .st-woocommerce-product-slider .css_prefix-woo-buttons-holder ul {
            list-style: none;
            margin: 0;
            padding: 0;
        }

        .st-woocommerce-product-slider .product-caption {
            flex-grow: 1;
            text-align: center;
        }

        .st-woocommerce-product-slider .product-caption .product-excerpt-container,
        .st-woocommerce-product-slider .product-caption .product-list-actions {
            display: none;
        }
    </style>
    <?php if ((!empty($settings['view_all_switch']) && $settings['view_all_switch'] === 'yes') || !empty($settings['product_slider_title'])): ?>
        <header class="st-main-header d-flex align-items-center justify-content-between">
            <h4 class="main-title">
                <?php echo esc_html($settings['product_slider_title'] ?? ''); ?>
            </h4>
            <?php echo wp_kses_post($view_all); ?>
        </header>
    <?php endif; ?>

    <section class="section-spacing-bottom">
        <div class="swiper js-streamit-slider st-skeleton" data-type="product-shortcode"
            data-slides="<?php echo esc_attr($desktop_slides); ?>"
            data-lap="<?php echo esc_attr($laptop_slides); ?>"
            data-tab="<?php echo esc_attr($tablet_slides); ?>"
            data-mob="<?php echo esc_attr($mobile_slides); ?>"
            data-loop="<?php echo esc_attr(!empty($settings['infinite']) && $settings['infinite'] === 'true' ? 'true' : 'false'); ?>"
            data-autoplay="<?php echo esc_attr(!empty($settings['autoplay']) && $settings['autoplay'] === 'true' ? 'true' : 'false'); ?>"
            data-delay="<?php echo esc_attr($settings['autoplay_speed'] ?? 2000); ?>"
            data-speed="<?php echo esc_attr($settings['speed'] ?? 300); ?>"
            data-navigation="<?php echo esc_attr($desktop_navigation ? 'true' : 'false'); ?>"
            data-navigation-laptop="<?php echo esc_attr($laptop_navigation ? 'true' : 'false'); ?>"
            data-navigation-tablet="<?php echo esc_attr($tablet_navigation ? 'true' : 'false'); ?>"
            data-navigation-mobile="<?php echo esc_attr($mobile_navigation ? 'true' : 'false'); ?>"
            <?php if (defined('WP_DEBUG') && WP_DEBUG): ?>
            data-debug-products-per-page="<?php echo esc_attr($products_per_page); ?>"
            <?php endif; ?>
            data-pagination="false">

            <?php
            $add_swiper_slide_class = function ($classes) {
                $classes[] = 'swiper-slide';
                return $classes;
            };
            add_filter('woocommerce_post_class', $add_swiper_slide_class);
            add_filter('post_class', $add_swiper_slide_class);

            $shortcode_output = do_shortcode('[' . ($settings['product_type'] ?? 'products') . ' per_page="' . esc_attr($products_per_page) . '" ' . ($details['category'] ?? '') . ' order="' . ($settings['woo_order'] ?? 'ASC') . '" paginate="false" class="product-grid-style swiper-wrapper"]');
            $has_products_wrapper = preg_match('/class="[^"]*\bproducts\b[^"]*"/i', $shortcode_output) === 1;
            $product_item_count = preg_match_all('/class="[^"]*\bcss_prefix-sub-product\b[^"]*"/i', $shortcode_output, $product_matches);

            $shortcode_output = preg_replace_callback(
                '/class="([^"]*\bcss_prefix-sub-product\b[^"]*)"/i',
                static function ($matches) {
                    $classes = preg_split('/\s+/', trim($matches[1]));
                    $classes = array_filter($classes, static function ($class_name) {
                        return $class_name !== 'col' && strpos($class_name, 'col-') !== 0;
                    });

                    if (!in_array('swiper-slide', $classes, true)) {
                        $classes[] = 'swiper-slide';
                    }

                    return 'class="' . esc_attr(implode(' ', array_unique($classes))) . '"';
                },
                $shortcode_output
            );

            if (!$has_products_wrapper) {
                $shortcode_output = '<div class="products product-grid-style swiper-wrapper">' . $shortcode_output . '</div>';
            }

            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log(
                    'Streamit Product Slider Shortcode Debug: ' . wp_json_encode([
                        'products_per_page' => $products_per_page,
                        'rendered_product_items' => intval($product_item_count),
                        'has_products_wrapper' => $has_products_wrapper,
                        'product_type' => $settings['product_type'] ?? 'products',
                    ])
                );
            }

            echo $shortcode_output;

            remove_filter('woocommerce_post_class', $add_swiper_slide_class);
            remove_filter('post_class', $add_swiper_slide_class);
            ?>
        </div>

        <?php if (defined('WP_DEBUG') && WP_DEBUG): ?>
            <script>
                console.debug('Streamit Product Slider Frontend Debug', {
                    productsPerPage: <?php echo wp_json_encode($products_per_page); ?>,
                    desktopSlides: <?php echo wp_json_encode($desktop_slides); ?>,
                    laptopSlides: <?php echo wp_json_encode($laptop_slides); ?>,
                    tabletSlides: <?php echo wp_json_encode($tablet_slides); ?>,
                    mobileSlides: <?php echo wp_json_encode($mobile_slides); ?>,
                    productType: <?php echo wp_json_encode($settings['product_type'] ?? 'products'); ?>
                });
            </script>
        <?php endif; ?>

        <?php if ($show_navigation): ?>
                <button class="swiper-arrow swiper-button-prev js-swiper-prev" aria-label="Previous">
                    <i class="icon-arrow-left"></i>
                </button>
                <button class="swiper-arrow swiper-button-next js-swiper-next" aria-label="Next">
                    <i class="icon-arrow-right"></i>
                </button>
        <?php endif; ?>
    </section>
</div>
