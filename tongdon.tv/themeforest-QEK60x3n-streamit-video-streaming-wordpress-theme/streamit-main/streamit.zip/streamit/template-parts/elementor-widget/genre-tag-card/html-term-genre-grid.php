<section class="streamit-terms-grid">

    <header class="streamit-section-header">

        <<?php echo esc_attr($title_tag); ?>>
                        <?php echo esc_html($slider_title); ?>
        </<?php echo esc_attr($title_tag); ?>>

    </header>


    <div class="row row-cols-2 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5 g-4">

        <?php foreach ($term_object as $term):

            $url = streamit_get_permalink(
                $term->get_taxonomy(),
                $term->get_term_slug()
            );

            ?>

            <div class="col">

                <article class="streamit-term-card position-relative">
                    <div class="image-box position-relative">
                        <a class="streamit-term-link" href="<?php echo esc_url($url); ?>">
    
                            <?php echo streamit_render_image([
                                "attachment_id" => $term->get_thumbnail(),
                                "class" => "img-fluid ",
                                "alt" => $term->get_term_name()
                            ]); ?>
    
                            <h3 class="streamit-term-title h6">
    
                                <?php echo esc_html($term->get_term_name()); ?>
    
                            </h3>
    
                        </a>
                    </div>

                </article>

            </div>

        <?php endforeach; ?>

    </div>

</section>