<?php if (!defined('ABSPATH'))
    exit;

$get_navigation_setting = static function (string $key, string $legacy_key = '', string $fallback = 'flex') use ($settings): bool {
    if (array_key_exists($key, $settings) && $settings[$key] !== '') {
        return $settings[$key] === 'flex' || $settings[$key] === 'true';
    }

    if ($legacy_key && array_key_exists($legacy_key, $settings) && $settings[$legacy_key] !== '') {
        return $settings[$legacy_key] === 'flex' || $settings[$legacy_key] === 'true';
    }

    return $fallback === 'flex' || $fallback === 'true';
};
$desktop_navigation = $get_navigation_setting('nav-arrow', '', 'flex');
$laptop_navigation = $get_navigation_setting('nav-arrow_laptop', '', 'flex');
$tablet_navigation = $get_navigation_setting('nav-arrow_tablet', 'nav_arrow_tablet');
$mobile_navigation = $get_navigation_setting('nav-arrow_mobile', 'nav_arrow_mobile');
$show_navigation = $desktop_navigation || $laptop_navigation || $tablet_navigation || $mobile_navigation;
?>

<section class="streamit-terms streamit-terms-slider section-spacing-bottom">


    <header class="streamit-section-header d-flex align-items-center justify-content-between">

        <?php if ($slider_title): ?>

            <<?php echo esc_attr($title_tag); ?> class="streamit-section-title mb-0">
                                <?php echo esc_html($slider_title); ?>
            </<?php echo esc_attr($title_tag); ?>>

        <?php endif; ?>


        <?php if ($view_all_url && $view_all_text): ?>

            <a class="streamit-view-all" href="<?php echo esc_url($view_all_url); ?>">

                <?php echo esc_html($view_all_text); ?>

            </a>

        <?php endif; ?>

    </header>



    <div class="swiper js-streamit-slider terms-slider" data-type="terms"
        data-navigation="<?php echo esc_attr($desktop_navigation ? 'true' : 'false'); ?>"
        data-navigation-laptop="<?php echo esc_attr($laptop_navigation ? 'true' : 'false'); ?>"
        data-navigation-tablet="<?php echo esc_attr($tablet_navigation ? 'true' : 'false'); ?>"
        data-navigation-mobile="<?php echo esc_attr($mobile_navigation ? 'true' : 'false'); ?>"
        data-autoplay="<?php echo esc_attr($settings['autoplay'] === 'true' ? 'true' : 'false'); ?>"
        data-delay="<?php echo esc_attr($settings['autoplay_speed'] ?? 2000); ?>"
        data-speed="<?php echo esc_attr($settings['speed'] ?? 300); ?>"
        data-loop="<?php echo esc_attr($settings['infinite'] === 'true' ? 'true' : 'false'); ?>"
        data-slides="<?php echo esc_attr($settings['desk_number'] ?? 6); ?>"
        data-lap="<?php echo esc_attr($settings['lap_number'] ?? 4); ?>"
        data-tab="<?php echo esc_attr($settings['tab_number'] ?? 3); ?>"
        data-mob="<?php echo esc_attr($settings['mob_number'] ?? 2); ?>">

        <div class="swiper-wrapper">

            <?php foreach ($term_object as $term):

                $image_id = $term->get_thumbnail();
                $url = streamit_get_permalink(
                    $term->get_taxonomy(),
                    $term->get_term_slug()
                );

                ?>

                <article class="swiper-slide">
                    <div class="streamit-term-card position-relative">
                        <div class="image-box position-relative">
                            <a href="<?php echo esc_url($url); ?>" class="streamit-term-link">

                                <?php
                                echo streamit_render_image([
                                    "attachment_id" => $image_id,
                                    "class" => "img-fluid ",
                                    "alt" => $term->get_term_name(),
                                    "loading" => "lazy"
                                ]);
                                ?>

                                <h3 class="streamit-term-title h6">

                                    <?php echo esc_html($term->get_term_name()); ?>

                                </h3>

                            </a>
                        </div>
                    </div>
                </article>

            <?php endforeach; ?>

        </div>


    </div>

                <?php if ($show_navigation): ?>

            <button class="swiper-arrow swiper-button-prev js-swiper-prev" aria-label="Previous">

            <i class="icon-arrow-left"></i>

        </button>


            <button class="swiper-arrow swiper-button-next js-swiper-next" aria-label="Next">

            <i class="icon-arrow-right"></i>

        </button>

                <?php endif; ?>

</section>
