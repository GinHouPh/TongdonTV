<section class="streamit-tags-slider">

    <header class="streamit-section-header">

        <<?php echo esc_attr($title_tag); ?>>
            <?php echo esc_html($slider_title); ?>
        </<?php echo esc_attr($title_tag); ?>>

    </header>


    <div class="swiper js-streamit-slider" data-type="tags"
        data-slides="<?php echo esc_attr($settings['desk_number'] ?? 6); ?>"
        data-lap="<?php echo esc_attr($settings['lap_number'] ?? 4); ?>"
        data-tab="<?php echo esc_attr($settings['tab_number'] ?? 3); ?>"
        data-mob="<?php echo esc_attr($settings['mob_number'] ?? 2); ?>">

        <div class="swiper-wrapper">

            <?php foreach ($term_object as $term): ?>

                <div class="swiper-slide">

                    <a class="streamit-tag" href="<?php echo esc_url(
                        streamit_get_permalink(
                            $term->get_taxonomy(),
                            $term->get_term_slug()
                        )
                    ); ?>">

                        <?php echo esc_html($term->get_term_name()); ?>

                    </a>

                </div>

            <?php endforeach; ?>

        </div>

    </div>

</section>