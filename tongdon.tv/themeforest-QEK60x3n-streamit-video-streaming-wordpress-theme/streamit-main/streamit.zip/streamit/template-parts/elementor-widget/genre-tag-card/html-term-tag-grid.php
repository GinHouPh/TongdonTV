<section class="streamit-terms-grid">

    <header class="streamit-section-header">

        <<?php echo esc_attr($title_tag); ?>>
                        <?php echo esc_html($slider_title); ?>
        </<?php echo esc_attr($title_tag); ?>>

    </header>


    <div class="row g-3 g-lg-4 row-cols-2 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5 row-cols-xxl-6">

        <?php foreach ($term_object as $term):

            $url = streamit_get_permalink(
                $term->get_taxonomy(),
                $term->get_term_slug()
            );

            ?>

            <div class="col">

                <article>

                    <a class="tag-card" href="<?php echo esc_url($url); ?>">

                                                <!-- <?php echo streamit_render_image([
                                                    "attachment_id" => $term->get_thumbnail(),
                                                    "class" => "img-fluid",
                                                    "alt" => $term->get_term_name()
                                                ]); ?> -->

                        <span class="tag-title line-count-1">

                            <?php echo esc_html($term->get_term_name()); ?>

                        </span>

                    </a>

                            </article>

                </div>

        <?php endforeach; ?>

    </div>

</section>