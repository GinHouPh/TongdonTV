<?php
if (!defined('ABSPATH'))
    exit;


if (empty($post_content))
    return;

$get_navigation_setting = static function (string $key, string $legacy_key = '', string $fallback = 'flex') use ($settings): bool {
    if (array_key_exists($key, $settings) && $settings[$key] !== '') {
        return $settings[$key] === 'flex' || $settings[$key] === 'true';
    }

    if ($legacy_key && array_key_exists($legacy_key, $settings) && $settings[$legacy_key] !== '') {
        return $settings[$legacy_key] === 'flex' || $settings[$legacy_key] === 'true';
    }

    return $fallback === 'flex' || $fallback === 'true';
};
$desktop_navigation = $get_navigation_setting('nav-arrow', '', 'flex');
$laptop_navigation = $get_navigation_setting('nav-arrow_laptop', '', 'flex');
$tablet_navigation = $get_navigation_setting('nav-arrow_tablet', 'nav_arrow_tablet');
$mobile_navigation = $get_navigation_setting('nav-arrow_mobile', 'nav_arrow_mobile');
$show_navigation = $desktop_navigation || $laptop_navigation || $tablet_navigation || $mobile_navigation;
?>

<section class="streamit-continue-watching">


    <?php if (!empty($slider_title)): ?>

        <header class="streamit-section-header d-flex justify-content-between align-items-center">

            <<?php echo esc_attr($title_tag); ?> class="section-title">

                <?php echo esc_html($slider_title); ?>

            </<?php echo esc_attr($title_tag); ?>>

        </header>

    <?php endif; ?>


    <div class="swiper js-streamit-slider streamit-continue-slider" data-type="continue-watching"
        data-slides="<?php echo esc_attr($settings['desk_number'] ?? 6); ?>"
        data-lap="<?php echo esc_attr($settings['lap_number'] ?? 4); ?>"
        data-tab="<?php echo esc_attr($settings['tab_number'] ?? 3); ?>"
        data-mob="<?php echo esc_attr($settings['mob_number'] ?? 2); ?>" data-loop="<?php echo esc_attr(
                 $settings['infinite'] === "true" ? "true" : "false"
             ); ?>" data-autoplay="<?php echo esc_attr(
                  $settings['autoplay'] === "true" ? "true" : "false"
              ); ?>" data-delay="<?php echo esc_attr(
                   $settings['autoplay_speed'] ?? 2000
                ); ?>" data-speed="<?php echo esc_attr(
                    $settings['speed'] ?? 300
                ); ?>" data-navigation="<?php echo esc_attr(
                     $desktop_navigation ? "true" : "false"
                 ); ?>" data-navigation-laptop="<?php echo esc_attr(
                     $laptop_navigation ? "true" : "false"
                 ); ?>" data-navigation-tablet="<?php echo esc_attr(
                     $tablet_navigation ? "true" : "false"
                 ); ?>" data-navigation-mobile="<?php echo esc_attr(
                     $mobile_navigation ? "true" : "false"
                 ); ?>" data-pagination="false">


        <div class="swiper-wrapper">


            <?php foreach ($post_content as $item):

                $post = $item['post_data'];

                if (!$post)
                    continue;

                $thumbnail =
                    $post->get_meta('thumbnail_id');

                $url =
                    streamit_get_permalink(
                        $post->get_post_type(),
                        $post->get_post_name()
                    );

                $progress =
                    intval(
                        $item['watched_time_percentage']
                    );

                $remaining =
                    round(
                        ($item['watched_total_time']
                            -
                            $item['watched_time']) / 60,
                        1
                    );

                ?>


                <article class="swiper-slide">

                    <div class="continue-card">


                        <!-- remove -->
                        <button class="trash-continue-watching continue-remove" data-post-id="<?php echo esc_attr(
                            $post->get_id()
                        ); ?>" data-post-type="<?php echo esc_attr(
                             $post->get_post_type()
                         ); ?>" aria-label="Remove">

                            <?php echo st_get_icon('cross'); ?>

                        </button>


                        <a href="<?php echo esc_url($url); ?>" class="continue-media">


                            <?php

                            echo streamit_render_image([
                                'attachment_id' => $thumbnail,
                                'class' => 'img-fluid',
                                'alt' => $post->get_post_title(),
                                'loading' => 'lazy',
                                'decoding' => 'async'
                            ]);

                            ?>


                        </a>


                        <div class="continue-meta">


                            <span class="continue-remaining">

                                <?php echo esc_html(
                                    $remaining
                                );
                                echo esc_html__('m Left', 'streamit'); ?>

                            </span>


                            <h3 class="continue-title">

                                <a href="<?php echo esc_url($url); ?>">

                                    <?php
                                    echo esc_html(
                                        $post->get_post_title()
                                    );
                                    ?>

                                </a>

                            </h3>


                        </div>


                        <div class="continue-progress">

                            <span class="progress-bar" style="width:
                            <?php echo esc_attr(
                                $progress
                            ); ?>%">
                            </span>

                        </div>


                    </div>

                </article>


            <?php endforeach; ?>


        </div>


        <?php if ($show_navigation): ?>

            <button class="swiper-arrow swiper-button-prev js-swiper-prev">

                <i class="icon-arrow-left"></i>

            </button>

            <button class="swiper-arrow swiper-button-next js-swiper-next">

                <i class="icon-arrow-right"></i>

            </button>

        <?php endif; ?>


</section>
