
<div class="section-spacing-bottom streamit-responsive-arrow-widget">



    <?php if (!empty($slider_title)): ?>
        <div class="streamit-card-title mb-3">
            <<?php echo esc_attr($title_tag); ?> class="title-tag">
                <?php echo esc_html($slider_title); ?>
            </<?php echo esc_attr($title_tag); ?>>
        </div>
    <?php endif; ?>

    <div class="swiper js-streamit-slider streamit-blog-slider" data-type="blog-slider"
        data-slides="<?php echo esc_attr($slick_settings['slidesToShow']); ?>"
        data-lap="<?php echo esc_attr($slick_settings['responsive'][0]['settings']['slidesToShow']); ?>"
        data-tab="<?php echo esc_attr($slick_settings['responsive'][1]['settings']['slidesToShow']); ?>"
        data-mob="<?php echo esc_attr($slick_settings['responsive'][2]['settings']['slidesToShow']); ?>"
        data-loop="<?php echo $slick_settings['infinite'] ? 'true' : 'false'; ?>"
        data-autoplay="<?php echo $slick_settings['autoplay'] ? 'true' : 'false'; ?>"
        data-delay="<?php echo esc_attr($slick_settings['autoplaySpeed']); ?>"
        data-speed="<?php echo esc_attr($slick_settings['speed']); ?>"
        data-navigation="<?php echo $slick_settings['arrows'] ? 'true' : 'false'; ?>"
        data-navigation-laptop="<?php echo $slick_settings['responsive'][0]['settings']['arrows'] ? 'true' : 'false'; ?>"
        data-navigation-tablet="<?php echo $slick_settings['responsive'][1]['settings']['arrows'] ? 'true' : 'false'; ?>"
        data-navigation-mobile="<?php echo $slick_settings['responsive'][2]['settings']['arrows'] ? 'true' : 'false'; ?>">

        <div class="swiper-wrapper">

            <?php foreach ($slides as $item): ?>

                <div class="swiper-slide">

                    <article class="streamit-blog-card">

                        <a href="<?php echo esc_url($item['link']); ?>">

                            <div class="blog-image">

                                <img src="<?php echo esc_url($item['image']); ?>"
                                    alt="<?php echo esc_attr($item['title']); ?>" class="img-fluid" loading="lazy">

                            </div>

                            <?php if ($show_post_title): ?>

                                <div class="blog-caption">

                                    <h6 class="blog-title line-count-2">
                                        <?php echo esc_html($item['title']); ?>
                                    </h6>

                                </div>

                            <?php endif; ?>

                        </a>

                    </article>

                </div>

            <?php endforeach; ?>

        </div>

        <?php if ($slick_settings['arrows']): ?>

            <div class="swiper-button-prev js-swiper-prev"><i class="icon-arrow-left"></i></div>

            <div class="swiper-button-next js-swiper-next"><i class="icon-arrow-right"></i></div>

        <?php endif; ?>

    </div>

</div>