<?php

/**
 * The template for displaying tag pages
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package streamit
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}
?>

<div class="col">
    <div class="streamit-term-card position-relative">
        <div class="image-box position-relative">

            <a href="<?php echo esc_url(streamit_get_permalink('video_category', $st_data->get_term_slug())) ?>"
                class="color-inherit line-count-1">

                <!-- Optimized Image Render -->
                <?php
                echo streamit_render_image([
                    'attachment_id' => $st_data->get_thumbnail(),
                    'alt'           => $st_data->get_term_name(),
                    'class'         => 'img-fluid w-100 genres-img',
                    'size'          => 'medium_large', // Best WP auto-scaled size
                    'loading'       => 'lazy',
                    'fetchpriority' => 'auto',
                    'show_fallback' => true,
                ]);
                ?>

                <?php if (!empty($st_data->get_term_name())) : ?>
                    <span class="genres-title h6">
                        <?php echo esc_html(wp_unslash($st_data->get_term_name())) ?>
                    </span>
                <?php endif; ?>

            </a>
        </div>
    </div>
</div>