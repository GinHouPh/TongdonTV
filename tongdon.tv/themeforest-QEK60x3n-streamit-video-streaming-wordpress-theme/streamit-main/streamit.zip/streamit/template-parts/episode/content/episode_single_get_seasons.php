<?php

/**
 * The template for displaying share model
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package streamit
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

global $streamit_options;
$enable_upcoming_badges = ($streamit_options['streamit_recommended_enable_upcoming_badges'] === 'yes');

?>

<?php
$current_episode_id = (int)$st_data->get_id();
$current_tab = $slider_position = 0;
$total_slides = 0;
$tvshow    = streamit_get_tvshow((int)$st_data->get_meta('tvshow_id'));
if (empty($tvshow)) {
    return;
}

$seasons = $tvshow->get_meta("_seasons");

if (empty($seasons)) {
    return;
}
foreach ($seasons as $index => $val) {
    if (isset($val['episodes']) && is_array($val['episodes'])) {
        if (in_array($current_episode_id, $val['episodes'])) {
            $current_tab = $index;
            $slider_position = array_search($current_episode_id, $val['episodes']);
            $total_slides = count($val['episodes']);
        }
    }
}

$slides_to_show = 5;
if ($slider_position > $total_slides - $slides_to_show) {
    $slider_position = max(0, $total_slides - $slides_to_show);
}
?>
<div class="section-spacing-top">
    <div class="container-fluid">
        <div class="episode-section">
            <div class="single-page-season-swiper">
                <div class="d-flex align-items-center justify-content-between mb-md-5 mb-3">
                    <h5 class="main-title text-capitalize mb-0"><?php echo esc_html__('Episodes', 'streamit'); ?></h5>
                </div>

                <div class="episode-season">
                    <div id="item-nav">
                        <div class="item-list-tabs no-ajax css_prefix-tab-lists" id="object-nav">
                            <div class="left" onclick="slide('left',event)" style="display: none;">
                                <?php echo st_get_icon('arrow-left'); ?>
                            </div>
                            <ul class="nav nav-pills custom-tab-slider episode-nav-btn gap-3" id="nav-tab">
                                <?php foreach ($seasons as $index => $val) :
                                    $season_name_id = trim(preg_replace('/[^a-zA-Z0-9]+/', '_', strtolower($val['name'])), '-');

                                    // Check if this season is upcoming
                                    $season_upcoming_data = function_exists('streamit_is_season_upcoming') ? streamit_is_season_upcoming($val) : ['is_future_release' => false];
                                    $is_upcoming_season = $season_upcoming_data['is_future_release'];
                                ?>
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link <?php echo $index === $current_tab ? 'active' : ''; ?>" data-display='<?php echo esc_attr($index); ?>' data-bs-toggle="pill" data-season_no="<?php echo esc_attr($index); ?>" href="#<?php echo esc_attr($season_name_id); ?>">
                                            <?php echo esc_html($val['name']); ?>
                                            <?php if ($is_upcoming_season && $enable_upcoming_badges) : ?>
                                                <span class="badge ms-2 upcoming-badge">
                                                    <span><?php echo esc_html__('Coming Soon', 'streamit'); ?></span>
                                                </span>
                                            <?php endif; ?>
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                            <div class="right" onclick="slide('right',event)" style="display: none;">
                                <?php echo st_get_icon('arrow-right'); ?>
                            </div>
                        </div>
                    </div>
                    <div class="episode-jump-buttons-wrapper mb-4" id="episode-jump-wrapper" style="display: none;">
                        <div class="d-flex gap-2 flex-wrap" id="episode-jump-buttons"></div>
                    </div>
                    <div class="tab-content mt-5" id="nav-tabContent">
                        <?php
                        foreach ($seasons as $index1 => $season) :
                            // Check if this season is upcoming
                            $season_upcoming_data = function_exists('streamit_is_season_upcoming') ? streamit_is_season_upcoming($season) : ['is_future_release' => false];
                            $is_upcoming_season = $season_upcoming_data['is_future_release'];
                            
                        ?>
                            <div class="tab-pane fade  <?php echo $current_tab === $index1 ? ' active show' : ''; ?>" id="<?php echo trim(preg_replace('/[^a-zA-Z0-9]+/', '_', strtolower($season['name'])), '-'); ?>" role="tabpanel" data-season-index="<?php echo esc_attr($index1); ?>">
                                <div class="single-page-season-swiper">
                                    <div class="css_prefix-episodes-content">
                                        <?php
                                        // Check if user is admin for upcoming season access
                                        $is_admin = current_user_can('administrator');

                                        if ($is_upcoming_season && !$is_admin) : ?>
                                            <?php
                                            // Include the upcoming season template 
                                            streamit_get_template('tvshow/content/tvshow_single_upcoming_season.php', ['season' => $season, 'season_upcoming_data' => $season_upcoming_data, 'st_data' => $tvshow, 'season_index' => $index1]);
                                            ?>
                                        <?php elseif (!empty($season['episodes'])) : ?>
                                            <div class="episodes-slider swiper js-streamit-slider st-skeleton"
                                                data-type="single-episode-season"
                                                data-display="<?php echo esc_attr($index1); ?>"
                                                data-navigation="true"
                                                data-initial-slide="<?php echo esc_attr($current_tab === $index1 ? $slider_position : 0); ?>">
                                                <div class="swiper-wrapper">
                                                <?php
                                                $episode_posts = streamit_get_episodes(['orderby' => 'post__in', 'include' => $season['episodes'],  'per_page' => -1])->results;
                                                foreach ($episode_posts as $index => $episode) :
                                                    streamit_get_template('episode/content/episode_single_slider.php', [
                                                        'episode' => $episode,
                                                        'current_episode_id' => $current_episode_id,
                                                        'slide_class' => 'swiper-slide',
                                                    ]);
                                                endforeach;
                                                ?>
                                                </div>
                                            </div>
                                            <div class="swiper-navigation">
                                                <button class="swiper-arrow swiper-button-prev PreArrow-two" aria-label="<?php esc_attr_e('Previous', 'streamit'); ?>">
                                                    <i class="icon-arrow-left"></i>
                                                </button>
                                                <button class="swiper-arrow swiper-button-next NextArrow-two" aria-label="<?php esc_attr_e('Next', 'streamit'); ?>">
                                                    <i class="icon-arrow-right"></i>
                                                </button>
                                            </div>
                                        <?php else :
                                            echo '<p class="no_data_found"> ' . esc_html__('No Episode Available', 'streamit') . '</p>';
                                        endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
