<?php

/**
 * The template for displaying index of current episode
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package streamit
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Get episode data
$st_data = $st_data ?? null;
if (empty($st_data)) {
    return;
}

// Get upcoming status
$upcoming_data = [];
if (function_exists('streamit_get_tvshow_upcoming_status')) {
    $upcoming_data = streamit_get_tvshow_upcoming_status($st_data);
}
$is_upcoming = $upcoming_data['is_upcoming'] ?? false;
$season_id = $upcoming_data['season_id'] ?? '';
// Episode post ID
$episode_id = $st_data->get_id();

// 1. Episode number (episodemeta)
$episode_number = $st_data->get_meta('_episode_number');

// 2. Get TV show ID (episodemeta)
$tvshow_id = $st_data->get_meta('tvshow_id');

// 3. Get seasons array (tvshowmeta)
$seasons_data = streamit_get_tvshow_meta($tvshow_id, '_seasons');

// 4. Lookup season number
$season_number = '';

if (!empty($seasons_data) && is_array($seasons_data)) {
    foreach ($seasons_data as $index => $season) {
        if (!empty($season['episodes'])) {
            foreach ($season['episodes'] as $ep_post_id) {
                
                // Match episode ID inside season episodes
                if (intval($ep_post_id) === intval($episode_id)) {
                    $season_number = $index + 1;
                    break 2; // break both loops
                }
            }
        }
    }
}

?>
<div class="episode-index-info">
    <div class="episode-meta-header">
        <?php if (!empty($season_number) && !empty($episode_number)) : ?>
            <span class="season-episode-info">
                <?php echo sprintf(esc_html__('Season %s • Episode %s', 'streamit'), $season_number, $episode_number); ?>
            </span>
        <?php endif; ?>

    </div>
</div>

<?php
