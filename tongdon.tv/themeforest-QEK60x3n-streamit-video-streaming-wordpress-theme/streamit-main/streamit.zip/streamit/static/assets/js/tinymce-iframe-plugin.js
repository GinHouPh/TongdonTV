(function () {
    tinymce.PluginManager.add('streamit_iframe_button', function (editor, url) {

        /**
         * Detect the type of media from URL
         * @param {string} url - The URL to analyze
         * @returns {object} - { type: 'image|video|audio|spotify|youtube|vimeo|soundcloud|iframe|unknown', data: {...} }
         */
        function detectMediaType(url) {
            // Get file extension
            var extension = url.split('?')[0].split('.').pop().toLowerCase();

            // Check for image extensions
            if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp'].includes(extension)) {
                return { type: 'image', url: url };
            }

            // Check for video extensions
            if (['mp4', 'webm', 'ogg', 'mov', 'avi', 'mkv'].includes(extension)) {
                return { type: 'video', url: url, extension: extension };
            }

            // Check for audio extensions
            if (['mp3', 'wav', 'ogg', 'm4a', 'aac', 'flac'].includes(extension)) {
                return { type: 'audio', url: url, extension: extension };
            }

            // Check for Spotify
            if (url.includes('spotify.com')) {
                if (url.includes('/track/')) {
                    var trackId = url.match(/track\/([a-zA-Z0-9]+)/);
                    return trackId ? { type: 'spotify', subtype: 'track', id: trackId[1] } : null;
                } else if (url.includes('/album/')) {
                    var albumId = url.match(/album\/([a-zA-Z0-9]+)/);
                    return albumId ? { type: 'spotify', subtype: 'album', id: albumId[1] } : null;
                } else if (url.includes('/playlist/')) {
                    var playlistId = url.match(/playlist\/([a-zA-Z0-9]+)/);
                    return playlistId ? { type: 'spotify', subtype: 'playlist', id: playlistId[1] } : null;
                }
            }

            // Check for YouTube
            if (url.includes('youtube.com') || url.includes('youtu.be')) {
                var videoId = null;
                if (url.includes('youtube.com/watch')) {
                    var match = url.match(/[?&]v=([^&]+)/);
                    videoId = match ? match[1] : null;
                } else if (url.includes('youtu.be/')) {
                    var match = url.match(/youtu\.be\/([^?]+)/);
                    videoId = match ? match[1] : null;
                }
                return videoId ? { type: 'youtube', id: videoId } : null;
            }

            // Check for Vimeo
            if (url.includes('vimeo.com')) {
                var videoId = url.match(/vimeo\.com\/(\d+)/);
                return videoId ? { type: 'vimeo', id: videoId[1] } : null;
            }

            // Check for SoundCloud
            if (url.includes('soundcloud.com')) {
                return { type: 'soundcloud', url: url };
            }

            return { type: 'unknown' };
        }

        /**
         * Convert media data to appropriate HTML
         * @param {object} mediaData - Media type and data from detectMediaType()
         * @returns {string} - HTML string
         */
        function convertToHTML(mediaData) {
            if (!mediaData || !mediaData.type) {
                return '';
            }

            // Handle different media types with clear if-else structure
            if (mediaData.type === 'image') {
                return '<img src="' + mediaData.url + '" alt="Embedded image" style="max-width: 100%; height: auto;" />';

            } else if (mediaData.type === 'video') {
                var mimeType = mediaData.extension === 'mov' ? 'quicktime' : mediaData.extension;
                return '<video controls style="max-width: 100%;"><source src="' + mediaData.url + '" type="video/' + mimeType + '">Your browser does not support the video tag.</video>';

            } else if (mediaData.type === 'audio') {
                var mimeType = mediaData.extension === 'm4a' ? 'mp4' : mediaData.extension;
                return '<audio controls style="width: 100%;"><source src="' + mediaData.url + '" type="audio/' + mimeType + '">Your browser does not support the audio tag.</audio>';

            } else if (mediaData.type === 'spotify') {
                var height = mediaData.subtype === 'track' ? '80' : '380';
                return '<iframe src="https://open.spotify.com/embed/' + mediaData.subtype + '/' + mediaData.id + '" width="300" height="' + height + '" frameborder="0" allowtransparency="true" allow="encrypted-media"></iframe>';

            } else if (mediaData.type === 'youtube') {
                return '<iframe width="560" height="315" src="https://www.youtube.com/embed/' + mediaData.id + '" frameborder="0" allowfullscreen></iframe>';

            } else if (mediaData.type === 'vimeo') {
                return '<iframe src="https://player.vimeo.com/video/' + mediaData.id + '" width="640" height="360" frameborder="0" allowfullscreen></iframe>';

            } else if (mediaData.type === 'soundcloud') {
                return '<iframe width="100%" height="166" scrolling="no" frameborder="no" src="https://w.soundcloud.com/player/?url=' + encodeURIComponent(mediaData.url) + '&color=%23ff5500&auto_play=false&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true"></iframe>';

            } else {
                // Unknown type - return empty
                return '';
            }
        }

        /**
         * Main conversion function
         * @param {string} input - User input (URL or HTML code)
         * @returns {string} - Converted HTML
         */
        function convertToMediaHTML(input) {
            input = input.trim();

            // If it's already HTML (contains < or >), return as-is
            if (input.includes('<') || input.includes('>')) {
                return input;
            }

            // Extract URL if it's wrapped in quotes or has extra text
            var urlMatch = input.match(/https?:\/\/[^\s]+/);
            var url = urlMatch ? urlMatch[0] : input;

            // Remove trailing punctuation
            url = url.replace(/[.,;!?]+$/, '');

            // Detect media type
            var mediaData = detectMediaType(url);

            // Convert to HTML
            var html = convertToHTML(mediaData);

            // If conversion failed, return original input
            return html || input;
        }

        /**
         * Create and show custom dynamic dialog
         */
        function showCustomDialog() {
            // Create overlay
            var overlay = document.createElement('div');
            overlay.id = 'streamit-media-overlay';
            overlay.style.cssText = 'position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.7); z-index: 100000; display: flex; align-items: center; justify-content: center;';

            // Create dialog
            var dialog = document.createElement('div');
            dialog.id = 'streamit-media-dialog';
            dialog.style.cssText = 'background: #fff; border-radius: 4px; box-shadow: 0 5px 15px rgba(0,0,0,0.3); width: 500px; max-width: 90%; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;';

            // Dialog header
            var header = document.createElement('div');
            header.style.cssText = 'padding: 15px 20px; border-bottom: 1px solid #ddd; display: flex; justify-content: space-between; align-items: center;';
            header.innerHTML = '<h2 style="margin: 0; font-size: 18px; font-weight: 600;">Attach via URL or Embed</h2><button id="streamit-close-btn" style="background: none; border: none; font-size: 24px; cursor: pointer; color: #666; line-height: 1; padding: 0; width: 30px; height: 30px;">&times;</button>';

            // Dialog body
            var body = document.createElement('div');
            body.style.cssText = 'padding: 20px;';

            var textarea = document.createElement('textarea');
            textarea.id = 'streamit-media-input';
            textarea.style.cssText = 'width: 100%; min-height: 80px; max-height: 300px; padding: 10px; border: 1px solid #ddd; border-radius: 3px; font-family: Consolas, Monaco, monospace; font-size: 13px; resize: none; overflow-y: auto; transition: height 0.2s ease; box-sizing: border-box;';
            textarea.placeholder = 'Paste URL or embed code here...';

            // Auto-resize function
            function autoResize() {
                textarea.style.height = 'auto';
                var newHeight = Math.min(Math.max(textarea.scrollHeight, 80), 300);
                textarea.style.height = newHeight + 'px';
            }

            textarea.addEventListener('input', autoResize);
            textarea.addEventListener('paste', function () {
                setTimeout(autoResize, 10);
            });

            body.appendChild(textarea);

            // Dialog footer
            var footer = document.createElement('div');
            footer.style.cssText = 'padding: 15px 20px; border-top: 1px solid #ddd; text-align: right;';

            var cancelBtn = document.createElement('button');
            cancelBtn.textContent = 'Cancel';
            cancelBtn.style.cssText = 'padding: 8px 16px; margin-right: 10px; border: 1px solid #ddd; background: #fff; border-radius: 3px; cursor: pointer; font-size: 13px;';

            var insertBtn = document.createElement('button');
            insertBtn.textContent = 'Insert';
            insertBtn.style.cssText = 'padding: 8px 16px; border: none; background: #2271b1; color: #fff; border-radius: 3px; cursor: pointer; font-size: 13px; font-weight: 500;';

            footer.appendChild(cancelBtn);
            footer.appendChild(insertBtn);

            // Assemble dialog
            dialog.appendChild(header);
            dialog.appendChild(body);
            dialog.appendChild(footer);
            overlay.appendChild(dialog);
            document.body.appendChild(overlay);

            // Focus textarea
            setTimeout(function () {
                textarea.focus();
            }, 100);

            // Close function
            function closeDialog() {
                document.body.removeChild(overlay);
            }

            // Event listeners
            overlay.addEventListener('click', function (e) {
                if (e.target === overlay) closeDialog();
            });

            document.getElementById('streamit-close-btn').addEventListener('click', closeDialog);
            cancelBtn.addEventListener('click', closeDialog);

            insertBtn.addEventListener('click', function () {
                var input = textarea.value;
                if (input) {
                    var html = convertToMediaHTML(input);
                    editor.insertContent(html);
                    closeDialog();
                }
            });

            // Enter to insert (Ctrl+Enter for new line)
            textarea.addEventListener('keydown', function (e) {
                if (e.key === 'Enter' && !e.ctrlKey && !e.shiftKey) {
                    e.preventDefault();
                    insertBtn.click();
                }
            });
        }

        // Register the TinyMCE button
        editor.addButton('streamit_iframe_button', {
            title: 'Add Media',
            icon: 'media',
            onclick: function () {
                showCustomDialog();
            }
        });
    });
})();
