<?php

/**
 * Common Helper Functions.
 *
 * @package streamit
 */

defined('ABSPATH') || exit;

/**
 * Setup theme features and support.
 *
 * This function is hooked into 'after_setup_theme' and adds support for various
 * theme features like title tags, post formats, menu locations, and more.
 */
add_action('after_setup_theme', function () {

    // Add default posts and comments RSS feed links to head
    add_theme_support('automatic-feed-links');

    // Enable responsive embeds (for oEmbed content)
    add_theme_support('responsive-embeds');

    // Enable HTML5 support for specific elements
    add_theme_support('html5', ['script', 'style', 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption']);

    // Let WordPress manage the document title
    add_theme_support('title-tag');

    // Enable support for custom logo
    add_theme_support('custom-logo');

    // LifterLMS sidebar support
    add_theme_support('lifterlms-sidebars');

    // Boostify header and footer support
    add_theme_support('boostify-header-footer');

    // Theme builder header/footer parts (if applicable)
    add_theme_support('fl-theme-builder-headers');
    add_theme_support('fl-theme-builder-footers');
    add_theme_support('fl-theme-builder-parts');

    // Enable editor styles for the block editor
    add_theme_support('editor-styles');

    // Enable support for post thumbnails (featured images)
    add_theme_support('post-thumbnails');

    // Add excerpt support for pages
    add_post_type_support('page', 'excerpt');

    // Enable support for post formats
    add_theme_support('post-formats', ['aside', 'gallery', 'link', 'image', 'quote', 'status', 'video', 'audio', 'chat']);

    // Register support for Gutenberg wide images
    add_theme_support('align-wide');

    // Enable selective refresh for widgets in customizer
    add_theme_support('customize-selective-refresh-widgets');

    // Header/Footer Elementor support
    add_theme_support('header-footer-elementor');

    //woocommerce support
    add_theme_support('woocommerce');
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');

    // Register navigation menus
    $st_all_menus = [
        'primary'   => esc_html__('Primary Menu', 'streamit'),
        'secondary' => esc_html__('Secondary Menu', 'streamit'),
        'streamit-footer-menu-link' => esc_html__('Mobile Navigation Menu', 'streamit'),
    ];

    // Allow other functions to modify menu locations
    $st_all_menus = apply_filters('st_register_nav_menus', $st_all_menus);

    // Register menus if there are any locations to register
    if (!empty($st_all_menus)) {
        register_nav_menus($st_all_menus);
    }

    add_filter('wpcf7_form_novalidate', '__return_true');

    add_filter('heartbeat_settings', function ($settings) {
        $settings['interval'] = 10; // seconds
        return $settings;
    });
});


//add widget
add_action(
    'widgets_init',
    function () {
        register_sidebar(
            array(
                'name'          => esc_html__('Blog Sidebar', 'streamit'),
                'id'            => 'streamit-blog-sidebar',
                'description'   => esc_html__('Add widgets here.', 'streamit'),
                'before_widget' => '<div id="%1$s" class="widget %2$s">',
                'after_widget'  => '</div>',
                'before_title'  => '<h5 class="widget-title"> <span>  ',
                'after_title'   => ' </span></h5>',
            )
        );

        register_sidebar(array(
            'name'          => esc_html__('Product Sidebar', 'streamit'),
            'class'         => 'nav-list',
            'id'            => 'streamit_product_sidebar',
            'before_widget' => '<div class="widget sidebar_widget widget-woof %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h5 class="widget-title"> <span>',
            'after_title'   => '</span></h5>',
        ));
    }
);

/**
 * Determine whether to display the header based on options.
 *
 * @return bool Whether to display the header.
 */
function streamit_display_header()
{
    global $streamit_options;
    if (!apply_filters('streamit_display_header', true)) return false;

    // Default to displaying header if options are not set
    if (!isset($streamit_options)) {
        return true;
    }

    // Check if header meta display is set to 'no'
    if (isset($streamit_options['display_header_meta']) && $streamit_options['display_header_meta'] === 'no') {
        return false;
    }

    // Check if it's a 404 page and header on 404 is set to '0'
    if (is_404() && isset($streamit_options['header_on_404']) && $streamit_options['header_on_404'] === '0') {
        return false;
    }

    // Return the final result after applying all conditions
    return true;
}

/**
 * Verify whether to display the footer.
 *
 * @return bool True if the footer should be displayed, false otherwise.
 */
function streamit_display_footer()
{
    global $streamit_options;

    if (!apply_filters('streamit_display_footer', true)) return false;
    // Default to displaying footer if options are not set
    if (!isset($streamit_options)) {
        return true;
    }


    // Check if footer meta display is set to 'no'
    if (isset($streamit_options['display_footer_meta']) && $streamit_options['display_footer_meta'] === 'no') {
        return false;
    }

    // Check if it's a 404 page and footer on 404 is set to '0'
    if (is_404() && isset($streamit_options['footer_on_404']) && $streamit_options['footer_on_404'] === '0') {
        return false;
    }

    // Return the final result after applying all conditions
    return true;
}

/**
 * Embed Video, Audio, Iframe, etc.
 *
 * @param int $post_id Post ID to fetch the embedded content from.
 * 
 * @return string|null Embed external resource, or null if not found.
 */
function st_get_embed_video($post_id)
{
    // Ensure $post_id is valid and sanitize it
    $post_id = intval($post_id);

    // Return null if post_id is invalid
    if (!$post_id) {
        return null;
    }

    $post = get_post($post_id);

    // Ensure we have post content to work with
    if (!$post || empty($post->post_content)) {
        return null;
    }

    $content = do_shortcode(apply_filters('the_content', $post->post_content));

    // Get all embedded media in the content
    $embeds = get_media_embedded_in_content($content);

    // Allow filtering of the embeds before processing
    $embeds = apply_filters('st_get_embeds', $embeds, $post_id);

    // Check if embeds exist and look for specific media types
    if (!empty($embeds)) {
        foreach ($embeds as $embed) {
            if (
                strpos($embed, 'video') !== false ||
                strpos($embed, 'youtube') !== false ||
                strpos($embed, 'vimeo') !== false ||
                strpos($embed, 'dailymotion') !== false ||
                strpos($embed, 'vine') !== false ||
                strpos($embed, 'wordpress.tv') !== false ||
                strpos($embed, 'embed') !== false ||
                strpos($embed, 'audio') !== false ||
                strpos($embed, 'iframe') !== false ||
                strpos($embed, 'object') !== false
            ) {
                return $embed; // Return the first matching embed
            }
        }
    }

    return null;
}


/**
 * HTML Structure Of Read More Button.
 *
 * @param string $link  URL for the read more link.
 * @param string $label Text for the read more link.
 * @param string $extra_classes Optional additional classes for the button.
 * @param array  $attributes Optional extra attributes for the anchor tag.
 * 
 * @return void
 */
function st_get_blog_readmore_link($link, $label = 'Read More', $extra_classes = '', $attributes = [])
{
    // Sanitize and escape URL and label
    $link = esc_url($link);
    $label = esc_html($label);

    // Prepare additional classes
    $classes = 'btn btn-link ' . esc_attr($extra_classes);

    // Build additional attributes string
    $attribute_string = '';
    if (!empty($attributes)) {
        foreach ($attributes as $key => $value) {
            $attribute_string .= ' ' . esc_attr($key) . '="' . esc_attr($value) . '"';
        }
    }

    // Output the button HTML
    echo '<a class="' . $classes . '" href="' . $link . '" ' . $attribute_string . '><span>' . $label . '</span></a>';
}


/**
 * Generate pagination links for a WordPress site.
 *
 * @param int  $numpages   Total number of pages. Defaults to global $wp_query->max_num_pages.
 * @param int  $pagerange  Number of page links to show around the current page. Default is 2.
 * @param int  $paged      Current page number. Defaults to global $paged.
 * @param bool $echo       Whether to echo the pagination HTML or return it. Default is true.
 * 
 * @return string|null    Pagination HTML if $echo is false, otherwise echoes the pagination.
 */
function st_pagination($numpages = '', $pagerange = 2, $paged = 1, $echo = true)
{
    global $wp_query;

    // Ensure global $paged is set if not passed as an argument
    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

    // Determine the total number of pages if not provided
    if (empty($numpages)) {
        $numpages = $wp_query->max_num_pages ? $wp_query->max_num_pages : 1;
    }

    // Construct pagination arguments
    $pagination_args = array(
        'format'        => '?paged=%#%',
        'total'         => $numpages,
        'current'       => $paged,
        'show_all'      => false,
        'end_size'      => 1,
        'mid_size'      => $pagerange,
        'prev_next'     => true,
        'prev_text'     => st_get_icon('arrow-prev'),
        'next_text'     => st_get_icon('arrow-next'),
        'type'          => 'list',
        'add_args'      => false,
        'add_fragment'  => ''
    );

    // Generate pagination links
    $paginate_links = paginate_links($pagination_args);

    // Output or return the pagination links
    if ($paginate_links) {
        $pagination_html = '<div class="col-lg-12 col-md-12 col-sm-12">
                                <div class="pagination justify-content-center">
                                    <nav aria-label="Page navigation">';
        $pagination_html .= sprintf('%s', $paginate_links);
        $pagination_html .= '      </nav>
                                </div>
                            </div>';

        if ($echo) {
            echo $pagination_html;
        } else {
            return $pagination_html;
        }
    }

    return null; // In case no pagination is generated
}

/**
 * Check if the primary navigation menu exists.
 *
 * @return bool True if the primary navigation menu exists, false otherwise.
 */
function st_check_primary_nav_menu()
{
    return has_nav_menu('primary');
}

/**
 * Display the primary navigation menu.
 *
 * @param array $args Optional. An array of arguments to pass to wp_nav_menu(). Default is an empty array.
 */
function display_primary_nav_menu(array $args = [])
{
    // Set default arguments
    $defaults = [
        'container' => 'nav',                // Wrap the menu in a <nav> element for better semantics
        'theme_location' => 'primary',       // The location of the menu
    ];

    // Merge passed arguments with defaults
    $args = array_merge($defaults, $args);

    // Display the menu
    wp_nav_menu($args);
}


/**
 * Adds a div before content based on post type.
 *
 * @param string $post_type The current post type.
 */
add_action('st_before_content', 'st_before_content_action', 10, 1);
function st_before_content_action($post_type)
{
    // Default div opening tag
    $div = '<div class="css_prefix-blog-box">';

    // Allow modification via filter
    $div = apply_filters('st_before_content_action', $div, $post_type);

    // Output the sanitized div
    echo wp_kses_post($div);
}

/**
 * Adds a closing div after content based on post type.
 *
 * @param string $post_type The current post type.
 */
add_action('st_after_content', 'st_after_content_action', 10, 1);
function st_after_content_action($post_type)
{
    // Default div closing tag
    $div = '</div>';

    // Allow modification via filter
    $div = apply_filters('st_after_content_action', $div, $post_type);

    // Output the sanitized div
    echo wp_kses_post($div);
}

/**
 * Formats the runtime from 'H:MM' format to 'Xhr : Ymins' with proper escaping.
 * Allows overriding the formatted runtime via a filter.
 *
 * @param string $run_time Runtime in 'H:MM' format.
 * @return string Formatted and escaped runtime.
 */
function st_format_runtime($run_time)
{
    if (empty($run_time)) return;
    // Split the runtime into hours and minutes
    $time_parts = explode(':', $run_time);
    $hours = isset($time_parts[0]) ? intval($time_parts[0]) : 0; // Get hours
    $minutes = isset($time_parts[1]) ? intval($time_parts[1]) : 0; // Get minutes

    // Create the formatted runtime string
    $formatted_run_time = '';

    // If hours are greater than 0, append hours to the formatted string
    if ($hours > 0) {
        $formatted_run_time .= esc_html($hours) . esc_html__(' h', 'streamit');
    }

    // If minutes are greater than 0, append minutes to the formatted string
    if ($minutes > 0) {
        // Add colon only if hours are present
        if ($hours > 0) {
            $formatted_run_time .= ' : ';
        }
        $formatted_run_time .= esc_html($minutes) . esc_html__(' min', 'streamit');
    }

    // If both hours and minutes are zero, return "0mins"
    if ($hours === 0 && $minutes === 0) {
        return '';
    }

    // Apply the filter to allow overriding the runtime format
    return apply_filters('st_format_runtime', trim($formatted_run_time), $run_time);
}



/**
 * Returns the URL of the default 'search not found' image.
 *
 * This function provides the URL of a default image to display when no search results are found.
 * Developers can modify this URL via the 'streamit_search_not_found_image' filter hook.
 *
 * Example usage of the filter:
 * 
 * // In a plugin or theme, to change the image URL:
 * add_filter('streamit_search_not_found_image', function($image_url) {
 *     return 'https://example.com/path/to/custom-image.png';
 * });
 *
 * @return string The URL of the 'search not found' image.
 */
function streamit_search_not_found_image()
{
    // Get the default search-not-found image URL
    $image_url = get_template_directory_uri() . '/static/assets/images/defaults/search-not-found.png';

    // Allow filtering of the image URL through the 'streamit_search_not_found_image' filter
    return apply_filters('streamit_search_not_found_image', esc_url($image_url));
}


/**
 * Allow additional MIME types for media uploads.
 *
 * This function extends WordPress's allowed MIME types to support
 * various video, image, and other media formats.
 *
 * @param array $mimes Existing allowed MIME types.
 * @return array Modified MIME types array.
 */
function st_allow_all_mime_types($mimes)
{
    // Common Video Formats
    $mimes['mp4']   = 'video/mp4';
    $mimes['webm']  = 'video/webm';
    $mimes['ogv']   = 'video/ogg';
    $mimes['mov']   = 'video/quicktime';
    $mimes['avi']   = 'video/x-msvideo';
    $mimes['mkv']   = 'video/x-matroska';
    $mimes['wmv']   = 'video/x-ms-wmv';
    $mimes['flv']   = 'video/x-flv';
    $mimes['m4v']   = 'video/x-m4v';
    $mimes['ogx']   = 'video/odx';


    // Streaming Formats
    $mimes['m3u8']  = 'application/x-mpegURL';
    $mimes['ts']    = 'video/mp2t';

    // Common Image Formats
    $mimes['jpg']   = 'image/jpeg';
    $mimes['jpeg']  = 'image/jpeg';
    $mimes['png']   = 'image/png';
    $mimes['gif']   = 'image/gif';
    $mimes['bmp']   = 'image/bmp';
    $mimes['webp']  = 'image/webp';
    $mimes['svg']   = 'image/svg+xml';
    $mimes['ico']   = 'image/vnd.microsoft.icon';

    // Subtitle Formats
    $mimes['vtt']   = 'text/vtt';
    $mimes['srt']   = 'application/x-subrip';
    $mimes['ass']   = 'text/x-ssa';
    $mimes['ssa']   = 'text/x-ssa';

    return $mimes;
}
add_filter('upload_mimes', 'st_allow_all_mime_types', 100);

/**
 * Bypass WordPress strict file type checking for subtitle files.
 *
 * WordPress performs additional security checks via wp_check_filetype_and_ext()
 * that can block files even if their MIME type is in the allowed list.
 * This filter ensures subtitle files (VTT, SRT, ASS, SSA) pass validation.
 *
 * @param array  $data File data with type, ext, and proper_filename.
 * @param string $file Full path to the file.
 * @param string $filename The name of the file.
 * @param array  $mimes Allowed MIME types.
 * @return array Modified file data.
 */
function st_allow_subtitle_file_types($data, $file, $filename, $mimes)
{
    // Get file extension
    $filetype = wp_check_filetype($filename, $mimes);
    $ext = $filetype['ext'];
    $type = $filetype['type'];

    // List of subtitle extensions we want to allow
    $subtitle_extensions = array('vtt', 'srt', 'ass', 'ssa');

    // If this is a subtitle file, override the validation
    if (in_array($ext, $subtitle_extensions)) {
        $data['ext'] = $ext;
        $data['type'] = $type;
    }

    return $data;
}
add_filter('wp_check_filetype_and_ext', 'st_allow_subtitle_file_types', 10, 4);



/**
 * Convert a release date to readable WordPress format.
 *
 * @param string|int $release_date MySQL date string or timestamp.
 * @return string Formatted readable date.
 */
function streamit_get_readable_release_date($release_date)
{
    if (empty($release_date)) {
        return '';
    }

    // Convert to timestamp if it's a string date
    if (! is_numeric($release_date)) {
        $release_date = strtotime($release_date);
    }

    return date_i18n(get_option('date_format'), $release_date);
}

/**
 * Check if the Miniorange Social Login is configured.
 *
 * @return bool True if the Miniorange Social Login is configured, false otherwise.
 */
function streamit_mo_social_login_is_enabled()
{
    $providers = [
        'mo_openid_google_enable',
        'mo_openid_salesforce_enable',
        'mo_openid_facebook_enable',
        'mo_openid_linkedin_enable',
        'mo_openid_amazon_enable',
        'mo_openid_twitter_enable',
        'mo_openid_vkontakte_enable',
        'mo_openid_yahoo_enable',
        'mo_openid_snapchat_enable',
        'mo_openid_dribbble_enable',
        'mo_openid_discord_enable',
    ];

    foreach ($providers as $provider) {
        if (get_option($provider)) {
            return true;
        }
    }

    return false;
}

/**
 * Render content with iframe embeds safely.
 *
 * This function sanitizes content while preserving iframe embeds for video players
 * like YouTube, Vimeo, etc. It uses wp_kses() to allow specific HTML tags and
 * attributes, maintaining security while enabling rich media content.
 *
 * @param string $content The content to render (may contain HTML and iframes).
 * @param bool   $wpautop Whether to apply wpautop() for paragraph formatting. Default true.
 * 
 * @return string Sanitized content with allowed HTML and iframe tags.
 */
function streamit_render_content_with_iframes($content, $wpautop = true)
{
    // Return empty string if no content provided
    if (empty($content)) {
        return '';
    }

    // Get allowed HTML tags for post content
    $allowed_tags = wp_kses_allowed_html('post');

    // Add iframe to allowed tags with specific attributes
    $allowed_tags['iframe'] = [
        'src'                => true,
        'width'              => true,
        'height'             => true,
        'frameborder'        => true,
        'allow'              => true,
        'allowfullscreen'    => true,
        'allowtransparency'  => true,
        'title'              => true,
        'class'              => true,
        'id'                 => true,
        'style'              => true,
        'loading'            => true,
        'name'               => true,
    ];

    // Sanitize content with allowed tags
    $sanitized_content = wp_kses($content, $allowed_tags);

    // Apply wpautop if requested
    if ($wpautop) {
        $sanitized_content = wpautop($sanitized_content);
    }

    // Allow filtering of the final output
    return apply_filters('streamit_render_content_with_iframes', $sanitized_content, $content);
}

/**
 * Get text-only content from post content, stripping iframes and embeds.
 *
 * This function is used for preview/excerpt display where we only want
 * to show text content, not embedded media like iframes.
 *
 * @param string $content The content to process.
 * @return string Text-only content with iframes and embeds removed.
 */
function streamit_get_text_only_content($content)
{
    if (empty($content)) {
        return '';
    }

    // Remove iframe tags
    $content = preg_replace('/<iframe[^>]*>.*?<\/iframe>/is', '', $content);

    // Remove other embed tags that might be present
    $content = preg_replace('/<embed[^>]*>/is', '', $content);
    $content = preg_replace('/<object[^>]*>.*?<\/object>/is', '', $content);

    // Strip all remaining HTML tags
    $content = strip_tags($content);

    // Clean up extra whitespace
    $content = preg_replace('/\s+/', ' ', $content);
    $content = trim($content);

    return $content;
}


/**
 * Allow iframe in wp_kses for all contexts.
 * 
 * This ensures iframes are not stripped when content is saved.
 *
 * @param array $allowed_tags Allowed HTML tags.
 * @return array Modified allowed tags with iframe support.
 */
function streamit_allow_iframe_in_editor($allowed_tags)
{
    if (!isset($allowed_tags['iframe'])) {
        $allowed_tags['iframe'] = array(
            'src'               => true,
            'height'            => true,
            'width'             => true,
            'frameborder'       => true,
            'allowfullscreen'   => true,
            'title'             => true,
            'allow'             => true,
            'class'             => true,
            'style'             => true,
            'allowtransparency' => true,
            'name'              => true,
            'align'             => true,
            'scrolling'         => true,
            'data-testid'       => true,
        );
    }
    return $allowed_tags;
}
add_filter('wp_kses_allowed_html', 'streamit_allow_iframe_in_editor', 99, 1);

/**
 * Add iframe to TinyMCE valid elements.
 *
 * @param array $init_array TinyMCE init array.
 * @return array Modified TinyMCE settings.
 */
function streamit_tinymce_allow_iframe($init_array)
{
    $existing_elements = isset($init_array['extended_valid_elements']) ? $init_array['extended_valid_elements'] . ',' : '';
    $init_array['extended_valid_elements'] = $existing_elements . 'iframe[src|width|height|name|align|style|frameborder|allowfullscreen|scrolling|allowtransparency|allow|data-*]';
    return $init_array;
}
add_filter('tiny_mce_before_init', 'streamit_tinymce_allow_iframe', 99);

/**
 * Add custom TinyMCE button for inserting iframes.
 *
 * @param array $plugin_array TinyMCE plugins array.
 * @return array Modified plugins array.
 */
function streamit_add_tinymce_iframe_plugin($plugin_array)
{
    $plugin_array['streamit_iframe_button'] = get_template_directory_uri() . '/static/assets/js/tinymce-iframe-plugin.js';
    return $plugin_array;
}

/**
 * Register TinyMCE iframe button.
 *
 * @param array $buttons TinyMCE buttons array.
 * @return array Modified buttons array.
 */
function streamit_register_tinymce_iframe_button($buttons)
{
    array_push($buttons, 'streamit_iframe_button');
    return $buttons;
}

/**
 * Initialize TinyMCE iframe button.
 */
function streamit_tinymce_iframe_button_init()
{
    if (current_user_can('edit_posts') && current_user_can('edit_pages')) {
        add_filter('mce_external_plugins', 'streamit_add_tinymce_iframe_plugin');
        add_filter('mce_buttons', 'streamit_register_tinymce_iframe_button');
    }
}
add_action('admin_init', 'streamit_tinymce_iframe_button_init');

/**
 * Overrides the global theme options with specific page meta when visiting the blog listing page
 * or other pages that act as archives but have a backing page ID.
 */
function streamit_apply_page_meta_to_options()
{
	global $streamit_options;

	$page_id = false;

	// Detection logic for the blog listing page (Backing Page in Reading Settings)
	if (is_home() && !is_front_page()) {
		$page_id = get_option('page_for_posts');
	}

	if (!$page_id) {
		return;
	}

	if ($page_id) {
		$meta_keys = [
			'display_header_meta',
			'select_header_logo_meta',
			'header_sticky_meta',
			'header_padding_top_meta',
			'display_footer_meta',
			'default_footer_meta',
			'select_footer_bg_meta',
			'select_footer_logo_meta',
			'display_color_pallet_meta',
			'primary_color_meta',
			'secondary_color_meta',
			'title_color_meta',
			'page_text_color_meta',
			'display_banner_meta',
		];

		foreach ($meta_keys as $key) {
			$meta_value = get_post_meta($page_id, $key, true);
			if ($meta_value !== '' && $meta_value !== 'default' && $meta_value !== null) {
				$streamit_options[$key] = $meta_value;
			}
		}
	}
}
add_action('wp', 'streamit_apply_page_meta_to_options', 20);

