import sliderManager from "../core/slider-manager";
import { post } from "../../../../static/assets/utilities/ajax.js";

/**
 * TV Show Season Swiper Builder
 *
 * - Initialises the main TV Show poster slider via sliderManager.
 * - Listens for season-tab clicks and loads episodes via AJAX with
 *   per-element, per-season in-memory caching so identical requests
 *   NEVER hit the server twice.
 * - When the active slide changes it syncs the episode panel to the
 *   new TV show's first season automatically.
 */

/** Element-level cache: element → Map<"tvshowId_seasonIndex", htmlString> */
const seasonCache = new WeakMap();

/** Track pending AJAX requests to avoid duplicate in-flight fetches */
const pendingFetches = new WeakMap();

/**
 * Build the episode list HTML from the AJAX response result array.
 * Each `block_main_content` is already a full `<li>` rendered by the
 * shared `episode-item.php` PHP partial — so we just join and wrap.
 *
 * @param {Array}  results  - Array of { block_main_content } objects
 * @returns {string} HTML string
 */
function buildEpisodeHTML(results) {
    if (!results || results.length === 0) {
        return `<p class="no_data_found animated fadeIn">No Episodes Available</p>`;
    }

    const items = results
        .map(ep => ep.block_main_content || '')
        .join('');

    return `<ul class="season-episodes-details list-unstyled animated fadeIn">${items}</ul>`;
}

function showSkeleton(panel) {
    panel.classList.add('st-skeleton');
    
    const shimmerGradient = 'linear-gradient(90deg, #141414 25%, #2a2a2a 50%, #141414 75%)';
    
    let skeletons = '';
    for(let i=0; i<4; i++) {
        skeletons += `
        <li class="episodes-info">
            <article class="episode-card-content" style="display: flex; align-items: center; gap: 1.5em; width: 100%;">
                <header class="episode-img" style="flex-shrink: 0; margin-top: 0;">
                    <div style="width: 7.5em; height: 5.3125em; border-radius: 4px; background: ${shimmerGradient}; background-size: 200% 100%; animation: shimmer 1.5s infinite linear;"></div>
                </header>
                <div class="episodes-meta" style="flex-grow: 1;">
                    <div style="width: 80%; max-width: 250px; height: 20px; border-radius: 4px; background: ${shimmerGradient}; background-size: 200% 100%; animation: shimmer 1.5s infinite linear; margin-bottom: 10px;"></div>
                    <div style="width: 30%; max-width: 100px; height: 16px; border-radius: 4px; background: ${shimmerGradient}; background-size: 200% 100%; animation: shimmer 1.5s infinite linear;"></div>
                </div>
            </article>
        </li>`;
    }

    panel.innerHTML = `<ul class="season-episodes-details list-unstyled" style="display: flex; flex-direction: column; gap: 1.25em;">${skeletons}</ul>`;
}

/**
 * Swap season tabs:  deactivate old, activate new, update ARIA states.
 * @param {HTMLElement} wrapper   - `.nav-tabs-inner` element
 * @param {HTMLElement} activeTab - The newly-clicked tab link
 */
function activateTab(wrapper, activeTab) {
    wrapper.querySelectorAll('.css_prefix-episodes-meta').forEach(tab => {
        tab.classList.remove('active');
        tab.setAttribute('aria-selected', 'false');
    });
    activeTab.classList.add('active');
    activeTab.setAttribute('aria-selected', 'true');
}

/**
 * Update the episode panel to show a specific TV show's seasons.
 * Rebuilds the season tab bar and loads the first season immediately.
 *
 * @param {HTMLElement} widget      - Root `.css_prefix-tvshow-season-parent`
 * @param {number}      tvshowId    - Post ID of the TV show
 * @param {Array}       seasons     - Array of season objects from slide data-seasons
 * @param {Object}      swiperInst  - The Swiper instance (used to get show URLs from slides)
 */
function switchToShow(widget, tvshowId, seasons, swiperInst) {
    const tabBar = widget.querySelector('.nav-tabs-inner');
    const panel = widget.querySelector('.season-content');
    if (!tabBar || !panel) return;

    // Rebuild tab bar for this TV show
    tabBar.setAttribute('data-first_tvshow_id', tvshowId);
    tabBar.innerHTML = seasons.map((s, i) =>
        `<a class="nav-item nav-link css_prefix-episodes-meta tvshow-${tvshowId} ${i === 0 ? 'active' : ''}"
            href="#" role="tab"
            data-tvshow-id="${tvshowId}"
            data-season="${i}"
            data-ajax-loaded="0"
            aria-selected="${i === 0}">
            ${s.name || ''}
        </a>`
    ).join('');

    // Immediately load the first season
    const firstTab = tabBar.querySelector('.css_prefix-episodes-meta');
    if (firstTab) {
        loadSeasonEpisodes(widget, firstTab);
    }
}

/**
 * Core AJAX loader — fetches episodes for a season tab, uses cache.
 *
 * @param {HTMLElement} widget - Root section element
 * @param {HTMLElement} tab    - The clicked `.css_prefix-episodes-meta` anchor
 */
function loadSeasonEpisodes(widget, tab) {
    const tvshowId = tab.dataset.tvshowId;
    const seasonIndex = parseInt(tab.dataset.season ?? 0, 10);
    const cacheKey = `${tvshowId}_${seasonIndex}`;
    const panel = widget.querySelector('.season-content');
    const tabWrapper = widget.querySelector('.nav-tabs-inner');

    if (!panel) return;

    activateTab(tabWrapper, tab);

    // --- HIT CACHE ---
    if (!seasonCache.has(widget)) seasonCache.set(widget, new Map());
    const elCache = seasonCache.get(widget);

    if (elCache.has(cacheKey)) {
        panel.classList.remove('st-skeleton');
        panel.innerHTML = elCache.get(cacheKey);
        return;
    }

    // --- DEDUPLICATE IN-FLIGHT REQUESTS ---
    if (!pendingFetches.has(widget)) pendingFetches.set(widget, new Set());
    const pending = pendingFetches.get(widget);

    if (pending.has(cacheKey)) return; // already in flight
    pending.add(cacheKey);

    // --- SKELETON → FETCH ---
    showSkeleton(panel);

    // Gather season episodes array from the active slide's data-seasons
    const activeSlide = widget.querySelector('.swiper-slide-active[data-seasons]')
        ?? widget.querySelector('[data-post]');

    let seasons = [];
    try {
        seasons = activeSlide ? JSON.parse(activeSlide.dataset.seasons || '[]') : [];
    } catch (_) { }

    post('tvshow_tab_seasons_data', {
        data: seasons,
        season: seasonIndex,
        tvshow_id: tvshowId,
        is_slider: false,
    })
        .then(res => {
            let json;
            try { json = JSON.parse(res); } catch (_) { json = null; }

            pending.delete(cacheKey);
            panel.classList.remove('st-skeleton');

            if (json?.success && json.result?.length) {
                const html = buildEpisodeHTML(json.result);
                elCache.set(cacheKey, html);
                panel.innerHTML = html;
            } else {
                panel.innerHTML = `<p class="no_data_found">No Episodes Available</p>`;
            }
        })
        .catch(() => {
            pending.delete(cacheKey);
            panel.classList.remove('st-skeleton');
            panel.innerHTML = `<p class="no_data_found">Error loading episodes.</p>`;
        });
}

// ─── Swiper Registration ────────────────────────────────────────────────────

sliderManager.register('tvshow-season', (element, DEFAULT_CONFIG, MODULES) => {
    const data = element.dataset;

    const config = {
        ...DEFAULT_CONFIG,
        modules: MODULES,
        slidesPerView: 1,
        loop: data.loop === 'true',
        speed: parseFloat(data.speed) || 300,
        autoplay: false,
        navigation: data.navigation === 'true'
            ? {
                nextEl: element.parentElement?.querySelector('.swiper-button-next'),
                prevEl: element.parentElement?.querySelector('.swiper-button-prev'),
            }
            : false,
        pagination: {
            el: element.querySelector('.swiper-pagination'),
            clickable: true,
        },
        on: {
            init(swiper) {
                // Initialize the custom 5-bullet window
                updatePaginationWindow(swiper);
            },
            slideChange(swiper) {
                // Keep pagination window in sync
                updatePaginationWindow(swiper);
            },
            afterInit(swiper) {
                // Bind season-tab clicks (event delegation on widget root)
                const widget = element.closest('.css_prefix-tvshow-season-parent');
                if (!widget) return;

                widget.addEventListener('click', e => {
                    const tab = e.target.closest('.css_prefix-episodes-meta');
                    if (!tab) return;
                    e.preventDefault();
                    loadSeasonEpisodes(widget, tab);
                });
            },

            slideChangeTransitionEnd(swiper) {
                const widget = element.closest('.css_prefix-tvshow-season-parent');
                if (!widget) return;

                const activeSlide = swiper.slides[swiper.activeIndex];
                if (!activeSlide) return;

                const tvshowId = activeSlide.dataset.post;
                let seasons = [];
                try { seasons = JSON.parse(activeSlide.dataset.seasons || '[]'); } catch (_) { }

                if (tvshowId && seasons.length) {
                    switchToShow(widget, tvshowId, seasons, swiper);
                }
            },
        },
    };

    // --- Core 5-Bullet Tapered Pagination Window Logic ---
    function updatePaginationWindow(swiper) {
        const paginationEl = element.querySelector('.swiper-pagination');
        if (!paginationEl) return;

        // Clean dynamically injected Swiper inline styles
        paginationEl.classList.remove('swiper-pagination-bullets-dynamic');
        paginationEl.style.width = '';

        const bullets = Array.from(paginationEl.querySelectorAll('.swiper-pagination-bullet'));
        const total = bullets.length;
        if (!total) return;

        const active = swiper.realIndex;

        bullets.forEach((bullet) => {
            bullet.classList.remove(
                'swiper-pagination-bullet-active-main',
                'swiper-pagination-bullet-active-prev',
                'swiper-pagination-bullet-active-prev-prev',
                'swiper-pagination-bullet-active-next',
                'swiper-pagination-bullet-active-next-next'
            );
            // Clean Swiper inline loop properties, but also 'order' for flex sorting
            bullet.style.left = '';
            bullet.style.transform = '';
            bullet.style.order = '';
        });

        const assignClass = (index, className, orderVal) => {
            const el = bullets[index];
            if (el && !el.className.match(/swiper-pagination-bullet-active-/)) {
                el.classList.add(className);
                el.style.order = orderVal;
            }
        };

        assignClass(active, 'swiper-pagination-bullet-active-main', 3);

        if (total > 1) {
            assignClass((active + 1) % total, 'swiper-pagination-bullet-active-next', 4);
            assignClass((active - 1 + total) % total, 'swiper-pagination-bullet-active-prev', 2);
        }

        if (total > 3) {
            assignClass((active + 2) % total, 'swiper-pagination-bullet-active-next-next', 5);
            assignClass((active - 2 + total) % total, 'swiper-pagination-bullet-active-prev-prev', 1);
        }
    }

    return config;
});
