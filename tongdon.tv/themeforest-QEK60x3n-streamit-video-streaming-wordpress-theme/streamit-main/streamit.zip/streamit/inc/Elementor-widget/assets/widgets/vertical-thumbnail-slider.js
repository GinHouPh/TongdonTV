import sliderManager from "../core/slider-manager";
import Swiper from "swiper";
import { Navigation, Pagination, Thumbs, Controller, EffectFade, FreeMode } from "swiper/modules";

// ===================== Slider Registration =====================
sliderManager.register("vertical-thumbnail", (element, DEFAULT_CONFIG, MODULES) => {

    const mainEl = element.querySelector(".vertical-banner-content");
    const thumbEl = element.querySelector(".vertical-banner-thumb");
    const prevBtn = element.querySelector('.vertical-btn-prev');
    const nextBtn = element.querySelector('.vertical-btn-next');

    if (!mainEl || !thumbEl) return false;

    // Height helper (Desktop vertical view)
    const updateThumbHeight = () => {
        if (window.innerWidth >= 768) {
            const slideW = thumbEl.offsetWidth;
            const slideH = slideW * (2.5 / 4.5);
            thumbEl.style.height = `${slideH * 3 + 40}px`;
            if (thumbsSwiper) thumbsSwiper.update();
        } else {
            thumbEl.style.height = "auto";
            if (thumbsSwiper) thumbsSwiper.update();
        }
    };
    window.addEventListener("resize", updateThumbHeight);

    function setActiveClass(swiperInstance, realIndex) {
        if (!swiperInstance) return;
        swiperInstance.slides.forEach((slide) => {
            const idx = parseInt(slide.getAttribute("data-swiper-slide-index") ?? "-1", 10);
            slide.classList.toggle("is-active", idx === realIndex);
        });
    }

    function syncActiveState(realIndex) {
        setActiveClass(mainSlider, realIndex);
        setActiveClass(thumbsSwiper, realIndex);

        if (thumbsSwiper && typeof thumbsSwiper.slideToLoop === "function") {
            thumbsSwiper.slideToLoop(realIndex, 300);
        }
    }

    // 1. Thumb Swiper (Horizontal on Mobile, Vertical on Desktop)
    const thumbsSwiper = new Swiper(thumbEl, {
        modules: [Navigation, FreeMode],
        loop: true,
        spaceBetween: 20,
        watchSlidesProgress: true,
        breakpoints: {
            0: {
                direction: "horizontal",
                slidesPerView: "auto",
                freeMode: {
                    enabled: true,
                    sticky: false,
                    momentumRatio: 1.2,
                    momentumVelocityRatio: 1.2,
                },
                centeredSlides: false
            },
            768: {
                direction: "vertical",
                slidesPerView: 3,
                freeMode: {
                    enabled: false,
                },
                centeredSlides: false
            },
        },
    });

    // Call height helper after Swiper is initialized
    updateThumbHeight();

    // Check if the DOM wrapper specifies an effect (e.g., data-effect="slide")
    const effectOption = element.dataset.effect || "fade";

    // 2. Main Banner Swiper
    const mainSlider = new Swiper(mainEl, {
        modules: [Navigation, Pagination, Thumbs, Controller, EffectFade],
        loop: true,
        effect: 'fade' === effectOption ? 'fade' : effectOption,
        fadeEffect: {
            crossFade: true
        },
        draggable: true,
        allowTouchMove: true,
        grabCursor: true,
        speed: 500,
        thumbs: {
            swiper: thumbsSwiper,
        },
        // Pagination — rendered always, visibility controlled by CSS (hidden on desktop)
        pagination: {
            el: mainEl.querySelector('.swiper-pagination'),
            clickable: true,
        },
        // Navigation arrows
        navigation: {
            prevEl: prevBtn,
            nextEl: nextBtn
        },
    });

    function updatePaginationWindow() {
        const paginationEl = mainEl.querySelector('.swiper-pagination');
        if (!paginationEl) return;

        // Strip Swiper's dynamic sizing inline styles if they persist
        paginationEl.classList.remove('swiper-pagination-bullets-dynamic');
        paginationEl.style.width = '';

        const bullets = Array.from(paginationEl.querySelectorAll('.swiper-pagination-bullet'));
        const total = bullets.length;
        if (!total) return;

        const active = mainSlider.realIndex;

        bullets.forEach((bullet) => {
            bullet.classList.remove(
                'swiper-pagination-bullet-active-main',
                'swiper-pagination-bullet-active-prev',
                'swiper-pagination-bullet-active-prev-prev',
                'swiper-pagination-bullet-active-next',
                'swiper-pagination-bullet-active-next-next'
            );
            // Clean inline position styles Swiper tries to apply, but clear order too
            bullet.style.left = '';
            bullet.style.transform = '';
            bullet.style.order = '';
        });

        // Priority assignment function to prevent collisions on low slide counts
        const assignClass = (index, className, orderVal) => {
            const el = bullets[index];
            // Only assign if it hasn't received a higher priority active class yet
            if (el && !el.className.match(/swiper-pagination-bullet-active-/)) {
                el.classList.add(className);
                el.style.order = orderVal;
            }
        };

        // 1. Assign Main Center (Middle -> order 3)
        assignClass(active, 'swiper-pagination-bullet-active-main', 3);

        // 2. Assign Immediate Prev/Next (Level 1)
        if (total > 1) {
            assignClass((active + 1) % total, 'swiper-pagination-bullet-active-next', 4);
            assignClass((active - 1 + total) % total, 'swiper-pagination-bullet-active-prev', 2);
        }

        // 3. Assign Outer Prev/Next (Level 2)
        if (total > 3) {
            assignClass((active + 2) % total, 'swiper-pagination-bullet-active-next-next', 5);
            assignClass((active - 2 + total) % total, 'swiper-pagination-bullet-active-prev-prev', 1);
        }
    }

    // Sync: Main → Thumb Visual (Active Class) + pagination window
    mainSlider.on("slideChange", () => {
        syncActiveState(mainSlider.realIndex);
        updatePaginationWindow();
    });

    mainSlider.on("transitionEnd", () => {
        syncActiveState(mainSlider.realIndex);
        updatePaginationWindow();
    });

    // Sync: Thumb click
    thumbsSwiper.on("click", (_swiper, event) => {
        const slide = event.target.closest(".swiper-slide");
        if (!slide) return;
        const realIdx = parseInt(slide.getAttribute("data-swiper-slide-index") ?? "-1", 10);
        if (isNaN(realIdx) || realIdx === mainSlider.realIndex) return;
        mainSlider.slideToLoop(realIdx, 300);
    });

    // Keyboard support on thumb slides
    thumbEl.addEventListener("keydown", (e) => {
        if (e.key !== "Enter" && e.key !== " ") return;
        const slide = e.target.closest(".swiper-slide");
        if (!slide) return;
        e.preventDefault();
        const realIdx = parseInt(slide.getAttribute("data-swiper-slide-index") ?? "-1", 10);
        if (!isNaN(realIdx)) mainSlider.slideToLoop(realIdx, 300);
    });

    // Initial sync
    syncActiveState(mainSlider.realIndex);
    updatePaginationWindow();

    // Manual cleanup when slider is removed
    const observer = new MutationObserver(() => {
        if (!document.contains(element)) {
            window.removeEventListener("resize", updateThumbHeight);
            if (thumbsSwiper) thumbsSwiper.destroy(true, true);
            if (mainSlider) mainSlider.destroy(true, true);
            observer.disconnect();
        }
    });
    observer.observe(document.body, { childList: true, subtree: true });

    element._swiperInstances = [mainSlider, thumbsSwiper];

    // CRITICAL: Return false so `sliderManager.js` skips auto-initializing Swiper on the parent!
    return false;
});
