import sliderManager from "../core/slider-manager";


sliderManager.register(
    "continue-watching",

    (element, DEFAULT_CONFIG, MODULES) => {

        const data = element.dataset;
        const navigationElements = {
            nextEl: element.parentElement?.querySelector('.swiper-button-next'),
            prevEl: element.parentElement?.querySelector('.swiper-button-prev'),
        };
        const desktopNavigation = data.navigation === "true";
        const laptopNavigation = data.navigationLaptop === "true";
        const tabletNavigation = data.navigationTablet === "true";
        const mobileNavigation = data.navigationMobile === "true";

        return {

            modules: MODULES,

            ...DEFAULT_CONFIG,

            slidesPerView:
                parseFloat(data.slides) || 6,

            speed:
                parseFloat(data.speed) || 300,

            loop:
                data.loop === "true",

            autoplay:
                data.autoplay === "true"
                    ?
                    {
                        delay:
                            parseFloat(data.delay) || 2000,

                        disableOnInteraction: false
                    }
                    :
                    false,


            navigation:
                desktopNavigation || laptopNavigation || tabletNavigation || mobileNavigation
                    ? navigationElements
                    :
                    false,


            breakpoints:
            {

                1400:
                {
                    slidesPerView:
                        parseFloat(data.slides) || 6,
                    navigation: desktopNavigation ? navigationElements : false
                },

                1024:
                {
                    slidesPerView:
                        parseFloat(data.lap) || 4,
                    navigation: laptopNavigation ? navigationElements : false
                },

                768:
                {
                    slidesPerView:
                        parseFloat(data.tab) || 3,
                    navigation: tabletNavigation ? navigationElements : false
                },

                0:
                {
                    slidesPerView:
                        parseFloat(data.mob) || 2,
                    navigation: mobileNavigation ? navigationElements : false
                }

            }

        };

    });
