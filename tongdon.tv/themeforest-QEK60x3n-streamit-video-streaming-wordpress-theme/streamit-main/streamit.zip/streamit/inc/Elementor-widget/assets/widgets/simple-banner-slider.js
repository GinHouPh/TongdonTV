import sliderManager from "../core/slider-manager";

sliderManager.register(
    "simple-banner",
    (element, DEFAULT_CONFIG, MODULES) => {

        const data = element.dataset;

        return {

            ...DEFAULT_CONFIG,

            modules: MODULES,

            slidesPerView: data.center === "true" ? 'auto' : 1,
            centeredSlides: data.center === "true",


            speed: parseFloat(data.speed) || 300,

            loop: true,

            autoplay: data.autoplay === "true"
                ? {
                    delay: parseFloat(data.delay) || 2000,
                    disableOnInteraction: false,
                }
                : false,

            navigation: data.navigation === "true"
                ? {
                    nextEl: element.parentElement?.querySelector('.swiper-button-next'),
                    prevEl: element.parentElement?.querySelector('.swiper-button-prev'),
                }
                : false,

            pagination: data.pagination === "true"
                ? {
                    el: element.querySelector(".swiper-pagination"),
                    clickable: true,
                }
                : false,
        };
    }
);
