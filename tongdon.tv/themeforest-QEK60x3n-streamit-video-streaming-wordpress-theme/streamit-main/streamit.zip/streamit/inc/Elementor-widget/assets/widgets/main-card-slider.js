import sliderManager from "../core/slider-manager";

sliderManager.register("main-card", (element, DEFAULT_CONFIG, MODULES) => {

    const data = element.dataset;
    const navigationElements = {
        nextEl: element.parentElement?.querySelector('.js-swiper-next') || element.querySelector('.js-swiper-next') || element.parentElement?.querySelector('.swiper-button-next'),
        prevEl: element.parentElement?.querySelector('.js-swiper-prev') || element.querySelector('.js-swiper-prev') || element.parentElement?.querySelector('.swiper-button-prev'),
    };
    const desktopNavigation = data.navigation === "true";
    const laptopNavigation = data.navigationLaptop === "true";
    const tabletNavigation = data.navigationTablet === "true";
    const mobileNavigation = data.navigationMobile === "true";

    const desk = parseFloat(data.desk) || 6;
    const lap = parseFloat(data.lap) || 4;
    const tab = parseFloat(data.tab) || 3;
    const mob = parseFloat(data.mob) || 2;

    const spaceBetween = parseInt(data.space) || 24;
    const spaceBetweenMob = parseInt(data.spaceMob) || 12;

    return {

        ...DEFAULT_CONFIG,

        modules: MODULES,

        slidesPerView: desk,

        spaceBetween: spaceBetween,

        speed: parseFloat(data.speed) || 300,

        loop: data.loop === "true",

        autoplay: data.autoplay === "true"
            ? {
                delay: parseFloat(data.delay) || 2000,
                disableOnInteraction: false,
            }
            : false,

        navigation: desktopNavigation || laptopNavigation || tabletNavigation || mobileNavigation
            ? navigationElements
            : false,

        // pagination: data.pagination === "true"
        //     ? {
        //         el: element.parentElement?.querySelector('.swiper-pagination') || element.querySelector('.swiper-pagination'),
        //         clickable: true,
        //     }
        //     : false,

        breakpoints: {
            0: {
                slidesPerView: parseFloat(data.mob) || 2,
                spaceBetween: spaceBetweenMob,
                navigation: mobileNavigation ? navigationElements : false,
                freeMode: {
                    enabled: true,
                    sticky: false,
                    momentumRatio: 1.2,
                    momentumVelocityRatio: 1.2,
                },
            },
            768: {
                slidesPerView: parseFloat(data.tab) || 3,
                spaceBetween: spaceBetweenMob,
                navigation: tabletNavigation ? navigationElements : false,
                freeMode: {
                    enabled: true,
                    sticky: false,
                    momentumRatio: 1.2,
                    momentumVelocityRatio: 1.2,
                },
            },
            1024: {
                slidesPerView: lap,
                spaceBetween: spaceBetween,
                cssMode: false,
                navigation: laptopNavigation ? navigationElements : false,
                freeMode: {
                    enabled: false,
                },
            },
            1400: {
                slidesPerView: desk,
                spaceBetween: spaceBetween,
                cssMode: false,
                navigation: desktopNavigation ? navigationElements : false,
                freeMode: {
                    enabled: false,
                },
            }
        }

    };

});
