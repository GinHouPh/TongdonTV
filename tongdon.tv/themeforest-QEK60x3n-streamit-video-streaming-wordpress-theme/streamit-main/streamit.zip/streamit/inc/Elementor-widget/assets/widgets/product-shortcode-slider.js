import sliderManager from "../core/slider-manager";

sliderManager.register("product-shortcode", (container, DEFAULT, MODULES) => {

    const allProductItems = Array.from(
        container.querySelectorAll(".css_prefix-sub-product, .product")
    ).filter((item) => item.closest(".js-streamit-slider") === container);

    if (!allProductItems.length) return DEFAULT;

    const wrapper = document.createElement("div");
    wrapper.className = "products product-grid-style swiper-wrapper";

    allProductItems.forEach((item) => {
        item.classList.add("swiper-slide");

        Array.from(item.classList).forEach((className) => {
            if (className === "col" || className.startsWith("col-")) {
                item.classList.remove(className);
            }
        });

        wrapper.appendChild(item);
    });

    container.innerHTML = "";
    container.appendChild(wrapper);

    const desktopNavigation = container.dataset.navigation === "true";
    const laptopNavigation = container.dataset.navigationLaptop === "true";
    const tabletNavigation = container.dataset.navigationTablet === "true";
    const mobileNavigation = container.dataset.navigationMobile === "true";
    const hasNavigation = desktopNavigation || laptopNavigation || tabletNavigation || mobileNavigation;
    const existingPrev = container.parentElement?.querySelector(".swiper-button-prev") || container.querySelector(".swiper-button-prev");
    const existingNext = container.parentElement?.querySelector(".swiper-button-next") || container.querySelector(".swiper-button-next");
    const debugInfo = {
        productsPerPage: Number(container.dataset.debugProductsPerPage) || null,
        desktopSlides: Number(container.dataset.slides) || 5,
        laptopSlides: Number(container.dataset.lap) || 4,
        tabletSlides: Number(container.dataset.tab) || 3,
        mobileSlides: Number(container.dataset.mob) || 2,
        productCount: allProductItems.length,
        hasNavigation,
    };

    if (window.console?.debug && container.dataset.debugProductsPerPage) {
        console.debug("Streamit Product Shortcode Slider Init", debugInfo);
    }

    /* navigation */
    if (hasNavigation && (!existingPrev || !existingNext)) {

        const prev = document.createElement("div");
        prev.className = "swiper-button-prev";

        const next = document.createElement("div");
        next.className = "swiper-button-next";

        container.append(prev, next);
    }

    const navigationElements = {
        nextEl: container.parentElement?.querySelector(".swiper-button-next") || container.querySelector(".swiper-button-next"),
        prevEl: container.parentElement?.querySelector(".swiper-button-prev") || container.querySelector(".swiper-button-prev"),
    };

    return {

        ...DEFAULT,

        modules: MODULES,

        slidesPerView: Number(container.dataset.slides) || 5,

        loop: container.dataset.loop === "true",

        autoplay: container.dataset.autoplay === "true"
            ? { delay: 2000 }
            : false,

        speed: Number(container.dataset.speed) || 400,

        navigation: hasNavigation ? navigationElements : false,

        observer: true,
        observeParents: true,
        watchOverflow: true,

        breakpoints: {
            0: {
                slidesPerView: Number(container.dataset.mob) || 2,
                navigation: mobileNavigation ? navigationElements : false,
            },
            768: {
                slidesPerView: Number(container.dataset.tab) || 3,
                navigation: tabletNavigation ? navigationElements : false,
            },
            1024: {
                slidesPerView: Number(container.dataset.lap) || 4,
                navigation: laptopNavigation ? navigationElements : false,
            },
            1400: {
                slidesPerView: Number(container.dataset.slides) || 5,
                navigation: desktopNavigation ? navigationElements : false,
            }
        }

    };

});
