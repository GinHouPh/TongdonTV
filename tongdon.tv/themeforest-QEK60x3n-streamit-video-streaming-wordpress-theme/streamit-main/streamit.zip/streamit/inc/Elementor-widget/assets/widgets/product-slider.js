import sliderManager from "../core/slider-manager";

sliderManager.register(
    "product-slider",
    (element, DEFAULT_CONFIG, MODULES) => {

        const data = element.dataset;

        const navigationElements = {
            nextEl: element.parentElement?.querySelector(".swiper-button-next"),
            prevEl: element.parentElement?.querySelector(".swiper-button-prev"),
        };

        const desktopNavigation = data.navigation === "true";
        const laptopNavigation = data.navigationLaptop === "true";
        const tabletNavigation = data.navigationTablet === "true";
        const mobileNavigation = data.navigationMobile === "true";
        const hasNavigation = desktopNavigation || laptopNavigation || tabletNavigation || mobileNavigation;

        return {

            ...DEFAULT_CONFIG,

            modules: MODULES,

            slidesPerView: 1,
            
            speed: parseFloat(data.speed) || 500,

            loop: data.loop === "true",

            autoplay: data.autoplay === "true"
                ? {
                    delay: parseFloat(data.delay) || 5000,
                    disableOnInteraction: false,
                }
                : false,

            navigation: hasNavigation ? navigationElements : false,
            
            breakpoints: {
                0: {
                    navigation: mobileNavigation ? navigationElements : false,
                },
                768: {
                    navigation: tabletNavigation ? navigationElements : false,
                },
                1024: {
                    navigation: laptopNavigation ? navigationElements : false,
                },
                1400: {
                    navigation: desktopNavigation ? navigationElements : false,
                }
            }
        };
    }
);
