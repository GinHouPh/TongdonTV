import Swiper from 'swiper';
import { Navigation, Pagination, Autoplay, Thumbs, Controller, FreeMode } from 'swiper/modules';

import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';

export { Swiper, Navigation, Pagination, Autoplay, Thumbs, Controller, FreeMode };
export default Swiper;
