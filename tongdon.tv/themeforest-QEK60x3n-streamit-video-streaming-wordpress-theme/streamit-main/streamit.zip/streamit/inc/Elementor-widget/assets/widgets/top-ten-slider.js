import sliderManager from "../core/slider-manager";

sliderManager.register("top-ten", (element, DEFAULT_CONFIG, MODULES) => {

    const data = element.dataset;
    const navigationElements = {
        nextEl: element.parentElement?.querySelector('.swiper-button-next'),
        prevEl: element.parentElement?.querySelector('.swiper-button-prev'),
    };
    const desktopNavigation = data.navigation === "true";
    const laptopNavigation = data.navigationLaptop === "true";
    const tabletNavigation = data.navigationTablet === "true";
    const mobileNavigation = data.navigationMobile === "true";

    return {

        modules: MODULES,

        ...DEFAULT_CONFIG,

        slidesPerView:
            parseFloat(data.slides) || 6,

        speed:
            parseInt(data.speed) || 400,

        loop:
            data.loop === "true",

        autoplay:
            data.autoplay === "true"
                ? {
                    delay:
                        parseInt(data.delay) || 2000,
                    disableOnInteraction: false
                }
                : false,


        navigation:
            desktopNavigation || laptopNavigation || tabletNavigation || mobileNavigation
                ? navigationElements
                : false,


        breakpoints: {
            0: {
                slidesPerView: parseFloat(data.mob) || 2,
                navigation: mobileNavigation ? navigationElements : false,
                freeMode: {
                    enabled: true,
                    sticky: false,
                    momentumRatio: 1.2,
                    momentumVelocityRatio: 1.2,
                },
            },
            768: {
                slidesPerView: parseFloat(data.tab) || 3,
                navigation: tabletNavigation ? navigationElements : false,
                freeMode: {
                    enabled: true,
                    sticky: false,
                    momentumRatio: 1.2,
                    momentumVelocityRatio: 1.2,
                },
            },
            1024: {
                slidesPerView: parseFloat(data.lap) || 4,
                navigation: laptopNavigation ? navigationElements : false,
                freeMode: {
                    enabled: false,
                },
            },
            1400: {
                slidesPerView: parseFloat(data.slides) || 6,
                navigation: desktopNavigation ? navigationElements : false,
                freeMode: {
                    enabled: false,
                },
            }
        }

    };

});
