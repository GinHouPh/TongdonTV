import sliderManager from "../core/slider-manager";

sliderManager.register("tags", (element, DEFAULT_CONFIG, MODULES) => {

    const data = element.dataset;

    return {

        modules: MODULES,

        ...DEFAULT_CONFIG,

        slidesPerView:
            parseFloat(data.slides) || 6,

        speed:
            parseFloat(data.speed) || 300,

        loop:
            data.loop === "true",

        autoplay:
            data.autoplay === "true"
                ? {
                    delay:
                        parseFloat(data.delay) || 2000,
                    disableOnInteraction: false
                }
                : false,

        navigation:
            data.navigation === "true"
                ? {
                    nextEl: element.parentElement?.querySelector('.swiper-button-next'),
                    prevEl: element.parentElement?.querySelector('.swiper-button-prev'),
                }
                : false,

        breakpoints: {
            0: {
                slidesPerView: parseFloat(data.mob) || 2,
                freeMode: {
                    enabled: true,
                    sticky: false,
                    momentumRatio: 1.2,
                    momentumVelocityRatio: 1.2,
                },
            },
            768: {
                 slidesPerView: parseFloat(data.tab) || 3,
                 freeMode: {
                    enabled: true,
                    sticky: false,
                    momentumRatio: 1.2,
                    momentumVelocityRatio: 1.2,
                },
            },
            1024: {
                slidesPerView: parseFloat(data.lap) || 4,
                freeMode: {
                    enabled: false,
                },
            },
            1400: {
                slidesPerView: parseFloat(data.slides) || 6,
                freeMode: {
                    enabled: false,
                },
            }
        }

    };

});
