import sliderManager from "../core/slider-manager";
import FadeSlider from "../core/streamit-slider";
import { Swiper, Navigation } from "../core/swiper-config";
import { post } from "../../../../static/assets/utilities/ajax.js";

sliderManager.register(
    "tv-show-tab-hybrid",
    (element) => {

        const mainEl = element.querySelector(".banner-main-slider");
        const thumbEl = element.querySelector(".banner-thumb-slider");

        if (!mainEl || !thumbEl) return false;

        const speed = Number(element.dataset.speed) || 600;
        const autoplay = element.dataset.autoplay === "true";
        const delay = Number(element.dataset.delay) || 5000;

        /*
        MAIN
        */
        const mainSlider = new FadeSlider(
            mainEl,
            {
                effect: "fade",
                loop: true,
                animationDuration: speed,
                autoplay,
                delay,
                allowDrag: false
            }
        );

        /*
        THUMB
        */
        const thumbSlideCount = thumbEl.querySelectorAll('.swiper-slide').length;
        
        // Disable loop animation if there are only 1 or 2 shows. Minimum 3 required.
        const thumbLoop = thumbSlideCount >= 3;

        const thumbSlider = new FadeSlider(
            thumbEl,
            {
                effect: "slide",
                loop: thumbLoop,
                slidesPerView: 6,
                breakpoints: {
                    0: 2,
                    768: 3,
                    1024: 5
                },
                spaceBetween: 20,
                centerMode: true,
                animationDuration: speed,
                navigation: {
                    nextEl: thumbEl.parentElement.querySelector('.js-swiper-next') || thumbEl.parentElement.querySelector('.swiper-button-next'),
                    prevEl: thumbEl.parentElement.querySelector('.js-swiper-prev') || thumbEl.parentElement.querySelector('.swiper-button-prev')
                },
                allowDrag: false
            }
        );

        /*
        SYNC
        */
        let syncing = false;

        const getTabParts = (tabItem) => {
            if (!tabItem) return {};

            return {
                overviewBtn: tabItem.querySelector('[data-bs-target^="#overview_"]'),
                episodesBtn: tabItem.querySelector(".js-tv-show-episodes"),
                overviewPane: tabItem.querySelector(".overview-tab"),
                episodesPane: tabItem.querySelector(".overlay-tab"),
                seasonSelect: tabItem.querySelector(".js-season-select"),
                episodesContainer: tabItem.querySelector(".episodes-contens"),
            };
        };

        const setTabState = (tabItem, tabName) => {
            const {
                overviewBtn,
                episodesBtn,
                overviewPane,
                episodesPane,
            } = getTabParts(tabItem);

            if (!overviewBtn || !overviewPane) return;

            const showEpisodes = tabName === "episodes" && episodesBtn && episodesPane;

            // Force clean state for Overview
            overviewBtn.classList.toggle("active", !showEpisodes);
            overviewBtn.setAttribute('aria-selected', !showEpisodes);
            overviewPane.classList.toggle("active", !showEpisodes);
            overviewPane.classList.toggle("show", !showEpisodes);

            // Force clean state for Episodes
            if (episodesBtn && episodesPane) {
                episodesBtn.classList.toggle("active", showEpisodes);
                episodesBtn.setAttribute('aria-selected', showEpisodes);
                episodesPane.classList.toggle("active", showEpisodes);
                episodesPane.classList.toggle("show", showEpisodes);
            }
        };

        mainSlider.onChange = (index) => {
            if (syncing) return;
            syncing = true;
            let target = index;
            if (mainSlider.loop && thumbLoop) {
                if (index === 0 && thumbSlider.currentIndex === thumbSlider.total - 1) target = thumbSlider.total;
                else if (index === mainSlider.total - 1 && thumbSlider.currentIndex === 0) target = -1;
            }
            thumbSlider.goToSlide(target, true);
            setTimeout(() => syncing = false, speed);
        };

        thumbSlider.onChange = (index) => {
            if (syncing) return;
            syncing = true;
            let target = index;
            if (mainSlider.loop && thumbLoop) {
                if (index === 0 && mainSlider.currentIndex === mainSlider.total - 1) target = mainSlider.total;
                else if (index === mainSlider.total - 1 && mainSlider.currentIndex === 0) target = -1;
            }
            mainSlider.goToSlide(target, true);
            setTimeout(() => syncing = false, speed);
        };

        /*
        CLICK SUPPORT
        */
        thumbEl.addEventListener("click", e => {
            const slide = e.target.closest(".swiper-slide");
            if (!slide) return;

            // Only count real slides for indexing, ignore clones
            const slides = Array.from(thumbEl.querySelectorAll(".swiper-slide:not(.is-clone)"));
            const targetIndex = slides.indexOf(slide);

            if (targetIndex !== -1) {
                let target = targetIndex;
                if (mainSlider.loop && thumbLoop) {
                   if (target === 0 && thumbSlider.currentIndex === mainSlider.total - 1) target = mainSlider.total;
                   else if (target === mainSlider.total - 1 && thumbSlider.currentIndex === 0) target = -1;
                }
                thumbSlider.goToSlide(target, true);
                mainSlider.goToSlide(target, true);
            } else {
                // If they clicked a clone, we still want to navigate to its logical index
                const allSlides = Array.from(thumbEl.querySelectorAll(".swiper-slide"));
                const clickedIndex = allSlides.indexOf(slide);
                if (clickedIndex !== -1) {
                    const rawLogical = clickedIndex - thumbSlider.cloneCount;
                    thumbSlider.goToSlide(rawLogical, true);
                    mainSlider.goToSlide(rawLogical, true);
                }
            }
        });

        /*
        EPISODES AJAX & SLIDER
        */
        const episodeSliders = [];
        const episodeCache = new Map();
        const renderEpisodeLoadingState = (sliderEl) => {
            console.log("Inline skeleton loader: Injecting...");
            const wrapper = sliderEl.querySelector('.swiper-wrapper');
            if (!wrapper) return;

            if (sliderEl.swiper) {
                sliderEl.swiper.destroy(true, true);
                sliderEl.swiper = undefined;
            }

            // Force visibility to block Swiper's native opacity 0 trick
            sliderEl.style.opacity = '1';
            sliderEl.style.visibility = 'visible';

            // Provide gap and flex so skeletons stack properly
            wrapper.style.display = 'flex';
            wrapper.style.gap = '20px';
            wrapper.style.overflow = 'hidden';
            wrapper.style.flexWrap = 'nowrap';

            // Calculate responsive widths mimicking Swiper breakpoints
            const getResponsiveWidth = () => {
                const width = window.innerWidth;
                if (width >= 1368) return 'calc(25% - 15px)'; // 4 cards
                if (width >= 993) return 'calc(33.333% - 13.33px)'; // 3 cards
                return 'calc(50% - 10px)'; // 2 cards (mobile/tablet)
            };
            const slideWidth = getResponsiveWidth();
            const shimmerGradient = 'linear-gradient(90deg, #141414 25%, #2a2a2a 50%, #141414 75%)';

            let skeletons = '';
            for(let i=0; i<4; i++) {
                skeletons += `
                <article class="swiper-slide" style="width: ${slideWidth}; flex-shrink: 0; min-height: 250px;">
                    <div class="episode-card" style="width: 100%; border-radius: 4px;">
                        <!-- Image Skeleton -->
                        <div style="width: 100%; aspect-ratio: 16/9; min-height: 150px; border-radius: 4px; background: ${shimmerGradient}; background-size: 200% 100%; animation: shimmer 1.5s infinite linear;"></div>
                        <!-- Meta Skeleton -->
                        <div style="padding-top: 15px;">
                            <div style="width: 80%; height: 20px; border-radius: 4px; background: ${shimmerGradient}; background-size: 200% 100%; animation: shimmer 1.5s infinite linear; margin-bottom: 10px;"></div>
                            <div style="width: 50%; height: 16px; border-radius: 4px; background: ${shimmerGradient}; background-size: 200% 100%; animation: shimmer 1.5s infinite linear;"></div>
                        </div>
                    </div>
                </article>`;
            }

            wrapper.innerHTML = skeletons;
            console.log("Inline skeleton loader: Successfully injected!");
        };

        const clearEpisodeLoadingState = (sliderEl) => {
            console.log("Inline skeleton loader: Removing...");
            sliderEl.style.opacity = '';
            sliderEl.style.visibility = '';
            const wrapper = sliderEl.querySelector('.swiper-wrapper');
            if (wrapper) {
                wrapper.style.display = '';
                wrapper.style.gap = '';
                wrapper.style.overflow = '';
                wrapper.style.flexWrap = '';
            }
        };

        const getEpisodeSwiperConfig = (sliderEl, targetContainer) => ({
            modules: [Navigation],
            effect: "slide",
            loop: false,
            nested: true,
            allowTouchMove: false,
            slidesPerView: 2,
            spaceBetween: 20,
            breakpoints: {
                577: { slidesPerView: 2 },
                993: { slidesPerView: 3 },
                1025: { slidesPerView: 3 },
                1368: { slidesPerView: 4 }
            },
            navigation: {
                nextEl: targetContainer.querySelector('.NextArrow-two'),
                prevEl: targetContainer.querySelector('.PreArrow-two')
            },
            on: {
                init: function () {
                    sliderEl.classList.add('slider-ready');
                }
            }
        });

        const handleEpisodesFetch = (seasonNo, seasonData, targetContainer) => {
            let sliderEl = targetContainer.querySelector('.js-episodes-slider');
            if (!sliderEl) return;

            const tvShowBtn = targetContainer.closest('.trending-custom-tab')?.querySelector('.js-tv-show-episodes');
            const tvShowId = tvShowBtn?.dataset.tvshowId || 'default';
            const cacheKey = `${tvShowId}-${seasonNo}`;
            const cachedSlides = episodeCache.get(cacheKey);

            if (cachedSlides) {
                sliderEl.dataset.display = String(seasonNo);
                sliderEl.dataset.loading = "false";
                sliderEl.dataset.loaded = "true";
                clearEpisodeLoadingState(sliderEl);

                const wrapper = sliderEl.querySelector('.swiper-wrapper');

                if (sliderEl.swiper) {
                    sliderEl.swiper.destroy(true, true);
                    sliderEl.swiper = undefined;
                }

                wrapper.innerHTML = cachedSlides;

                const epSlider = new Swiper(sliderEl, getEpisodeSwiperConfig(sliderEl, targetContainer));
                sliderEl.swiper = epSlider;
                episodeSliders.push(epSlider);
                return;
            }

            sliderEl.dataset.loading = "true";
            sliderEl.dataset.display = String(seasonNo);
            sliderEl.dataset.loaded = "false";
            renderEpisodeLoadingState(sliderEl);

            post('tvshow_tab_seasons_data', { data: seasonData, season: seasonNo, is_slider: true })
                .then(res => {
                    // Check if season hasn't been changed during fetch
                    if (sliderEl.dataset.display !== String(seasonNo)) return;

                    sliderEl.dataset.loading = "false";
                    clearEpisodeLoadingState(sliderEl);
                    const jsonRes = typeof res === "string" ? JSON.parse(res) : res;
                    const wrapper = sliderEl.querySelector('.swiper-wrapper');
                    
                    if (jsonRes.success) {
                        if (sliderEl.swiper) {
                            sliderEl.swiper.destroy(true, true);
                            sliderEl.swiper = undefined;
                        }

                        wrapper.innerHTML = ''; // clear current slides

                        jsonRes.result.forEach((item) => {
                            const slideHTML = `<article class="episode-item swiper-slide animated fadeInUp ajax"><div class="episode-card">${item.block_main_content}</div></article>`;
                            wrapper.insertAdjacentHTML('beforeend', slideHTML);
                        });

                        episodeCache.set(cacheKey, wrapper.innerHTML);
                        sliderEl.dataset.loaded = "true";

                        // Initialize Swiper again with real data
                        const epSlider = new Swiper(sliderEl, getEpisodeSwiperConfig(sliderEl, targetContainer));
                        sliderEl.swiper = epSlider;
                        episodeSliders.push(epSlider);
                    }
                })
                .catch(err => {
                    if (sliderEl.dataset.display !== String(seasonNo)) return;
                    sliderEl.dataset.loading = "false";
                    clearEpisodeLoadingState(sliderEl);
                    const wrapper = sliderEl.querySelector('.swiper-wrapper');
                    wrapper.innerHTML = '<p class="no_data_found mb-3 mt-3 w-100 text-center">Error loading episodes.</p>';
                    console.error("Error fetching episodes:", err);
                });
        };

       const handleSeasonChange = (select) => {
            const tabItem = select.closest('.trending-custom-tab');
            if (!tabItem) return;

            const tvShowBtn = tabItem.querySelector('.js-tv-show-episodes');
            if (!tvShowBtn) return;

            const seasonData = JSON.parse(tvShowBtn.dataset.seasons || "{}");
            const seasonNo = select.value;
            const targetContainer = tabItem.querySelector('.episodes-contens');

            // Force stay on episodes tab when changing season
            setTabState(tabItem, "episodes");

            if (targetContainer) handleEpisodesFetch(seasonNo, seasonData, targetContainer);
        };

        if (typeof jQuery !== 'undefined') {
            jQuery(element).on("change", ".js-season-select", function (e) {
                e.stopPropagation(); // Stop bubbling
                handleSeasonChange(this);
            });
        } else {
            element.addEventListener("change", (e) => {
                if (e.target.classList.contains("js-season-select")) {
                    e.stopPropagation();
                    handleSeasonChange(e.target);
                }
            });
        }

        element.addEventListener("click", (e) => {
            // 1. Handle Overview Button Click
            const overviewBtn = e.target.closest('[data-bs-target^="#overview_"]');
            if (overviewBtn) {
                e.preventDefault();
                e.stopPropagation();
                const tabItem = overviewBtn.closest('.trending-custom-tab');
                setTabState(tabItem, "overview");
                return;
            }

            // 2. Handle Episodes Button Click
            const btn = e.target.closest(".js-tv-show-episodes");
            if (btn) {
                e.preventDefault();
                e.stopPropagation();
                
                const tabItem = btn.closest('.trending-custom-tab');
                if (!tabItem) return;

                setTabState(tabItem, "episodes");

                const seasonData = JSON.parse(btn.dataset.seasons || "{}");
                const targetContainer = tabItem.querySelector('.episodes-contens');

                const select = tabItem.querySelector('.js-season-select');
                const seasonNo = select ? select.value : Object.keys(seasonData)[0];

                if (select && seasonNo !== undefined) {
                    select.value = String(seasonNo);
                }

                if (seasonNo !== undefined && targetContainer) {
                    handleEpisodesFetch(String(seasonNo), seasonData, targetContainer);
                }
            }
        });

        if (typeof jQuery !== 'undefined') {
            jQuery(element).on("change", ".js-season-select", function (e) {
                handleSeasonChange(this);
            });
        } else {
            element.addEventListener("change", (e) => {
                if (e.target.classList.contains("js-season-select")) {
                    handleSeasonChange(e.target);
                }
            });
        }

        element.addEventListener("click", (e) => {
            const overviewBtn = e.target.closest('[data-bs-target^="#overview_"]');
            if (overviewBtn) {
                const tabItem = overviewBtn.closest('.trending-custom-tab');
                setTabState(tabItem, "overview");
                return;
            }

            const btn = e.target.closest(".js-tv-show-episodes");
            if (btn) {
                const tabItem = btn.closest('.trending-custom-tab');
                if (!tabItem) return;

                setTabState(tabItem, "episodes");

                const seasonData = JSON.parse(btn.dataset.seasons || "{}");
                const targetContainer = tabItem.querySelector('.episodes-contens');

                const select = tabItem.querySelector('.js-season-select');
                const seasonNo = select ? select.value : Object.keys(seasonData)[0];

                if (select && seasonNo !== undefined) {
                    select.value = String(seasonNo);
                }

                if (seasonNo !== undefined && targetContainer) {
                    handleEpisodesFetch(String(seasonNo), seasonData, targetContainer);
                }
            }
        });
        /*

        CLEANUP
        */
        const observer = new MutationObserver(() => {
            if (!document.contains(element)) {
                mainSlider.destroy();
                thumbSlider.destroy();
                episodeSliders.forEach(s => s.destroy());
                observer.disconnect();
            }
        });

        observer.observe(document.body, { childList: true, subtree: true });

        return false;
    }
);
