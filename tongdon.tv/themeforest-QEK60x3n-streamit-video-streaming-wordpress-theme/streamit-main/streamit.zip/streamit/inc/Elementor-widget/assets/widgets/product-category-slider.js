import sliderManager from "../core/slider-manager";

sliderManager.register(
    "product-category",
    (element, DEFAULT_CONFIG, MODULES) => {
        const data = element.dataset;
        const navigationElements = {
            nextEl: element.parentElement?.querySelector(".swiper-button-next"),
            prevEl: element.parentElement?.querySelector(".swiper-button-prev"),
        };
        const desktopNavigation = data.navigation === "true";
        const laptopNavigation = data.navigationLaptop === "true";
        const tabletNavigation = data.navigationTablet === "true";
        const mobileNavigation = data.navigationMobile === "true";
        const hasNavigation = desktopNavigation || laptopNavigation || tabletNavigation || mobileNavigation;

        const desktopSlides = parseFloat(data.slides) || 4;
        const laptopSlides = parseFloat(data.lap) || 3;
        const tabletSlides = parseFloat(data.tab) || 3;
        const mobileSlides = parseFloat(data.mob) || 1;

        return {
            modules: MODULES,
            ...DEFAULT_CONFIG,
            slidesPerView: desktopSlides,
            speed: parseFloat(data.speed) || 300,
            loop: data.loop === "true",
            autoplay: data.autoplay === "true"
                ? {
                    delay: parseFloat(data.delay) || 2000,
                    disableOnInteraction: false,
                }
                : false,
            navigation: hasNavigation ? navigationElements : false,
            observer: true,
            observeParents: true,
            watchOverflow: true,
            breakpoints: {
                0: {
                    slidesPerView: mobileSlides,
                    navigation: mobileNavigation ? navigationElements : false,
                },
                768: {
                    slidesPerView: tabletSlides,
                    navigation: tabletNavigation ? navigationElements : false,
                },
                1024: {
                    slidesPerView: laptopSlides,
                    navigation: laptopNavigation ? navigationElements : false,
                },
                1400: {
                    slidesPerView: desktopSlides,
                    navigation: desktopNavigation ? navigationElements : false,
                },
            }
        };
    }
);
