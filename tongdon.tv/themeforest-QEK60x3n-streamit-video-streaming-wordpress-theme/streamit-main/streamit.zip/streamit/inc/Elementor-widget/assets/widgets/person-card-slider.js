import sliderManager from "../core/slider-manager";

sliderManager.register("person-card", (element, DEFAULT_CONFIG, MODULES) => {

    const data = element.dataset;
    const sliderSection = element.closest(".streamit-person-section") || element.parentElement;
    const nextArrow = sliderSection?.querySelector('[data-person-nav="next"]')
        || sliderSection?.querySelector('.swiper-button-next');
    const prevArrow = sliderSection?.querySelector('[data-person-nav="prev"]')
        || sliderSection?.querySelector('.swiper-button-prev');
    const desktopNavigation = data.navigation === "true";
    const laptopNavigation = data.navigationLaptop === "true";
    const tabletNavigation = data.navigationTablet === "true";
    const mobileNavigation = data.navigationMobile === "true";

    return {

        ...DEFAULT_CONFIG,

        modules: MODULES,

        slidesPerView: parseFloat(data.slides) || 12,

        spaceBetween: 16,

        loop: data.loop === "true",

        speed: parseFloat(data.speed) || 300,

        autoplay: data.autoplay === "true"
            ? {
                delay: parseFloat(data.delay) || 2000,
                disableOnInteraction: false
            }
            : false,

        navigation: desktopNavigation || laptopNavigation || tabletNavigation || mobileNavigation
            ? {
                nextEl: nextArrow,
                prevEl: prevArrow,
            }
            : false,

        breakpoints: {
            0: {
                slidesPerView: parseFloat(data.mob) || 3,
                navigation: mobileNavigation ? { nextEl: nextArrow, prevEl: prevArrow } : false,
                freeMode: {
                    enabled: true,
                    sticky: false,
                    momentumRatio: 1.2,
                    momentumVelocityRatio: 1.2,
                },
            },
            768: {
                 slidesPerView: parseFloat(data.tab) || 4,
                 navigation: tabletNavigation ? { nextEl: nextArrow, prevEl: prevArrow } : false,
                 freeMode: {
                    enabled: true,
                    sticky: false,
                    momentumRatio: 1.2,
                    momentumVelocityRatio: 1.2,
                },
            },
            1024: {
                slidesPerView: parseFloat(data.lap) || 6,
                navigation: laptopNavigation ? { nextEl: nextArrow, prevEl: prevArrow } : false,
                freeMode: {
                    enabled: false,
                },
            },
            1400: {
                slidesPerView: parseFloat(data.slides) || 12,
                navigation: desktopNavigation ? { nextEl: nextArrow, prevEl: prevArrow } : false,
                freeMode: {
                    enabled: false,
                },
            }
        }

    };

});
