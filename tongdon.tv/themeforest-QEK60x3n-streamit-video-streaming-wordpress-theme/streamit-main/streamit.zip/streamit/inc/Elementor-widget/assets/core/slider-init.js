import sliderManager from './slider-manager';
import "../widgets/main-banner-slider";
import '../widgets/main-card-slider';
import "../widgets/person-card-slider";
import "../widgets/top-ten-slider";
import "../widgets/product-category-slider";
import "../widgets/continue-watching-slider";
import "../widgets/product-shortcode-slider";
import "../widgets/blog-slider";
import "../widgets/vertical-thumbnail-slider";
import "../widgets/simple-banner-slider";
import "../widgets/single-episode-season-slider";
import "../widgets/tv-show-season-slider";
import "../widgets/tv-show-tab-slider";
import "../widgets/terms-slider";
import "../widgets/tags-slider";
import "../widgets/product-slider";


document.addEventListener('DOMContentLoaded', () => {

    sliderManager.initAll();

    bindDirectionInputs();

});


function bindDirectionInputs(scope = document) {
    const directionInputs = scope.querySelectorAll('input[name="theme_scheme_direction"]');

    directionInputs.forEach(input => {

        input.addEventListener("change", () => {

            sliderManager.updateDirection(input.value);

        });

    });

}


/* Elementor dynamic load support */
if (window.elementorFrontend) {

    jQuery(window).on(
        "elementor/frontend/init",
        () => {

            elementorFrontend.hooks.addAction(
                "frontend/element_ready/global",
                ($scope) => {

                    sliderManager.initAll($scope[0]);

                    bindDirectionInputs($scope[0]);

                }
            );

        }
    );

}
