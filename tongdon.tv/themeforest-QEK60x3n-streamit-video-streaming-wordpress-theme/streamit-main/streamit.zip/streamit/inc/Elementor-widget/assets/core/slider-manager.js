import { Swiper, Navigation, Pagination, Autoplay, Thumbs, Controller, FreeMode } from './swiper-config';
import bootstrapcomponent from './../../../../static/assets/js/bootstrap-component.js';


const DEFAULT_CONFIG = Object.freeze({
    slidesPerView: 1,
    spaceBetween: 16,
    speed: 300,
});

export const SWIPER_MODULES = [
    Navigation,
    Pagination,
    Autoplay,
    Thumbs,
    Controller,
    FreeMode
];

class SliderManager {

    constructor() {

        this.instances = new Map();
        this.builders = {};
        this.bootstrap = new bootstrapcomponent();

    }

    register(type, builder) {
        this.builders[type] = builder;
    }

    initSlider(element) {

        if (!element) return;
        if (this.instances.has(element)) return;
        // Prevent double initialization
        if (element._swiperInstances) return false;

        const config = this.buildConfig(element);

        // A builder that returns false/null managed its own Swiper instances.
        // Mark the element as handled so we don't re-init it, but skip BOTH
        // the generic Swiper() constructor call AND the MutationObserver below
        // (the widget's own observer handles cleanup for these complex widgets).
        if (config === false || config == null) {
            requestAnimationFrame(() => {
                element.classList.add('slider-ready');
            });
            this.instances.set(element, null);
            return; // ← early exit: prevents orphaned MutationObserver
        }

        const swiper = new Swiper(element, config);
        
        // const updateActiveClasses = (s) => {
        //     s.slides.forEach((slide, i) => {
        //         const idx = parseInt(slide.getAttribute('data-swiper-slide-index') ?? i, 10);
        //         slide.classList.toggle('is-active', idx === s.realIndex);
        //     });
        // };

        // Natively, Swiper adds .swiper-initialized. 
        // We add .slider-ready simply as an internal fallback API.
        swiper.on('init', () => {
            element.classList.add('slider-ready');
           // updateActiveClasses(swiper);
        });

        // swiper.on('slideChange', () => {
        //     updateActiveClasses(swiper);
        // });

        // If it initialized synchronously, the init event may have already fired
        if (swiper.initialized) {
            element.classList.add('slider-ready');
            //updateActiveClasses(swiper);
        }

        this.instances.set(element, swiper);

        if (typeof IntersectionObserver !== 'undefined') {
            const observer = new MutationObserver(() => {
                if (!document.contains(element)) {
                    swiper.destroy(true, true);
                    this.instances.delete(element);
                    observer.disconnect();
                }
            });
            observer.observe(document.body, { childList: true, subtree: true });
        }
    }


    initAll(scope = document) {
        const observer = new IntersectionObserver((entries) => {

            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.initSlider(entry.target);
                    observer.unobserve(entry.target);
                }
            });
        }, { rootMargin: '100px' });

        scope.querySelectorAll('.js-streamit-slider')
            .forEach(el => observer.observe(el));
    }


    buildConfig(element) {
        const type = element.dataset.type || "default";
        
        // Debug logging for responsive navigation settings
        if (window.elementorFrontend || window.location.search.includes('elementor-preview')) {
            console.log(`[Swiper Debug] Initializing "${type}" slider:`, {
                navigation: element.dataset.navigation,
                navigationLaptop: element.dataset.navigationLaptop,
                navigationTablet: element.dataset.navigationTablet,
                navigationMobile: element.dataset.navigationMobile,
                element: element
            });
        }

        let config;
        if (this.builders[type]) {
            config = this.builders[type](element, DEFAULT_CONFIG, SWIPER_MODULES);
        } else {
            config = this.defaultBuilder(element);
        }

        if (config && (window.elementorFrontend || window.location.search.includes('elementor-preview'))) {
            console.log(`[Swiper Debug] Final Config for "${type}":`, config);
        }

        return config;
    }

    defaultBuilder(element) {

        const data = element.dataset;

        return {

            modules: SWIPER_MODULES,

            ...DEFAULT_CONFIG,

            slidesPerView: parseInt(data.slides) || 1,

            navigation: data.navigation === "true"
                ? {
                    nextEl: element.parentElement?.querySelector('.js-swiper-next') || element.querySelector('.js-swiper-next') || element.parentElement?.querySelector('.swiper-button-next') || element.querySelector('.swiper-button-next'),
                    prevEl: element.parentElement?.querySelector('.js-swiper-prev') || element.querySelector('.js-swiper-prev') || element.parentElement?.querySelector('.swiper-button-prev') || element.querySelector('.swiper-button-prev'),
                }
                : false,

            pagination: data.pagination === "true"
                ? {
                    el: element.parentElement?.querySelector('.swiper-pagination') || element.querySelector('.swiper-pagination'),
                    clickable: true,
                }
                : false,

        };
    }



    updateDirection(direction) {

        /* normalize */
        const dir = direction === "rtl" ? "rtl" : "ltr";

        /* close bootstrap offcanvas safely (if you have helper) */
        if (this.bootstrap?.closeVisibleOffcanvas) {
            this.bootstrap.closeVisibleOffcanvas('#rtl-switcher-options');
        }

        /* update html direction */
        document.documentElement.dir = dir;

        /* save cookie */
        this.setCookie('theme_scheme_direction', dir, 7);


        /* update active state */
        const active = document.getElementById(
            `theme-scheme-direction-${dir}`
        );

        const inactive = document.getElementById(
            `theme-scheme-direction-${dir === "ltr" ? "rtl" : "ltr"}`
        );

        const activeClass =
            this.config?.classes?.active || "active";

        if (active) {
            active.classList.add(activeClass);
        }

        if (inactive) {
            inactive.classList.remove(activeClass);
        }


        /* update all swiper instances safely */
        this.instances.forEach(swiper => {

            if (!swiper || swiper.destroyed) return;

            swiper.changeLanguageDirection(dir);

            swiper.update();

        });

    }

    setCookie(name, value, days) {

        const expires =
            new Date(
                Date.now() + days * 86400000
            ).toUTCString();

        document.cookie =
            `${name}=${value}; expires=${expires}; path=/`;

    }
}

export default new SliderManager();
