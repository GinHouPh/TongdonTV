import sliderManager from "../core/slider-manager";
import Swiper from "swiper";
import { Autoplay } from "swiper/modules";
import FadeSlider from "../core/streamit-slider";

sliderManager.register("main-banner", (element, DEFAULT_CONFIG, MODULES) => {

    const data = element.dataset;

    // ── 1. ELEMENT QUERIES ───────────────────────────────────────────────────
    const mainEl = element.querySelector(".banner-main-slider");
    const thumbEl = element.querySelector(".banner-thumb-slider");
    const thumbWrapperEl = element.querySelector(".banner-thumb-wrapper");
    const prevBtn = element.querySelector(".thumb-btn-prev");
    const nextBtn = element.querySelector(".thumb-btn-next");

    if (!mainEl || !thumbEl) {
        return false;
    }

    // ── 2. CONFIG ────────────────────────────────────────────────────────────
    const autoplayEnabled = data.autoplay === "true";
    const delay = Number(data.delay) || 5000;
    const speed = Number(data.speed) || 600;

    // ── 3. STATE ─────────────────────────────────────────────────────────────
    let isHovering = false;
    let resumeTimer = null;

    // ── 4. THUMB SWIPER ──────────────────────────────────────────────────────
    const thumbsSwiper = new Swiper(thumbEl, {
        modules: [Autoplay],
        slidesPerView: 2,
        slidesPerGroup: 1,
        spaceBetween: 30,
        speed,
        loop: true,
        watchSlidesProgress: true,
        grabCursor: true,
        simulateTouch: true,
        allowTouchMove: true,
        autoplay: autoplayEnabled ? { delay, disableOnInteraction: false } : false,
    });

    function setActiveClass(thumbSwiper, realIndex) {
        thumbSwiper.slides.forEach((slide) => {
            const idx = parseInt(slide.getAttribute("data-swiper-slide-index") ?? "-1", 10);
            slide.classList.toggle("is-active", idx === realIndex);
        });
    }

    // ── 5. MAIN FADESLIDER ───────────────────────────────────────────────────
    const effectOption = data.effect || "fade";
    const mainSlider = new FadeSlider(mainEl, {
        loop: true,
        dragThreshold: 50,
        animationDuration: speed,
        effect: effectOption,
        wrapperSelector: ".swiper-wrapper"
    });

    // ── 6. SYNC LOGIC ────────────────────────────────────────────────────────
    mainSlider.onChange = (newIndex) => {
        if (thumbsSwiper.realIndex === newIndex) return;
        thumbsSwiper.slideToLoop(newIndex, speed);
        setActiveClass(thumbsSwiper, newIndex);
    };

    thumbsSwiper.on("slideChange", () => {
        const target = thumbsSwiper.realIndex;
        if (mainSlider.currentIndex === target) return;
        mainSlider.goToSlide(target, true);
        setActiveClass(thumbsSwiper, target);
    });

    // ── 7. AUTOPLAY HELPERS ──────────────────────────────────────────────────
    function pauseAutoplay() {
        if (!autoplayEnabled || thumbsSwiper.destroyed) return;
        clearTimeout(resumeTimer);
        thumbsSwiper.autoplay.pause();
        element.classList.add("is-autoplay-paused");
    }

    function resumeAutoplay(afterDelay = 0) {
        if (!autoplayEnabled || thumbsSwiper.destroyed) return;
        clearTimeout(resumeTimer);
        resumeTimer = setTimeout(() => {
            if (!thumbsSwiper.destroyed && !isHovering) {
                thumbsSwiper.autoplay.resume();
                element.classList.remove("is-autoplay-paused");
            }
        }, afterDelay);
    }

    function restartAutoplay(afterDelay = 0) {
        if (!autoplayEnabled || thumbsSwiper.destroyed) return;
        thumbsSwiper.autoplay.stop();
        clearTimeout(resumeTimer);
        resumeTimer = setTimeout(() => {
            if (!thumbsSwiper.destroyed && !isHovering) {
                thumbsSwiper.autoplay.start();
                element.classList.remove("is-autoplay-paused");
            }
        }, afterDelay);
    }

    // ── 8. DRAG UX ───────────────────────────────────────────────────────────
    function handleDragStart() {
        element.classList.add("is-dragging");
        if (autoplayEnabled) thumbsSwiper.autoplay.stop();
    }

    function handleDragEnd() {
        element.classList.remove("is-dragging");
        restartAutoplay(speed + 300);
    }

    thumbsSwiper.on("touchStart", handleDragStart);
    thumbsSwiper.on("touchEnd", handleDragEnd);

    // Manually pass mouse/touch drag events to FadeSlider DOM target
    mainEl.addEventListener("touchstart", handleDragStart, { passive: true });
    mainEl.addEventListener("touchend", handleDragEnd);
    mainEl.addEventListener("mousedown", handleDragStart);
    mainEl.addEventListener("mouseup", handleDragEnd);
    window.addEventListener("mouseup", handleDragEnd);

    // ── 9. CUSTOM ARROW HANDLERS ─────────────────────────────────────────────
    function moveThumb(direction) {
        if (!thumbsSwiper || thumbsSwiper.destroyed) return;
        if (autoplayEnabled) thumbsSwiper.autoplay.stop();

        if (direction === 'next') thumbsSwiper.slideNext(speed);
        else thumbsSwiper.slidePrev(speed);

        setTimeout(() => restartAutoplay(speed + 300), 500);
    }

    if (prevBtn) {
        prevBtn.addEventListener("click", (e) => {
            e.preventDefault();
            moveThumb('prev');
        });
    }
    if (nextBtn) {
        nextBtn.addEventListener("click", (e) => {
            e.preventDefault();
            moveThumb('next');
        });
    }

    // ── 10. THUMB CLICK / KEYBOARD ───────────────────────────────────────────
    function handleThumbSelect(e) {
        const slide = e.target.closest(".swiper-slide");
        if (!slide || !thumbsSwiper || thumbsSwiper.destroyed) return;

        // Handle keyboard constraints
        if (e.type === "keydown" && e.key !== "Enter" && e.key !== " ") return;
        if (e.type === "keydown") e.preventDefault();

        const realIdx = parseInt(slide.getAttribute("data-swiper-slide-index"), 10);
        if (!isNaN(realIdx) && thumbsSwiper.realIndex !== realIdx) {
            thumbsSwiper.slideToLoop(realIdx, speed);
            if (autoplayEnabled) thumbsSwiper.autoplay.stop();
            setTimeout(() => restartAutoplay(speed + 300), 500);
        }
    }

    thumbsSwiper.on('click', (swiper, e) => handleThumbSelect(e));
    thumbEl.addEventListener("keydown", handleThumbSelect);

    // ── 11. HOVER & VISIBILITY ───────────────────────────────────────────────
    if (autoplayEnabled) {
        element.addEventListener("mouseenter", () => {
            isHovering = true;
            pauseAutoplay();
        });
        element.addEventListener("mouseleave", () => {
            isHovering = false;
            resumeAutoplay(200);
        });
    }

    const onVisibilityChange = () => {
        if (!autoplayEnabled || thumbsSwiper.destroyed) return;
        if (document.hidden) {
            thumbsSwiper.autoplay.stop();
        } else if (!isHovering) {
            thumbsSwiper.autoplay.start();
        }
    };
    document.addEventListener("visibilitychange", onVisibilityChange);

    // ── 12. INITIALIZATION ───────────────────────────────────────────────────
    thumbsSwiper.slideToLoop(0, 0);
    setActiveClass(thumbsSwiper, 0);

    requestAnimationFrame(() => {
        if (autoplayEnabled && !thumbsSwiper.destroyed) thumbsSwiper.autoplay.start();
    });

    // ── 13. CLEANUP ──────────────────────────────────────────────────────────
    const observer = new MutationObserver(() => {
        if (!document.contains(element)) {
            clearTimeout(resumeTimer);
            document.removeEventListener("visibilitychange", onVisibilityChange);
            mainEl.removeEventListener("touchstart", handleDragStart);
            mainEl.removeEventListener("touchend", handleDragEnd);
            mainEl.removeEventListener("mousedown", handleDragStart);
            mainEl.removeEventListener("mouseup", handleDragEnd);
            window.removeEventListener("mouseup", handleDragEnd);

            if (thumbsSwiper) thumbsSwiper.destroy(true, true);
            if (mainSlider) mainSlider.destroy();
            observer.disconnect();
        }
    });
    observer.observe(document.body, { childList: true, subtree: true });

    element._swiperInstances = [thumbsSwiper];

    // CRITICAL: Prevent sliderManager.js from injecting a duplicate native wrapper
    return false;
});