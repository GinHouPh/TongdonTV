import sliderManager from "../core/slider-manager";

sliderManager.register("blog-slider", (element, DEFAULT_CONFIG, MODULES) => {

    const data = element.dataset;

    return {

        ...DEFAULT_CONFIG,

        modules: MODULES,

        slidesPerView: Number(data.mob) || 1,

        spaceBetween: 24,

        speed: Number(data.speed) || 500,

        loop: data.loop === "true",

        autoplay: data.autoplay === "true"
            ? {
                delay: Number(data.delay) || 3000,
                disableOnInteraction: false
            }
            : false,

        navigation: data.navigation === "true"
            ? {
                nextEl: element.parentElement?.querySelector('.swiper-button-next'),
                prevEl: element.parentElement?.querySelector('.swiper-button-prev'),
            }
            : false,

        breakpoints: {

            0: {
                slidesPerView: Number(data.mob) || 1
            },

            768: {
                slidesPerView: Number(data.tab) || 2
            },

            1024: {
                slidesPerView: Number(data.lap) || 3
            },

            1400: {
                slidesPerView: Number(data.slides) || 3
            }

        }

    };

});