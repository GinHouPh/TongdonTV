import sliderManager from "../core/slider-manager";

/**
 * Remove Continue Watching
 * works with Swiper + sliderManager
 */
function RemoveContinueWatching(event) {
    const button = event.currentTarget;

    const slide =
        button.closest(".swiper-slide");

    if (!slide) return;

    const slider =
        button.closest(".js-streamit-slider");

    const postType =
        button.dataset.postType || "";

    const postId =
        button.dataset.id || "";


    const data =
    {
        post_type: postType,
        post_id: postId
    };


    post("remove_continue_watch", data)

        .then(() => {

            slide.remove();


            /**
             * update swiper layout
             */
            if (slider) {
                const instance =
                    sliderManager.instances.get(slider);

                if (instance) {
                    instance.update();
                }
            }

        })

        .catch(console.error);
}


/**
 * event delegation
 */
document.addEventListener(
    "click",
    (event) => {

        const button =
            event.target.closest(
                ".trash-continue-watching"
            );

        if (!button) return;

        RemoveContinueWatching(
            { currentTarget: button }
        );

    });