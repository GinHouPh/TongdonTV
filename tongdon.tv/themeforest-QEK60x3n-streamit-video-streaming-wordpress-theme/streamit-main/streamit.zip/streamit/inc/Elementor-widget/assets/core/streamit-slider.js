export default class FadeSlider {
    constructor(container, options = {}) {
        this.container = container;
        const wrapperSelector = options.wrapperSelector || ".swiper-wrapper";
        this.wrapper = this.container.querySelector(wrapperSelector) || this.container;

        let slideSelector = options.slideSelector;
        if (slideSelector) {
            this.slides = Array.from(this.wrapper.querySelectorAll(slideSelector));
        } else {
            this.slides = Array.from(this.wrapper.children);
        }

        // Core options
        this.effect = options.effect || 'fade';
        this.loop = options.loop ?? true;
        this.dragThreshold = options.dragThreshold ?? 50;
        this.animationDuration = options.animationDuration ?? 300;
        this.allowDrag = options.allowDrag ?? true;

        // Multi‑slide options
        this.baseSlidesPerView = options.slidesPerView ?? 1;
        this.spaceBetween = Number(options.spaceBetween) || 0;
        this.breakpoints = options.breakpoints || null;
        this.centerMode = options.centerMode ?? false;

        this.slidesPerView = this.baseSlidesPerView;
        this.isMulti = this.slidesPerView > 1;

        // Clones for infinite loop
        this.clones = [];
        this.cloneCount = 0;
        this._snapTimeout = null;

        // Drag state
        this.isDragging = false;
        this.startX = 0;
        this.startY = 0;
        this.currentX = 0;
        this.startTranslate = 0;
        this.isScrolling = false;

        // Momentum tracking
        this.velocity = 0;
        this.lastMoveTime = 0;
        this.lastMoveX = 0;
        this.animationFrame = null;          // for momentum animation
        this.momentumDuration = 800;          // max duration of momentum (ms)

        // Dimensions
        this.slideWidth = 0;
        this.wrapperWidth = 0;
        this.maxTranslate = 0;                // most negative allowed (non‑loop)
        this.minTranslate = 0;                 // most positive allowed (non‑loop)

        // Navigation
        this.navigation = options.navigation || false;
        this.prevEl = this.navigation?.prevEl || null;
        this.nextEl = this.navigation?.nextEl || null;

        // Bind methods
        this.dragStartHandler = this.dragStart.bind(this);
        this.dragMoveHandler = this.dragMove.bind(this);
        this.dragEndHandler = this.dragEnd.bind(this);
        this.contextMenuHandler = (e) => e.preventDefault();
        this.imageDragHandler = (e) => {
            if (e.target.tagName === 'IMG') e.preventDefault();
        };
        this.resizeHandler = this._debounce(this.handleResize.bind(this), 100);

        if (this.slides.length > 0) {
            this._initLayout();
            this._initStyles();
            this._bindEvents();
            this._initNavigation();
            this.goToSlide(0, false);

            // Wait for next paint to ensure dimensions are registered, then reveal slider
            requestAnimationFrame(() => {
                this.container.classList.add('slider-ready');
            });
        }
    }

    get total() {
        return this.slides.length;
    }

    // --------------------------------------------------------------
    // Initialisation
    // --------------------------------------------------------------
    _initLayout() {
        this._updateSlidesPerView();
        this.container.style.touchAction = 'pan-y';

        if (this.isMulti) {
            this.wrapper.style.display = 'flex';
            this.wrapper.style.flexWrap = 'nowrap';
            this.wrapper.style.transition = `transform ${this.animationDuration}ms ease`;
            this.wrapper.style.willChange = 'transform';

            // Remove old clones if any
            if (this.clones && this.clones.length > 0) {
                this.clones.forEach(clone => clone.remove());
                this.clones = [];
            }
            this.cloneCount = 0;

            if (this.loop) {
                // Clone enough slides to create an endless feel (at least 2 extra sets)
                this.cloneCount = Math.max(this.slides.length, this.slidesPerView + 2);
                // Append clones after the last slide
                for (let i = 0; i < this.cloneCount; i++) {
                    let slideIndex = i % this.slides.length;
                    let clone = this.slides[slideIndex].cloneNode(true);
                    clone.classList.add('is-clone');
                    clone.removeAttribute('id');
                    this.wrapper.appendChild(clone);
                    this.clones.push(clone);
                }
                // Prepend clones before the first slide
                for (let i = 0; i < this.cloneCount; i++) {
                    let slideIndex = (this.slides.length - 1 - (i % this.slides.length));
                    let clone = this.slides[slideIndex].cloneNode(true);
                    clone.classList.add('is-clone');
                    clone.removeAttribute('id');
                    this.wrapper.insertBefore(clone, this.wrapper.firstChild);
                    this.clones.push(clone);
                }
            }

            // Style all children (original + clones)
            const allItems = Array.from(this.wrapper.children);
            allItems.forEach(slide => {
                slide.style.flex = '0 0 auto';
                slide.style.marginRight = this.spaceBetween + 'px';
            });

            this._updateDimensions();

            // Initial position – place the real first slide at the correct spot
            if (this.loop) {
                const initialTx = this._getTargetTranslate(0);
                this._applyWrapperTransform(initialTx, false);
            }
        } else {
            this.container.style.position = 'relative';
            this.container.style.overflow = 'hidden';
            this.wrapper.style.position = 'relative';
            this.wrapper.style.width = '100%';
            this.wrapper.style.height = '100%';
            this.wrapper.style.display = 'flex';
        }
    }

    _initStyles() {
        if (this.isMulti) {
            this.container.style.position = 'relative';
            this.container.style.overflow = 'hidden';
        } else {
            // Single slide absolute positioning (unchanged)
            this.slides.forEach((slide, i) => {
                slide.style.position = i === 0 ? 'relative' : 'absolute';
                slide.style.top = '0';
                slide.style.left = '0';
                slide.style.width = '100%';
                slide.style.height = '100%';
                slide.style.pointerEvents = i === 0 ? 'auto' : 'none';
                slide.style.zIndex = i === 0 ? '1' : '0';

                if (this.effect === 'fade') {
                    slide.style.transition = `opacity ${this.animationDuration}ms ease`;
                    slide.style.opacity = i === 0 ? '1' : '0';
                } else if (this.effect === 'slide') {
                    slide.style.transition = `transform ${this.animationDuration}ms ease`;
                    slide.style.transform = i === 0 ? 'translateX(0)' : 'translateX(100%)';
                }
            });
        }
    }

    _bindEvents() {
        if (this.allowDrag) {
            this.container.addEventListener('touchstart', this.dragStartHandler, { passive: false });
            this.container.addEventListener('mousedown', this.dragStartHandler);
            window.addEventListener('touchmove', this.dragMoveHandler, { passive: false });
            window.addEventListener('mousemove', this.dragMoveHandler);
            window.addEventListener('touchend', this.dragEndHandler);
            window.addEventListener('mouseup', this.dragEndHandler);
        }
        this.container.addEventListener('contextmenu', this.contextMenuHandler);
        this.container.addEventListener('dragstart', this.imageDragHandler);
        window.addEventListener('resize', this.resizeHandler);

        // Auto-recalculate slider widths when container size changes (e.g., from display:none to block in tabs)
        if (typeof ResizeObserver !== 'undefined') {
            this.resizeObserver = new ResizeObserver(() => {
                if (this.container && this.container.clientWidth > 0 && this.isMulti) {
                    this.resizeHandler();
                }
            });
            this.resizeObserver.observe(this.container);
        }
    }

    _initNavigation() {
        if (!this.navigation) return;

        this.navPrevHandler = (e) => { e.preventDefault(); this.prev(); };
        this.navNextHandler = (e) => { e.preventDefault(); this.next(); };

        if (this.prevEl) this.prevEl.addEventListener('click', this.navPrevHandler);
        if (this.nextEl) this.nextEl.addEventListener('click', this.navNextHandler);
    }

    // --------------------------------------------------------------
    // Responsive breakpoints
    // --------------------------------------------------------------
    _updateSlidesPerView() {
        if (!this.breakpoints) return;

        const containerWidth = this.container.clientWidth;
        let newPerView = this.baseSlidesPerView;

        const sortedBreakpoints = Object.keys(this.breakpoints)
            .map(Number)
            .sort((a, b) => a - b);

        for (let bp of sortedBreakpoints) {
            if (containerWidth >= bp) {
                newPerView = this.breakpoints[bp];
            } else {
                break;
            }
        }

        if (newPerView !== this.slidesPerView) {
            this.slidesPerView = newPerView;
            this.isMulti = this.slidesPerView > 1;
            this._initLayout();
            this.goToSlide(this.currentIndex, false);
        }
    }

    handleResize() {
        if (this.isMulti) {
            this._updateSlidesPerView();
            this._updateDimensions();
            const maxIndex = Math.max(0, this.slides.length - this.slidesPerView);
            if (this.currentIndex > maxIndex) {
                this.goToSlide(maxIndex, false);
            } else {
                this._applyWrapperTransform(this._getTargetTranslate(this.currentIndex), false);
            }
        }
    }

    _updateDimensions() {
        if (!this.isMulti) return;

        const containerWidth = this.container.clientWidth;
        this.slideWidth = (containerWidth - (this.slidesPerView - 1) * this.spaceBetween) / this.slidesPerView;

        const allItems = Array.from(this.wrapper.children);
        allItems.forEach(slide => {
            slide.style.width = this.slideWidth + 'px';
        });

        this.wrapperWidth = allItems.length * (this.slideWidth + this.spaceBetween) - this.spaceBetween;
        this.wrapper.style.width = this.wrapperWidth + 'px';

        if (!this.loop) {
            this.maxTranslate = -Math.max(0, this.wrapperWidth - containerWidth);
            this.minTranslate = 0;
        } else {
            // In loop mode we allow full movement
            this.maxTranslate = -this.wrapperWidth;
            this.minTranslate = 0;
        }
    }

    // Hardware‑accelerated transform
    _applyWrapperTransform(translateX, animate = true) {
        if (!this.isMulti) return;
        this.wrapper.style.transition = animate ? `transform ${this.animationDuration}ms ease` : 'none';
        this.wrapper.style.transform = `translate3d(${translateX}px, 0, 0)`;
    }

    _getWrapperTranslate() {
        if (!this.isMulti) return 0;
        const style = window.getComputedStyle(this.wrapper);
        const matrix = style.transform.match(/matrix.*\((.+)\)/);
        if (matrix) {
            const values = matrix[1].split(', ');
            if (values.length === 16) {
                return parseFloat(values[12] || 0); // 3d matrix
            } else {
                return parseFloat(values[4] || 0);  // 2d matrix
            }
        }
        return 0;
    }

    // Calculate target translation for a given logical index
    _getTargetTranslate(index) {
        if (!this.isMulti) return 0;

        let virtualIndex = index;
        if (this.loop) {
            // Add clone offset so that real slide at index 0 is placed after the first set of clones
            virtualIndex = index + this.cloneCount;
        }

        let translateX = -virtualIndex * (this.slideWidth + this.spaceBetween);
        if (this.centerMode) {
            const containerWidth = this.container.clientWidth;
            const offset = (containerWidth / 2) - (this.slideWidth / 2);
            translateX += offset;
        }

        if (!this.loop) {
            translateX = Math.max(this.maxTranslate, Math.min(this.minTranslate, translateX));
        }
        return translateX;
    }

    // Convert a translation value to the nearest logical index (for snap after momentum)
    _translateToIndex(translateX) {
        const step = this.slideWidth + this.spaceBetween;
        let rawIndex = -translateX / step;
        if (this.centerMode) {
            const containerWidth = this.container.clientWidth;
            const offset = (containerWidth / 2) - (this.slideWidth / 2);
            rawIndex = -(translateX - offset) / step;
        }
        let index = Math.round(rawIndex);
        if (this.loop) {
            // Adjust for clones – map to real slide index
            index = (index - this.cloneCount) % this.slides.length;
            if (index < 0) index += this.slides.length;
        } else {
            index = Math.max(0, Math.min(this.slides.length - this.slidesPerView, index));
        }
        return index;
    }

    // --------------------------------------------------------------
    // Public navigation methods
    // --------------------------------------------------------------
    goToSlide(index, animate = true) {
        if (this.slides.length === 0) return;

        const total = this.slides.length;
            let maxIndex = total - 1;
            if (this.isMulti && !this.centerMode) {
                maxIndex = Math.max(0, total - this.slidesPerView);
            }

        let targetIndex = index;
        if (!this.loop) {
            targetIndex = Math.max(0, Math.min(maxIndex, index));
        } else if (!this.isMulti) {
            // Single slide loop wrap
            if (targetIndex < 0) targetIndex = total - 1;
            else if (targetIndex > maxIndex) targetIndex = 0;
        }

        if (targetIndex === this.currentIndex && !this.isMulti) return;

        const prevIndex = this.currentIndex;
        this.currentIndex = targetIndex;
        // Normalize for active class
        if (this.loop && this.isMulti) {
            this.currentIndex = (this.currentIndex % total + total) % total;
        }

        // Update active class on original slides
        this.slides.forEach((slide, i) => {
            slide.classList.toggle("is-active", i === this.currentIndex);
        });

        if (this.isMulti) {
            // Compute target translation
            const translateX = this._getTargetTranslate(targetIndex);
            this._applyWrapperTransform(translateX, animate);

            if (this.loop && animate) {
                // After animation, if we ended on a clone, snap to real position without animation
                clearTimeout(this._snapTimeout);
                this._snapTimeout = setTimeout(() => {
                    const currentTx = this._getWrapperTranslate();
                    const nearestIndex = this._translateToIndex(currentTx);
                    const correctTx = this._getTargetTranslate(nearestIndex);
                    // Only snap if we're not already at the correct position
                    if (Math.abs(currentTx - correctTx) > 1) {
                        this._applyWrapperTransform(correctTx, false);
                    }
                    this.currentIndex = nearestIndex;
                    // Update active class again (in case it changed)
                    this.slides.forEach((slide, i) => {
                        slide.classList.toggle("is-active", i === this.currentIndex);
                    });
                }, this.animationDuration);
            }
        } else {
            // Single slide logic (unchanged) ...
            let isForward = index > prevIndex;
            if (this.loop) {
                if (prevIndex === total - 1 && index === 0) isForward = true;
                if (prevIndex === 0 && index === total - 1) isForward = false;
            }

            if (this.effect === 'slide' && animate && index !== prevIndex) {
                const incomingSlide = this.slides[index];
                incomingSlide.style.transition = 'none';
                incomingSlide.style.transform = isForward ? 'translateX(100%)' : 'translateX(-100%)';
                void incomingSlide.offsetWidth;
            }

            this.slides.forEach((slide, i) => {
                const isActive = i === this.currentIndex;
                    slide.style.position = isActive ? 'relative' : 'absolute';

                if (this.effect === 'fade') {
                    const opacity = isActive ? '1' : '0';
                    slide.style.transition = animate ? `opacity ${this.animationDuration}ms ease` : 'none';
                    slide.style.opacity = opacity;
                    slide.style.pointerEvents = isActive ? 'auto' : 'none';
                    slide.style.zIndex = isActive ? '1' : '0';
                    } else if (this.effect === 'slide') {
                        if (isActive) {
                        slide.style.transition = animate ? `transform ${this.animationDuration}ms ease` : 'none';
                        slide.style.transform = 'translateX(0)';
                        slide.style.pointerEvents = 'auto';
                        slide.style.zIndex = '1';
                    } else if (i === prevIndex) {
                            slide.style.transition = animate ? `transform ${this.animationDuration}ms ease` : 'none';
                            slide.style.transform = isForward ? 'translateX(-100%)' : 'translateX(100%)';
                        slide.style.pointerEvents = 'none';
                        slide.style.zIndex = '0';
                        } else {
                            slide.style.transition = 'none';
                            slide.style.transform = 'translateX(100%)';
                        slide.style.pointerEvents = 'none';
                        slide.style.zIndex = '0';
                    }
                }
            });
        }

        if (this.onChange && animate) this.onChange(this.currentIndex, prevIndex);
    }

    next() {
        this.goToSlide(this.currentIndex + 1);
    }

    prev() {
        this.goToSlide(this.currentIndex - 1);
    }

    // --------------------------------------------------------------
    // Drag handlers – with momentum and true infinite loop
    // --------------------------------------------------------------
    dragStart(e) {
        // Ignore drag if it started inside a nested slider
        const nestedSlider = e.target.closest('.swiper, .swiper-container, .js-episodes-slider');
        if (nestedSlider && nestedSlider !== this.container && this.container.contains(nestedSlider)) {
            return;
        }

        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;

        this.startX = clientX;
        this.startY = clientY;
        this.currentX = clientX;
        this.isDragging = true;
        this.isScrolling = false;
        this.velocity = 0;

        this.lastMoveTime = performance.now();
        this.lastMoveX = clientX;

        // Cancel any pending snap timeout and ongoing momentum
        if (this._snapTimeout) {
            clearTimeout(this._snapTimeout);
            this._snapTimeout = null;
        }
        if (this.animationFrame) {
            cancelAnimationFrame(this.animationFrame);
            this.animationFrame = null;
        }

        if (this.isMulti) {
            // Immediately set transition to none for responsive drag
            this.wrapper.style.transition = 'none';
            this.startTranslate = this._getWrapperTranslate();
        }

        this.container.style.cursor = 'grabbing';
    }

    dragMove(e) {
        if (!this.isDragging) return;

        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;

        // Small movement detection to decide scroll vs swipe
        if (!this.isScrolling) {
            const diffX = Math.abs(clientX - this.startX);
            const diffY = Math.abs(clientY - this.startY);
            if (diffX < 5 && diffY < 5) return; // ignore tiny moves

            if (diffY > diffX) {
                this.isScrolling = true;
                this.isDragging = false;
                return;
            }
        }

        e.preventDefault(); // prevent page scroll
        this.currentX = clientX;

        // Update velocity
        const now = performance.now();
        const elapsed = now - this.lastMoveTime;
        if (elapsed > 0) {
            this.velocity = (clientX - this.lastMoveX) / elapsed;
            // Limit velocity to avoid extreme values
            if (Math.abs(this.velocity) > 3) this.velocity = Math.sign(this.velocity) * 3;
            this.lastMoveTime = now;
            this.lastMoveX = clientX;
        }

        if (this.isMulti) {
            const delta = this.currentX - this.startX;
            let newTranslate = this.startTranslate + delta;
            if (!this.loop) {
                newTranslate = Math.max(this.maxTranslate, Math.min(this.minTranslate, newTranslate));
            }
            // Apply transform (already GPU accelerated)
            this.wrapper.style.transform = `translate3d(${newTranslate}px, 0, 0)`;
        }
    }

    dragEnd(e) {
        if (!this.isDragging) return;
        this.isDragging = false;
        this.container.style.cursor = '';

        if (this.isMulti) {
            const delta = this.currentX - this.startX;
            const absDelta = Math.abs(delta);

            // If barely moved, just snap back
            if (absDelta < 5 && Math.abs(this.velocity) < 0.1) {
                this.goToSlide(this.currentIndex, true);
                return;
            }

            // Calculate target translation (optionally with momentum)
            const step = this.slideWidth + this.spaceBetween;
            let finalTranslate = this._getWrapperTranslate();

            // Apply momentum: continue moving with decaying velocity
            if (Math.abs(this.velocity) > 0.1) {
                // Estimate how far we would go with deceleration
                const deceleration = 0.0015; // px/ms² – smooth slow down
                const direction = this.velocity > 0 ? 1 : -1;
                const speed = Math.abs(this.velocity);
                const distance = (speed * speed) / (2 * deceleration); // v²/(2a)
                const time = speed / deceleration;

                // Clamp distance to a reasonable number of slides (max 3)
                const maxSlides = 3;
                const maxDistance = maxSlides * step;
                const momentumDistance = Math.min(distance, maxDistance) * direction;

                finalTranslate += momentumDistance;

                // Clamp to bounds if not looping
                if (!this.loop) {
                    finalTranslate = Math.max(this.maxTranslate, Math.min(this.minTranslate, finalTranslate));
                }
            }

            // Find the nearest slide index from finalTranslate
            let targetIndex = this._translateToIndex(finalTranslate);

            // We pass the RAW targetIndex (e.g. -1 or total) to goToSlide 
            // so that it visually slides continuously into the cloned slide wrappers.
            // The goToSlide method handles clamping and snapping internally.

            // Go to that slide with animation
            this.goToSlide(targetIndex, true);

        } else {
            // Single slide drag (unchanged)
            const diff = this.currentX - this.startX;
            if (Math.abs(diff) > this.dragThreshold) {
                if (diff > 0) {
                    this.prev();
                } else {
                    this.next();
                }
            }
        }
    }

    // --------------------------------------------------------------
    // Destroy / cleanup
    // --------------------------------------------------------------
    destroy() {
        if (this.allowDrag) {
            this.container.removeEventListener('touchstart', this.dragStartHandler);
            this.container.removeEventListener('mousedown', this.dragStartHandler);
            window.removeEventListener('touchmove', this.dragMoveHandler);
            window.removeEventListener('mousemove', this.dragMoveHandler);
            window.removeEventListener('touchend', this.dragEndHandler);
            window.removeEventListener('mouseup', this.dragEndHandler);
        }
        this.container.removeEventListener('contextmenu', this.contextMenuHandler);
        this.container.removeEventListener('dragstart', this.imageDragHandler);
        window.removeEventListener('resize', this.resizeHandler);

        if (this.resizeObserver) {
            this.resizeObserver.disconnect();
        }

        if (this.prevEl && this.navPrevHandler) this.prevEl.removeEventListener('click', this.navPrevHandler);
        if (this.nextEl && this.navNextHandler) this.nextEl.removeEventListener('click', this.navNextHandler);

        if (this.clones && this.clones.length > 0) {
            this.clones.forEach(clone => clone.remove());
            this.clones = [];
        }

        this.slides.forEach(slide => {
            slide.style.position = '';
            slide.style.opacity = '';
            slide.style.transform = '';
            slide.style.pointerEvents = '';
            slide.style.transition = '';
            slide.style.zIndex = '';
            slide.style.width = '';
            slide.style.marginRight = '';
            slide.style.flex = '';
        });
        this.wrapper.style.transition = '';
        this.wrapper.style.transform = '';
        this.wrapper.style.width = '';
        this.wrapper.style.display = '';
        this.wrapper.style.flexWrap = '';
    }

    _debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
}
