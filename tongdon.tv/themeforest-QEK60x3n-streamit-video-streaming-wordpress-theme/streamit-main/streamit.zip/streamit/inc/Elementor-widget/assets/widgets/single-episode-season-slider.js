import sliderManager from "../core/slider-manager";

sliderManager.register("single-episode-season", (element, DEFAULT_CONFIG, MODULES) => ({
    ...DEFAULT_CONFIG,
    modules: MODULES,
    slidesPerView: 1,
    loop: false,
    speed: 300,
    initialSlide: parseInt(element.dataset.initialSlide || "0", 10),
    observer: true,
    observeParents: true,
    watchOverflow: true,
    breakpoints: {
        577: { slidesPerView: 1 },
        993: { slidesPerView: 2 },
        1025: { slidesPerView: 3 },
        1368: { slidesPerView: 5 }
    },
    navigation: element.dataset.navigation === "true"
        ? {
            nextEl: element.parentElement?.querySelector(".swiper-button-next"),
            prevEl: element.parentElement?.querySelector(".swiper-button-prev"),
        }
        : false,
}));

document.addEventListener("shown.bs.tab", (event) => {
    const trigger = event.target;
    if (!(trigger instanceof HTMLElement)) return;

    const targetSelector = trigger.getAttribute("data-bs-target") || trigger.getAttribute("href");
    if (!targetSelector || !targetSelector.startsWith("#")) return;

    const tabPane = document.querySelector(targetSelector);
    if (!(tabPane instanceof HTMLElement)) return;

    tabPane.querySelectorAll('.js-streamit-slider[data-type="single-episode-season"]').forEach((slider) => {
        sliderManager.initSlider(slider);

        requestAnimationFrame(() => {
            if (slider.swiper) {
                slider.swiper.update();
            }
        });
    });
});
