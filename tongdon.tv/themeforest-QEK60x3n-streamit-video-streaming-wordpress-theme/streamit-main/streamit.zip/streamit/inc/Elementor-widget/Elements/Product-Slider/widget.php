<?php

namespace Elementor;

use Elementor\Widget_Base;

if (!defined('ABSPATH')) {
    exit;
}

class ST_Products_Slider extends Widget_Base
{
    public $product_query;
    public $max_page;

    public function get_name()
    {
        return 'st_products_slider';
    }

    public function get_title()
    {
        return __('WooCommerce Products Slider', 'streamit');
    }

    public function get_categories()
    {
        return ['streamit'];
    }

    public function get_icon()
    {
        return 'eicon-product-images';
    }

    protected function register_controls()
    {
        $this->start_controls_section(
            'section_blog',
            [
                'label' => __('Products Slider', 'streamit'),
            ]
        );

        $this->add_control(
            'product_slider_title',
            [
                'label' => __('Title', 'streamit'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Title', 'streamit'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'product_type',
            [
                'label' => __('Select Product', 'streamit'),
                'type' => Controls_Manager::SELECT,
                'default' => 'products',
                'options' => [

                    'featured_products' => __('Feature Product', 'streamit'),
                    'recent_products' => __('Recent Product', 'streamit'),
                    'sale_products' => __('Sale Product', 'streamit'),
                    'best_selling_products' => __('Best Selling Product', 'streamit'),
                    'top_rated_products' => __('Top Rated Product', 'streamit'),
                    'products' => __('All Products', 'streamit'),
                ],
            ]
        );

        $this->add_control(
            'woo_order',
            [
                'label' => __('Order By', 'streamit'),
                'type' => Controls_Manager::SELECT,
                'default' => 'ASC',
                'options' => [
                    'DESC' => esc_html__('Descending', 'streamit'),
                    'ASC' => esc_html__('Ascending', 'streamit')
                ],
            ]
        );

        $this->add_control(
            'woo_per_page',
            [
                'label' => __('Total Products', 'streamit'),
                'type' => Controls_Manager::NUMBER,
                'min' => -1,
                'step' => 1,
                'default' => 10,
                'description' => __('Controls how many products are loaded into the slider. Visible items per device are controlled by Desktop/Laptop/Tablet/Mobile view settings below.', 'streamit'),
            ]
        );

        $this->add_control(
            'view_all_switch',
            [
                'label' => __('Use View All Button ?', 'streamit'),
                'type' => Controls_Manager::SWITCHER,
                'yes' => __('Yes', 'streamit'),
                'no' => __('No', 'streamit'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'use_custom_link_viewall',
            [
                'label' => __('Use View All custom link ?', 'streamit'),
                'type' => Controls_Manager::SWITCHER,
                'yes' => __('Yes', 'streamit'),
                'no' => __('No', 'streamit'),
                'return_value' => 'yes',
                'default' => 'no',
                'condition' => ['view_all_switch' => 'yes'],
            ]
        );

        $this->add_control(
            'use_custom_link_text',
            [
                'label' => __('Custom Link Text', 'streamit'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Link Text', 'streamit'),
                'label_block' => true,
                'condition' => [
                    'use_custom_link_viewall' => 'yes',
                    'view_all_switch' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'view_all_custom_link',
            [
                'label' => __('Custom link', 'streamit'),
                'type' => Controls_Manager::URL,
                'placeholder' => __('https://your-link.com', 'streamit'),
                'show_external' => true,
                'default' => [
                    'url' => '',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'condition' => [
                    'use_custom_link_viewall' => 'yes',
                    'view_all_switch' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'show_catalog',
            [
                'label' => __('Show Catalog ordering', 'streamit'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'streamit'),
                'label_off' => __('Hide', 'streamit'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => ['show_pagination' => 'yes'],
            ]
        );

        $this->add_control(
            'woo_category',
            [
                'label' => __('Display Product From Specific Category', 'streamit'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'multiple' => true,
                'options' => isset($_REQUEST['editor_post_id']) && function_exists('streamit_get_all_taxonomies') ? streamit_get_all_taxonomies("product_cat") : [],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'slick_control_section',
            [
                'label' => __('Slider Control', 'streamit'),
            ]
        );

        $this->add_control(
            'desk_number',
            [
                'label' => __('Desktop view', 'streamit'),
                'type' => Controls_Manager::TEXT,
                'dynamic' => [
                    'active' => true,
                ],
                'label_block' => true,
                'default' => '5',
            ]
        );

        $this->add_control(
            'lap_number',
            [
                'label' => __('Laptop view', 'streamit'),
                'type' => Controls_Manager::TEXT,
                'dynamic' => [
                    'active' => true,
                ],
                'label_block' => true,
                'default' => '4',
            ]
        );


        $this->add_control(
            'tab_number',
            [
                'label' => __('Tablet view', 'streamit'),
                'type' => Controls_Manager::TEXT,
                'dynamic' => [
                    'active' => true,
                ],
                'label_block' => true,
                'default' => '3',
            ]
        );

        $this->add_control(
            'mob_number',
            [
                'label' => __('Mobile view', 'streamit'),
                'type' => Controls_Manager::TEXT,
                'dynamic' => [
                    'active' => true,
                ],
                'label_block' => true,
                'default' => '2',
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label' => __('Autoplay', 'streamit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'true' => __('True', 'streamit'),
                    'false' => __('False', 'streamit'),
                ],
                'default' => 'false',
            ]
        );

        $this->add_control(
            'autoplay_speed',
            [
                'label' => __('Autoplay Speed', 'streamit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => false,
                'condition' => ['autoplay' => 'true'],
                'default' => '2000',
            ]
        );

        $this->add_control(
            'infinite',
            [
                'label' => __('Infinite', 'streamit'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'true' => __('True', 'streamit'),
                    'false' => __('False', 'streamit'),
                ],
                'default' => 'false',
            ]
        );

        $this->add_control(
            'speed',
            [
                'label' => __('Speed', 'streamit'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => '300',
            ]
        );

        $this->add_responsive_control(
            'nav-arrow',
            [
                'label' => __('Arrow', 'streamit'),
                'type' => Controls_Manager::SELECT,
                'devices' => ['desktop', 'laptop', 'tablet', 'mobile'],
                'default' => 'true',
                'laptop_default' => 'true',
                'tablet_default' => 'false',
                'mobile_default' => 'false',
                'options' => [
                    'true' => __('True', 'streamit'),
                    'false' => __('False', 'streamit'),
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_title_style',
            [
                'label' => esc_html__('Slider Heading ', 'streamit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'label' => esc_html__('Typography', 'streamit'),
                'selector' => '{{WRAPPER}} .st-woocommerce-product-slider .st-main-header  .main-title',
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__('Color', 'streamit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}  .st-woocommerce-product-slider .st-main-header  .main-title' => 'color:{{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'title_hover_color',
            [
                'label' => esc_html__('Hover Color', 'streamit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}  .st-woocommerce-product-slider .st-main-header  .main-title:hover' => 'color:{{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_margin',
            [
                'label' => esc_html__('Margin', 'streamit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .st-woocommerce-product-slider .st-main-header' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_padding',
            [
                'label' => esc_html__('Padding', 'streamit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .st-woocommerce-product-slider .st-main-header' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_product_style',
            [
                'label' => esc_html__('Product ', 'streamit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'product_margin',
            [
                'label' => esc_html__('Margin', 'streamit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .st-woocommerce-product-slider .css_prefix-sub-product' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],

            ]
        );

        $this->add_responsive_control(
            'product_padding',
            [
                'label' => esc_html__('Padding', 'streamit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .st-woocommerce-product-slider .css_prefix-sub-product' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_product_content_style',
            [
                'label' => esc_html__('Product Content Box', 'streamit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'product_content_padding',
            [
                'label' => esc_html__('Padding', 'streamit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .st-woocommerce-product-slider .css_prefix-sub-product .product-caption' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_product_title_style',
            [
                'label' => esc_html__('Product Content', 'streamit'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'product_title_typography',
                'label' => esc_html__('Title Typography', 'streamit'),
                'selector' => '{{WRAPPER}} .st-woocommerce-product-slider .css_prefix-sub-product .product-caption .woocommerce-loop-product__title',
            ]
        );

        $this->add_control(
            'product_title_color',
            [
                'label' => esc_html__('Title Color', 'streamit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}  .st-woocommerce-product-slider .css_prefix-sub-product .product-caption .woocommerce-loop-product__title > a' => 'color:{{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'product_hover_title_color',
            [
                'label' => esc_html__(' Title Hover Color', 'streamit'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}  .st-woocommerce-product-slider .css_prefix-sub-product .product-caption .woocommerce-loop-product__title:hover > a' => 'color:{{VALUE}}',
                ],
            ]
        );

        $this->add_responsive_control(
            'product_title_margin',
            [
                'label' => esc_html__('Product Title Margin', 'streamit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .st-woocommerce-product-slider .css_prefix-sub-product .product-caption .woocommerce-loop-product__title ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'product_price_margin',
            [
                'label' => esc_html__('Product Price Margin', 'streamit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .st-woocommerce-product-slider .css_prefix-sub-product .product-caption .price-detail' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'product_rating_margin',
            [
                'label' => esc_html__('Product Rating Margin', 'streamit'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .st-woocommerce-product-slider .css_prefix-sub-product .product-caption .container-rating' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    public function render()
    {

        if (!class_exists('WooCommerce')) {
            return false;
        }

        $settings = $this->get_settings_for_display();
        $get_responsive_flag = static function (array $settings, string $key, string $legacy_key = '', string $fallback = 'flex'): bool {
            if (array_key_exists($key, $settings) && $settings[$key] !== '') {
                return $settings[$key] === 'flex' || $settings[$key] === 'true';
            }

            if ($legacy_key && array_key_exists($legacy_key, $settings) && $settings[$legacy_key] !== '') {
                return $settings[$legacy_key] === 'flex' || $settings[$legacy_key] === 'true';
            }

            return $fallback === 'flex' || $fallback === 'true';
        };
        $desktop_navigation = $get_responsive_flag($settings, 'nav-arrow', '', 'flex');
        $laptop_navigation = $get_responsive_flag($settings, 'nav-arrow_laptop', '', 'flex');
        $tablet_navigation = $get_responsive_flag($settings, 'nav-arrow_tablet', 'nav_arrow_tablet');
        $mobile_navigation = $get_responsive_flag($settings, 'nav-arrow_mobile', 'nav_arrow_mobile');
        $slick_settings = array(
            "dots" => false,
            "slidesToShow" => !empty($settings['desk_number']) ? intval($settings['desk_number']) : 6,
            "slidesToScroll" => !empty($settings['desk_number']) ? intval($settings['desk_number']) : 6,
            "arrows" => $desktop_navigation || $laptop_navigation || $tablet_navigation || $mobile_navigation,
            "autoplay" => !empty($settings['autoplay']) && $settings['autoplay'] === "true" ? true : false,
            "autoplaySpeed" => !empty($settings['autoplay_speed']) ? intval($settings['autoplay_speed']) : 2000,
            "speed" => !empty($settings['speed']) ? intval($settings['speed']) : 300,
            "infinite" => !empty($settings['infinite']) && $settings['infinite'] === "true" ? true : false,
            "responsive" => [
                [
                    "breakpoint" => 1367,
                    "settings" => [
                        "slidesToShow" => !empty($settings['lap_number']) ? intval($settings['lap_number']) : 4,
                        "slidesToScroll" => !empty($settings['lap_number']) ? intval($settings['lap_number']) : 4,
                    ]
                ],
                [
                    "breakpoint" => 1025,
                    "settings" => [
                        "slidesToShow" => !empty($settings['tab_number']) ? intval($settings['tab_number']) : 3,
                        "slidesToScroll" => !empty($settings['tab_number']) ? intval($settings['tab_number']) : 3,
                    ]
                ],
                [
                    "breakpoint" => 768,
                    "settings" => [
                        "slidesToShow" => !empty($settings['mob_number']) ? intval($settings['mob_number']) : 2,
                        "slidesToScroll" => !empty($settings['mob_number']) ? intval($settings['mob_number']) : 2,
                    ]
                ]
            ]
        );

        $category = '';
        if (!empty($settings['woo_category'])) {
            foreach ($settings['woo_category'] as $element) {
                $category .= $element . ",";
            }
            $category = "category=" . '"' . rtrim($category, ",") . '"';
        }

        do_action('woocommerce_before_shop_loop');

        add_filter('woocommerce_product_loop_start', '__return_empty_string', 10);

        try {
            add_filter(
                'wc_get_template_part',
                function ($template, $slug, $name) {
                    // Check for specific slugs or names if needed
                    if ($slug === 'content' && $name === 'product') {
                        $template = locate_template('template-parts/wocommerce/entry.php');
                    }
                    return $template;
                },
                10,
                3
            );

            // Widget rendering logic here
        } finally {
            remove_filter('wc_get_template_part', function () {}, 10); // Match the closure
        }

        add_filter('woocommerce_product_loop_end', '__return_empty_string', 10);

        do_action('woocommerce_after_shop_loop');

        $details = array(
            'category' => $category,
        );

        $products_per_page = isset($settings['woo_per_page']) ? intval($settings['woo_per_page']) : 10;
        $desktop_slides = !empty($settings['desk_number']) ? intval($settings['desk_number']) : 5;
        $laptop_slides = !empty($settings['lap_number']) ? intval($settings['lap_number']) : 4;
        $tablet_slides = !empty($settings['tab_number']) ? intval($settings['tab_number']) : 3;
        $mobile_slides = !empty($settings['mob_number']) ? intval($settings['mob_number']) : 2;

        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log(
                'Streamit Product Slider Debug: ' . wp_json_encode([
                    'widget' => 'st_products_slider',
                    'product_type' => $settings['product_type'] ?? 'products',
                    'woo_per_page' => $products_per_page,
                    'desk_number' => $desktop_slides,
                    'lap_number' => $laptop_slides,
                    'tab_number' => $tablet_slides,
                    'mob_number' => $mobile_slides,
                    'woo_order' => $settings['woo_order'] ?? 'ASC',
                    'woo_category' => $settings['woo_category'] ?? [],
                ])
            );
        }

        streamit_get_template(
            'elementor-widget/products-slider/html-products-slider.php',
            [
                'details' => $details,
                'settings' => $settings,
                'products_per_page' => $products_per_page,
                'desktop_slides' => $desktop_slides,
                'laptop_slides' => $laptop_slides,
                'tablet_slides' => $tablet_slides,
                'mobile_slides' => $mobile_slides,
            ]
        );
    }
}
